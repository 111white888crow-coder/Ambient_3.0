import { ModalFormData } from "@minecraft/server-ui";

import { showWhenFree } from "../utils/forms.js";
import {
	LENGTH_CHOICES,
	MAX_TEMPO,
	MIN_TEMPO,
	parseMelody,
	renderRoll
} from "./melody.js";

/**
 * The instrument screen — one tab, no menu.
 *
 * Top to bottom: the melody's name, the melody itself with the record switch
 * beside it, the piano roll, then the timing settings. That order is also the
 * layout: the screen's factory lays the controls out in exactly the order they
 * are added here, so moving a field in this function moves it on screen.
 *
 * Which screen draws the tab is picked by the title, `dd:inst.<ui>.<name key>`.
 * Every file in RP/ui/dd/instruments/ is one look — its own textures and, if it
 * wants one, an icon in front of the name — and shows itself only for the marker
 * it names in $title_needs_to_contain. The layout they all share lives in
 * RP/ui/dd/instrument_screen.json. An instrument picks its look with `ui` in
 * MelodyStore.INSTRUMENTS; one without it gets the default screen.
 *
 * After the marker comes the instrument's name key rather than free text: the
 * screen strips the marker and shows what is left, and a bare .lang key is what
 * a label translates on its own.
 */

const TITLE_PREFIX = "dd:inst.";
const DEFAULT_UI = "default";

/** Extent of the roll in the tab. The panel scrolls, so it can afford to be full size. */
const ROLL_IN_FORM = { lanes: 8, beats: 20 };

/** Label text lives in RP/texts/*.lang; this wraps a key as a RawMessage. */
const tr = (name) => ({ translate: `button.dd:${name}.name` });

const QUANTIZE_KEYS = [0, 1].map((i) => tr(`quantize_${i}`));
const LENGTH_KEYS = LENGTH_CHOICES.map((_, i) => tr(`length_${i}`));

/**
 * `label` is a standalone read-only row, but it only exists from server-ui 2.0
 * on. Where it is missing the roll rides along on the melody field's own label
 * instead, which loses the separate row but never loses the form.
 */
const SUPPORTS_LABEL = typeof ModalFormData.prototype.label === "function";

/**
 * @param {import("@minecraft/server").Player} player
 * @param {{nameKey: string, ui?: string, melody: string, name: string, tempo: number,
 *          lengthIndex: number, quantize: boolean, recording: boolean}} state
 * @returns {Promise<{name: string, melody: string, record: boolean, tempo: number,
 *                    lengthIndex: number, quantize: boolean}|undefined>}
 */
export async function openInstrumentForm(player, state) {
	const { events, errors } = parseMelody(state.melody);

	const roll = renderRoll(events, state.tempo, ROLL_IN_FORM).rawtext;
	const notice = errors.length === 0 ? [] : [
		{ text: "\n§c" },
		{ translate: "text.dd:msg_bad_tokens.name" },
		{ text: ` ${errors.slice(0, 4).join(" ")}§r` }
	];

	const melodyLabel = SUPPORTS_LABEL
		? tr("inst_melody")
		: { rawtext: [tr("inst_melody"), { text: "\n" }, ...roll, ...notice] };

	const form = new ModalFormData()
		.title(`${TITLE_PREFIX}${state.ui ?? DEFAULT_UI}.${state.nameKey}`)
		.textField(tr("inst_name"), { translate: state.nameKey }, { defaultValue: state.name })
		.textField(melodyLabel, "A1 #C1:bell/2@4 - G0", { defaultValue: state.melody })
		.toggle(tr("inst_record"), { defaultValue: state.recording });

	if (SUPPORTS_LABEL) form.label({ rawtext: [...roll, ...notice] });

	form
		.slider(tr("inst_tempo"), MIN_TEMPO, MAX_TEMPO, { valueStep: 1, defaultValue: state.tempo })
		.dropdown(tr("inst_length"), LENGTH_KEYS, { defaultValueIndex: state.lengthIndex })
		.dropdown(tr("inst_quantize"), QUANTIZE_KEYS, { defaultValueIndex: state.quantize ? 1 : 0 })
		.submitButton(tr("inst_submit"));

	let response;
	try {
		response = await showWhenFree(form, player);
	} catch (error) {
		console.warn(`[instruments] form: ${error}`);
		return undefined;
	}

	if (!response || response.canceled) return undefined;

	const [name, melody, record, tempo, lengthIndex, quantize] = response.formValues.filter((v) => v !== undefined);

	return {
		name: typeof name === "string" ? name : "",
		melody: typeof melody === "string" ? melody : "",
		record: record === true,
		tempo: Number(tempo) || state.tempo,
		lengthIndex: Number(lengthIndex) || 0,
		quantize: Number(quantize) === 1
	};
}
