import { NOTE_NAMES, NOTE_COUNT, OCTAVE_COUNT, TONES, clampNote, clampOctave } from "../blocks/tuning_fork/notes.js";

/**
 * The melody format the instruments read, write and show.
 *
 * A melody is a line of space-separated tokens, one per event:
 *
 *     A1              note A, octave 1
 *     #C2             C sharp, octave 2
 *     A#1  Bb1        the sharp and flat spellings people actually type
 *     -               a rest
 *
 * and each of those takes up to three suffixes, in any order:
 *
 *     :bell           tone — ring this note with a different timbre
 *     /2              length — how many beats the note is held (default 1)
 *     @4              position — start on beat 4 of the melody
 *
 *     A1:bell/2@4     all four at once
 *
 * Without `@` an event simply follows the one before it, which is what makes a
 * plain `A1 B1 C1` line read as a tune. With `@` it is pinned to an absolute
 * beat, so two events can share a start time and sound as a chord.
 *
 * Pitch names come straight from the tuning fork (notes.js), so an instrument
 * and a fork set to the same note play the same pitch — and a note carrying a
 * `:tone` is what lets a melody ring forks tuned to a different timbre than the
 * instrument playing it.
 *
 * Beats become ticks through the instrument's tempo, which is stored on the item
 * rather than in the text, so one melody can be played fast or slow without
 * being retyped.
 */

export const DEFAULT_TEMPO = 4;
export const MIN_TEMPO = 1;
export const MAX_TEMPO = 20;

/** Beat lengths offered in the settings, and what an unmarked note is worth. */
export const LENGTH_CHOICES = [0.5, 1, 2, 4];
export const DEFAULT_LENGTH_INDEX = 1;

/** Guard rails so a pasted wall of text cannot lock up a tick or fill an item. */
export const MAX_EVENTS = 400;
export const MAX_TEXT = 2000;
const MAX_BEATS = 512;

/** Default extent of the piano roll; the form asks for a smaller one. */
const ROLL_BEATS = 24;
const ROLL_LANES = 8;

/**
 * Reads melody text into events laid out on the beat grid.
 *
 * @returns {{events: MelodyEvent[], errors: string[]}}
 *   Events come back sorted by start time with `start` already resolved to an
 *   absolute beat. `note === null` marks a rest, `tone === null` means "whatever
 *   the instrument is". Bad tokens are named in `errors` and skipped, so one
 *   typo does not throw the rest of the line away.
 *
 * @typedef {{note: number|null, octave: number, beats: number, tone: number|null,
 *            start: number, pinned: boolean}} MelodyEvent
 */
export function parseMelody(text) {
	const events = [];
	const errors = [];

	if (typeof text !== "string" || text.trim() === "") return { events, errors };

	let cursor = 0;

	for (const raw of text.trim().split(/[\s,]+/)) {
		if (events.length >= MAX_EVENTS) {
			errors.push(`>${MAX_EVENTS}`);
			break;
		}

		const token = raw.trim();
		if (token === "") continue;

		const parsed = parseToken(token);
		if (!parsed) {
			errors.push(token);
			continue;
		}

		const start = parsed.start === null ? cursor : parsed.start;
		if (start > MAX_BEATS) {
			errors.push(token);
			continue;
		}

		events.push({
			note: parsed.note,
			octave: parsed.octave,
			beats: parsed.beats,
			tone: parsed.tone,
			start,
			pinned: parsed.start !== null
		});

		cursor = start + parsed.beats;
	}

	events.sort((a, b) => a.start - b.start);
	return { events, errors };
}

/** One suffix: its marker, then a word for a tone or a number for a length or a beat. */
const SUFFIX = /([:/@])([A-Za-z_]+|\d+(?:\.\d+)?)/y;

/** One token -> its parts, or undefined when it is not a valid event. */
function parseToken(token) {
	const firstMarker = token.search(/[:/@]/);
	const pitchPart = firstMarker < 0 ? token : token.slice(0, firstMarker);
	if (pitchPart === "") return undefined;

	const suffixes = {};
	if (firstMarker >= 0) {
		SUFFIX.lastIndex = firstMarker;
		while (SUFFIX.lastIndex < token.length) {
			const match = SUFFIX.exec(token);
			if (!match || match[1] in suffixes) return undefined;
			suffixes[match[1]] = match[2];
		}
	}

	let tone = null;
	if (suffixes[":"] !== undefined) {
		tone = TONES.findIndex((t) => t.id === suffixes[":"].toLowerCase());
		if (tone < 0) return undefined;
	}

	let beats = 1;
	if (suffixes["/"] !== undefined) {
		beats = Number(suffixes["/"]);
		if (!Number.isFinite(beats) || beats <= 0 || beats > 64) return undefined;
	}

	let start = null;
	if (suffixes["@"] !== undefined) {
		start = Number(suffixes["@"]);
		if (!Number.isFinite(start) || start < 0) return undefined;
	}

	if (pitchPart === "-" || pitchPart === "_") {
		return { note: null, octave: 0, beats, tone: null, start };
	}

	const pitch = parsePitch(pitchPart);
	if (!pitch) return undefined;

	return { note: pitch.note, octave: pitch.octave, beats, tone, start };
}

/** `#A1`, `A#1`, `Bb1`, `a1`, `A` -> {note, octave}. Undefined if it is not a pitch. */
function parsePitch(text) {
	let body = text.toUpperCase();

	let octave = 1;
	const tail = body.slice(-1);
	if (tail >= "0" && tail <= "9") {
		octave = clampOctave(Number(tail));
		body = body.slice(0, -1);
	}

	if (/^[A-G]B$/.test(body)) {
		const natural = NOTE_NAMES.indexOf(body[0]);
		if (natural < 0) return undefined;
		return { note: (natural - 1 + NOTE_COUNT) % NOTE_COUNT, octave };
	}

	if (body.endsWith("#")) body = "#" + body.slice(0, -1);

	const note = NOTE_NAMES.indexOf(body);
	if (note < 0) return undefined;

	return { note, octave };
}

/**
 * Turns events back into text.
 *
 * `@` is written only where the event does not already fall where the reader's
 * cursor would put it. That keeps a plain sequential tune as the plain line it
 * was typed as, and it is also what makes the output re-readable: writing `@`
 * from a `pinned` flag instead would drift, because a pinned event moves the
 * cursor too, so one interleaved with unpinned notes shifts everything after it.
 */
export function formatMelody(events) {
	let cursor = 0;

	return events
		.map((e) => {
			let token = e.note === null ? "-" : NOTE_NAMES[clampNote(e.note)] + clampOctave(e.octave);
			if (e.tone !== null && e.tone !== undefined && TONES[e.tone]) token += ":" + TONES[e.tone].id;
			if (e.beats !== 1) token += "/" + trimNumber(e.beats);
			if (e.start !== cursor) token += "@" + trimNumber(e.start);

			cursor = e.start + e.beats;
			return token;
		})
		.join(" ");
}

function trimNumber(value) {
	return Number(value.toFixed(2)).toString();
}

/** Beat the melody ends on — the furthest point any event reaches. */
export function totalBeats(events) {
	let end = 0;
	for (const e of events) end = Math.max(end, e.start + e.beats);
	return end;
}

export function durationTicks(events, tempo) {
	return Math.round(totalBeats(events) * tempo);
}

export function durationSeconds(events, tempo) {
	return durationTicks(events, tempo) / 20;
}

/** Just the events that make a sound, in playing order. */
export function soundedEvents(events) {
	return events.filter((e) => e.note !== null);
}

/**
 * Melody text cut down to MAX_TEXT on a token boundary. A plain slice can stop
 * inside the last note and leave `#D0/0.75` as `#D0/0`, which no longer reads;
 * this drops that note whole instead.
 */
export function clipMelody(text) {
	if (text.length <= MAX_TEXT) return text;

	let cut = MAX_TEXT;
	while (cut > 0 && !/[\s,]/.test(text[cut])) cut--;
	return text.slice(0, cut > 0 ? cut : MAX_TEXT);
}

/**
 * The roll's mark for a note that names its tone: the initial, except where two
 * tones share one — bell and bass both start with B, so bass takes its S.
 */
const TONE_MARKS = {
	harp: "H", bell: "B", chime: "C", flute: "F",
	guitar: "G", xylophone: "X", bass: "S", pling: "P"
};

const toneMark = (id) => TONE_MARKS[id] ?? id[0].toUpperCase();

/**
 * The piano roll: one lane per pitch, one column per beat, time running left to
 * right. Returned as a RawMessage: the grid is literal characters, but the
 * wording around it comes from RP/texts/*.lang.
 *
 * Cells are `#` for a note in the instrument's own tone and a capital letter
 * from TONE_MARKS for one that names a tone, so a `:bell` note is visible at a
 * glance.
 * Only those characters and `_` are used, and every lane label is padded to
 * exactly three of them: Minecraft's font is proportional — spaces and dots are
 * narrower than the rest — so sticking to glyphs of one width is what keeps the
 * columns lined up.
 */
export function renderRoll(events, tempo, options = {}) {
	const t = (name) => ({ translate: `text.dd:${name}.name` });
	const maxBeats = options.beats ?? ROLL_BEATS;
	const maxLanes = options.lanes ?? ROLL_LANES;

	const sounded = soundedEvents(events);
	if (events.length === 0) return { rawtext: [{ text: "§7" }, t("roll_empty"), { text: "§r" }] };
	if (sounded.length === 0) return { rawtext: [{ text: "§7" }, t("roll_rests"), { text: "§r" }] };

	const end = totalBeats(events);
	const shownBeats = Math.max(1, Math.min(maxBeats, Math.ceil(end)));

	const lanes = new Map();
	for (const e of sounded) {
		const key = e.octave * NOTE_COUNT + e.note;
		if (!lanes.has(key)) lanes.set(key, []);
		lanes.get(key).push(e);
	}

	const ordered = [...lanes.keys()].sort((a, b) => b - a);
	const visible = ordered.slice(0, maxLanes);
	const lines = [];

	for (const key of visible) {
		const cells = new Array(shownBeats).fill("_");

		for (const e of lanes.get(key)) {
			const mark = e.tone !== null && TONES[e.tone] ? toneMark(TONES[e.tone].id) : "#";
			const from = Math.max(0, Math.floor(e.start));
			const to = Math.min(shownBeats, Math.ceil(e.start + e.beats));
			for (let i = from; i < to; i++) cells[i] = mark;
		}

		lines.push(`§e${laneLabel(key)}§r§8|§r§a${cells.join("")}§r`);
	}

	const parts = [{ text: lines.join("\n") }];

	if (ordered.length > visible.length) {
		parts.push({ text: `\n§7+${ordered.length - visible.length} ` }, t("roll_more"), { text: "§r" });
	}
	if (end > shownBeats) {
		parts.push({ text: `\n§7> ${shownBeats} ` }, t("roll_beats"), { text: "§r" });
	}

	parts.push(
		{ text: `\n§7${sounded.length} ` }, t("roll_notes"),
		{ text: ` · ${trimNumber(end)} ` }, t("roll_beats"),
		{ text: ` · ${durationSeconds(events, tempo).toFixed(1)} ` }, t("roll_seconds"),
		{ text: "§r" }
	);

	return { rawtext: parts };
}

/**
 * A three-character lane name such as `#A1` or `-G0`. Naturals get a leading `-`
 * so every label is the same width and the grid stays square.
 */
function laneLabel(key) {
	const octave = Math.floor(key / NOTE_COUNT) % OCTAVE_COUNT;
	const name = NOTE_NAMES[key % NOTE_COUNT];
	return (name.length === 1 ? "-" + name : name) + octave;
}
