import { EquipmentSlot } from "@minecraft/server";

import { TONES } from "../blocks/tuning_fork/notes.js";
import {
	DEFAULT_LENGTH_INDEX,
	DEFAULT_TEMPO,
	MAX_TEMPO,
	MIN_TEMPO,
	clipMelody,
	durationSeconds,
	parseMelody,
	soundedEvents
} from "./melody.js";

/**
 * Where an instrument keeps its melody.
 *
 * Everything lives on the held ItemStack as dynamic properties, so two harps in
 * the same chest hold two different tunes and the melody travels with the item
 * when it is traded or dropped. The catch is that an ItemStack read out of a
 * container is a copy: changing it does nothing until it is written back, which
 * is what `updateHeld` and `updateInSlot` are for.
 */

const PROP_MELODY = "dd:melody";
const PROP_TEMPO = "dd:tempo";
const PROP_LENGTH = "dd:length";
const PROP_NAME = "dd:melody_name";
const PROP_QUANTIZE = "dd:quantize";

/**
 * Item id -> which of the tuning fork's timbres it is, and how its tab looks.
 *
 * `tone` is an index into TONES, which is what ties the two features together:
 * a note played on the harp only rings forks whose own tone is set to harp.
 *
 * `ui` names the screen that draws the tab: it is the middle of the
 * `dd:inst.<ui>.` title marker that RP/ui/dd/instruments/<ui>_screen.json waits
 * for. No dots in it. Leave it out and the tab gets the default screen.
 */
export const INSTRUMENTS = {
	"dd:harp": { tone: toneIndex("harp"), nameKey: "item.dd:harp.name", ui: "lira" },
};

function toneIndex(id) {
	const index = TONES.findIndex((t) => t.id === id);
	if (index < 0) throw new Error(`[instruments] no tone "${id}" in notes.js`);
	return index;
}

export const isInstrument = (typeId) => Object.prototype.hasOwnProperty.call(INSTRUMENTS, typeId);

export function getHeld(player) {
	try {
		const equippable = player.getComponent("minecraft:equippable");
		const stack = equippable?.getEquipment(EquipmentSlot.Mainhand);
		return stack && isInstrument(stack.typeId) ? stack : undefined;
	} catch {
		return undefined;
	}
}

/**
 * Runs `mutate` on a copy of the held instrument and puts the result back in the
 * player's hand. Returns false when nothing was held or the write failed.
 *
 * @param {import("@minecraft/server").Player} player
 * @param {(stack: import("@minecraft/server").ItemStack) => void} mutate
 */
export function updateHeld(player, mutate) {
	try {
		const equippable = player.getComponent("minecraft:equippable");
		const stack = equippable?.getEquipment(EquipmentSlot.Mainhand);
		if (!stack || !isInstrument(stack.typeId)) return false;

		mutate(stack);
		refreshLore(stack);
		equippable.setEquipment(EquipmentSlot.Mainhand, stack);
		return true;
	} catch (error) {
		console.warn(`[instruments] write: ${error}`);
		return false;
	}
}

/**
 * The same for the instrument in one inventory slot, held or not. A recording
 * is saved this way, to the slot it was started from, so it still reaches its
 * instrument after the player has switched to something else.
 *
 * @param {import("@minecraft/server").Player} player
 * @param {number} slot
 * @param {(stack: import("@minecraft/server").ItemStack) => void} mutate
 */
export function updateInSlot(player, slot, mutate) {
	try {
		const container = player.getComponent("minecraft:inventory")?.container;
		const stack = container?.getItem(slot);
		if (!stack || !isInstrument(stack.typeId)) return false;

		mutate(stack);
		refreshLore(stack);
		container.setItem(slot, stack);
		return true;
	} catch (error) {
		console.warn(`[instruments] write: ${error}`);
		return false;
	}
}

export function readSettings(stack) {
	const melody = asString(stack.getDynamicProperty(PROP_MELODY));
	const tempo = asNumber(stack.getDynamicProperty(PROP_TEMPO), DEFAULT_TEMPO, MIN_TEMPO, MAX_TEMPO);
	const lengthIndex = asNumber(stack.getDynamicProperty(PROP_LENGTH), DEFAULT_LENGTH_INDEX, 0, 3);
	const name = asString(stack.getDynamicProperty(PROP_NAME));
	const quantize = stack.getDynamicProperty(PROP_QUANTIZE) !== false;

	return { melody, tempo: Math.round(tempo), lengthIndex: Math.round(lengthIndex), name, quantize };
}

export function writeSettings(stack, settings) {
	if (settings.melody !== undefined) {
		stack.setDynamicProperty(PROP_MELODY, clipMelody(String(settings.melody)));
	}
	if (settings.tempo !== undefined) {
		stack.setDynamicProperty(PROP_TEMPO, clamp(Math.round(settings.tempo), MIN_TEMPO, MAX_TEMPO));
	}
	if (settings.lengthIndex !== undefined) {
		stack.setDynamicProperty(PROP_LENGTH, clamp(Math.round(settings.lengthIndex), 0, 3));
	}
	if (settings.name !== undefined) {
		stack.setDynamicProperty(PROP_NAME, String(settings.name).slice(0, 48));
	}
	if (settings.quantize !== undefined) {
		stack.setDynamicProperty(PROP_QUANTIZE, settings.quantize === true);
	}
}

/**
 * Mirrors the melody onto the tooltip. The stored copy is the source of truth;
 * this is only so a player can tell two instruments apart in a chest without
 * opening either of them.
 *
 * setLore takes plain strings — it does not accept a RawMessage — so this is the
 * one piece of player-facing text in the pack that cannot go through .lang. It
 * is written in English and kept to two short words, and an instrument with no
 * melody gets no lore at all rather than a line saying so.
 */
function refreshLore(stack) {
	const { melody, tempo, name } = readSettings(stack);
	const { events } = parseMelody(melody);

	if (events.length === 0) {
		stack.setLore([]);
		return;
	}

	const lore = [];
	if (name) lore.push(`§b${name}§r`);
	lore.push(`§7${soundedEvents(events).length} notes · ${durationSeconds(events, tempo).toFixed(1)}s§r`);
	lore.push(`§8tempo ${tempo}§r`);

	stack.setLore(lore);
}

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

function asString(value) {
	return typeof value === "string" ? value : "";
}

function asNumber(value, fallback, lo, hi) {
	return typeof value === "number" && Number.isFinite(value) ? clamp(value, lo, hi) : fallback;
}
