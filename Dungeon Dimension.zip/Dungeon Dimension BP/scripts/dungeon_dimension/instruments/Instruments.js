import { world, system } from "@minecraft/server";

import { VibrationManager } from "../blocks/tuning_fork/VibrationManager.js";
import { strikeMatchingForks } from "../blocks/tuning_fork/TuningFork.js";
import { pitchOf, soundOf } from "../blocks/tuning_fork/notes.js";
import { cancelRingOut, ringOut } from "../utils/sustain.js";
import {
	LENGTH_CHOICES,
	MAX_EVENTS,
	MAX_TEXT,
	clipMelody,
	formatMelody,
	parseMelody,
	soundedEvents,
	totalBeats
} from "./melody.js";
import {
	INSTRUMENTS,
	getHeld,
	isInstrument,
	readSettings,
	updateHeld,
	updateInSlot,
	writeSettings
} from "./MelodyStore.js";
import { openInstrumentForm } from "./InstrumentForms.js";

/**
 * Instruments — the items listed in MelodyStore.INSTRUMENTS — play a melody
 * stored on the item.
 *
 *   hold use        plays, and keeps looping for as long as it is held
 *   sneak + use     opens the tab
 *
 * Every note also reaches out: a fork tuned to that exact note, octave and
 * timbre rings when the note sounds, and then resonates down its own chain. A
 * note carrying a `:tone` rings forks of that timbre instead of the
 * instrument's, which is how one harp can drive forks set to bells.
 *
 * A melody can be typed into the tab, or recorded from the world — arm the
 * record switch and strike tuning forks, and the instrument writes down which
 * note each one rang and how long you waited between them. That is the same
 * vibration stream sculk sensors read, so the forks need no special casing.
 */

/** Wording for anything the player is told; the text itself is in RP/texts/*.lang. */
const t = (name) => ({ translate: `text.dd:${name}.name` });

/** How far a played note reaches when looking for forks to ring. */
const FORK_REACH = 16;

/** How far from the player a fork has to be for the recorder to hear it. */
const RECORD_RADIUS = 24;

/** Recording stops and saves itself after this long with nothing played. */
const RECORD_TIMEOUT = 200;

/** Longest a recorded note is held before the rest of the gap becomes a rest. */
const MAX_RECORDED_NOTE = 2;
const MIN_RECORDED_NOTE = 0.25;

/** Silence between loops, so a repeated melody does not run into itself. */
const LOOP_GAP_BEATS = 1;

/** playerId -> playback in flight */
const playing = new Map();

/** playerId -> armed recorder */
const recording = new Map();

/** playerId -> how the last recording ended, repeated when the tab was covering it */
const recordingOutcome = new Map();

/* ─── Playback ───────────────────────────────────────────────────────────── */

/**
 * Starts playing, and keeps looping until the player lets go.
 *
 * The schedule is absolute: every note carries the beat it starts on, so two
 * notes sharing a start time sound together as a chord.
 */
function startPlayback(player, typeId, settings) {
	const { events } = parseMelody(settings.melody);
	const sounded = soundedEvents(events);

	if (sounded.length === 0) {
		actionBar(player, { rawtext: [{ text: "§7" }, t("msg_no_melody"), { text: "§r" }] });
		return;
	}

	const instrumentTone = INSTRUMENTS[typeId].tone;

	const schedule = sounded.map((event) => ({
		at: Math.round(event.start * settings.tempo),
		ticks: Math.max(1, Math.round(event.beats * settings.tempo)),
		note: event.note,
		octave: event.octave,
		tone: event.tone === null ? instrumentTone : event.tone
	}));
	schedule.sort((a, b) => a.at - b.at);

	playing.set(player.id, {
		start: system.currentTick,
		schedule,
		index: 0,
		loopTicks: Math.max(1, Math.round((totalBeats(events) + LOOP_GAP_BEATS) * settings.tempo))
	});
}

function stopPlayback(playerId) {
	cancelRingOut(playerId);
	return playing.delete(playerId);
}

function advancePlayback(now) {
	if (playing.size === 0) return;

	for (const [id, state] of playing) {
		const player = playerById(id);
		if (!player || !getHeld(player)) {
			playing.delete(id);
			continue;
		}

		while (state.index < state.schedule.length && state.start + state.schedule[state.index].at <= now) {
			sound(player, state.schedule[state.index++]);
		}

		if (state.index >= state.schedule.length && now - state.start >= state.loopTicks) {
			state.start = now;
			state.index = 0;
		}
	}
}

function sound(player, event) {
	const pitch = pitchOf(event.note, event.octave);

	ringOut({ player }, soundOf(event.tone), pitch, event.ticks);

	try {
		strikeMatchingForks(
			player.dimension,
			player.location,
			{ note: event.note, octave: event.octave, tone: event.tone },
			FORK_REACH
		);
	} catch (error) {
		console.warn(`[instruments] forks: ${error}`);
	}
}

/* ─── Recording ──────────────────────────────────────────────────────────── */

/**
 * Arms the recorder on the instrument in the player's hand.
 *
 * Only the slot is kept, not the timing. Rings are stored as ticks and become
 * beats when the recording is saved, with the tempo, quantize and length the
 * instrument has at that moment — so a recording stopped from the tab uses the
 * settings made in that same tab, and still sounds the way it was played.
 */
function startRecording(player) {
	stopPlayback(player.id);

	recording.set(player.id, {
		slot: player.selectedSlotIndex,
		start: null,
		last: system.currentTick,
		captured: [],
		seen: new Set()
	});

	actionBar(player, { rawtext: [{ text: "§c" }, t("msg_record_armed"), { text: "§r" }] });
}

/** Picks up every fork ring that happened near an armed player this tick. */
function collectRings(now) {
	if (recording.size === 0) return;

	const vibrations = VibrationManager.getAll().filter((v) => v.cause === "tuning_fork_ring");

	for (const [id, state] of recording) {
		const player = playerById(id);
		if (!player) {
			recording.delete(id);
			continue;
		}

		if (player.selectedSlotIndex !== state.slot || !getHeld(player)) {
			finishRecording(player);
			continue;
		}

		for (const vibration of vibrations) {
			if (state.captured.length >= MAX_EVENTS) break;
			if (vibration.dimension && vibration.dimension !== player.dimension.id) continue;

			const note = vibration.data?.note;
			const octave = vibration.data?.octave;
			if (typeof note !== "number" || typeof octave !== "number") continue;

			if (vibration.data.hops > 0) continue;

			const key = `${vibration.vibration.x},${vibration.vibration.y},${vibration.vibration.z}@${vibration.tickCreated}`;
			if (state.seen.has(key)) continue;

			const dx = vibration.vibration.x + 0.5 - player.location.x;
			const dy = vibration.vibration.y + 0.5 - player.location.y;
			const dz = vibration.vibration.z + 0.5 - player.location.z;
			if (dx * dx + dy * dy + dz * dz > RECORD_RADIUS * RECORD_RADIUS) continue;

			state.seen.add(key);
			if (state.start === null) state.start = vibration.tickCreated;

			state.captured.push({
				ticks: Math.max(0, vibration.tickCreated - state.start),
				note,
				octave,
				tone: vibration.data.tone
			});
			state.last = now;

			actionBar(player, { rawtext: [{ text: "§c" }, t("msg_recording"), { text: `§r §7${state.captured.length} ` }, t("roll_notes"), { text: "§r" }] });
		}

		const full = state.captured.length >= MAX_EVENTS;
		const quiet = state.start !== null && now - state.last > RECORD_TIMEOUT;
		if (full || quiet) finishRecording(player);
	}
}

/**
 * Ends the recording and saves it onto the instrument it was started on.
 *
 * Every way a recording ends comes through here — the tab, the timeout, a full
 * recorder, switching away — and each one tells the player how it went,
 * including when the instrument is no longer in its slot to take the melody.
 */
function finishRecording(player) {
	const state = recording.get(player.id);
	recording.delete(player.id);
	if (!state) return;

	if (state.captured.length === 0) {
		reportRecording(player, { rawtext: [{ text: "§7" }, t("msg_record_empty"), { text: "§r" }] });
		return;
	}

	let notes = 0;
	let clipped = false;

	const saved = updateInSlot(player, state.slot, (stack) => {
		const text = formatMelody(capturedToEvents(state.captured, readSettings(stack), INSTRUMENTS[stack.typeId].tone));
		const melody = clipMelody(text);

		writeSettings(stack, { melody });
		notes = soundedEvents(parseMelody(melody).events).length;
		clipped = melody.length < text.length || state.captured.length >= MAX_EVENTS;
	});

	if (!saved) {
		reportRecording(player, { rawtext: [{ text: "§c" }, t("msg_save_failed"), { text: "§r" }] });
		return;
	}

	reportRecording(player, { rawtext: [{ text: "§a" }, t("msg_recorded"), { text: `§f ${notes}§a ` }, t("roll_notes"), { text: "§r" }] });
	if (clipped) tellTruncated(player);
}

/**
 * Turns recorded rings into melody events.
 *
 * Ticks become beats through the instrument's tempo, rounded to whole beats when
 * quantize is on. Starts are written down as they happened, so forks struck
 * together come back as a chord. A note is held until the next one starts,
 * which is what makes a recording sound played rather than like a row of equal
 * beeps; anything longer than MAX_RECORDED_NOTE becomes a note plus silence. The
 * last note has nothing after it to measure against and is held for the length
 * picked in the tab. A fork whose timbre is not the instrument's own is written
 * with an explicit `:tone`.
 */
function capturedToEvents(captured, settings, instrumentTone) {
	const rings = captured
		.map((ring) => {
			const beat = ring.ticks / settings.tempo;
			return { ...ring, beat: settings.quantize ? Math.round(beat) : beat };
		})
		.sort((a, b) => a.beat - b.beat);

	const lastLength = LENGTH_CHOICES[settings.lengthIndex] ?? 1;
	const events = [];

	for (let i = 0; i < rings.length; i++) {
		const current = rings[i];

		let next = rings[i + 1];
		let step = 1;
		while (next && next.beat === current.beat) next = rings[i + ++step];

		const beats = next
			? clamp(round2(next.beat - current.beat), MIN_RECORDED_NOTE, MAX_RECORDED_NOTE)
			: lastLength;
		const tone = typeof current.tone === "number" && current.tone !== instrumentTone ? current.tone : null;

		events.push({
			note: current.note,
			octave: current.octave,
			beats,
			tone,
			start: round2(current.beat),
			pinned: true
		});
	}

	return events;
}

/* ─── The tab ────────────────────────────────────────────────────────────── */

async function openTab(player) {
	const held = getHeld(player);
	if (!held) return;

	const settings = readSettings(held);
	const typeId = held.typeId;
	const session = recording.get(player.id);

	const result = await openInstrumentForm(player, {
		nameKey: INSTRUMENTS[typeId].nameKey,
		ui: INSTRUMENTS[typeId].ui,
		melody: settings.melody,
		name: settings.name,
		tempo: settings.tempo,
		lengthIndex: settings.lengthIndex,
		quantize: settings.quantize,
		recording: session !== undefined
	});

	if (!result) return;

	const endedMeanwhile = session !== undefined && recording.get(player.id) !== session;

	const saved = updateHeld(player, (stack) => writeSettings(stack, {
		melody: endedMeanwhile ? undefined : result.melody,
		name: result.name,
		tempo: result.tempo,
		lengthIndex: result.lengthIndex,
		quantize: result.quantize
	}));

	if (!saved) {
		actionBar(player, { rawtext: [{ text: "§c" }, t("msg_save_failed"), { text: "§r" }] });
		return;
	}

	if (endedMeanwhile) {
		const outcome = recordingOutcome.get(player.id);
		if (outcome) actionBar(player, outcome);
		return;
	}

	const stored = clipMelody(result.melody);
	if (stored.length < result.melody.length) tellTruncated(player);

	const { errors } = parseMelody(stored);
	if (errors.length > 0) {
		player.sendMessage({ rawtext: [{ text: "§c" }, t("msg_bad_tokens"), { text: `§r ${errors.slice(0, 8).join(" ")}` }] });
	}

	if (result.record && !session) {
		startRecording(player);
	} else if (!result.record && session) {
		finishRecording(player);
	}
}

/* ─── Wiring ─────────────────────────────────────────────────────────────── */

world.afterEvents.itemStartUse.subscribe((e) => {
	const { itemStack, source } = e;
	if (!itemStack || !isInstrument(itemStack.typeId)) return;
	if (!source || source.typeId !== "minecraft:player") return;

	if (source.isSneaking) {
		system.run(() => {
			openTab(source).catch((error) => console.warn(`[instruments] tab: ${error}`));
		});
		return;
	}

	if (recording.has(source.id)) return;

	system.run(() => {
		const held = getHeld(source);
		if (!held) return;
		startPlayback(source, held.typeId, readSettings(held));
	});
});

world.afterEvents.itemStopUse.subscribe((e) => {
	if (!e.source || e.source.typeId !== "minecraft:player") return;
	stopPlayback(e.source.id);
});

world.afterEvents.itemCompleteUse.subscribe((e) => {
	if (!e.source || e.source.typeId !== "minecraft:player") return;
	stopPlayback(e.source.id);
});

world.afterEvents.playerLeave.subscribe((e) => {
	playing.delete(e.playerId);
	recording.delete(e.playerId);
	recordingOutcome.delete(e.playerId);
});

system.runInterval(() => {
	const now = system.currentTick;
	advancePlayback(now);
	collectRings(now);
}, 1);

/* ─── Helpers ────────────────────────────────────────────────────────────── */

function playerById(id) {
	for (const player of world.getAllPlayers()) {
		if (player.id === id) return player;
	}
	return undefined;
}

function actionBar(player, text) {
	try {
		player.onScreenDisplay.setActionBar(text);
	} catch { /* player left */ }
}

/** Shows how a recording ended and keeps it, for a tab that was open at the time. */
function reportRecording(player, text) {
	recordingOutcome.set(player.id, text);
	actionBar(player, text);
}

function tellTruncated(player) {
	try {
		player.sendMessage({ rawtext: [{ text: "§c" }, t("msg_truncated"), { text: ` §f(${MAX_TEXT})§r` }] });
	} catch { /* player left */ }
}

const round2 = (v) => Number(v.toFixed(2));
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
