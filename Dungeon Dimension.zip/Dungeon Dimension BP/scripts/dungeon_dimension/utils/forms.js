import { system } from "@minecraft/server";
import { FormCancelationReason } from "@minecraft/server-ui";

const RETRY_TICKS = 5;
const MAX_RETRIES = 40;

/**
 * Shows a form once the player is able to receive one.
 *
 * A form cannot open while the player is mid-interaction, and the interact
 * event fires exactly then — the first `show` comes straight back cancelled
 * with UserBusy. Retry until they are free, then give up quietly rather than
 * leaving a form pending forever.
 *
 * @returns the form response, or undefined if the player never became free.
 */
export async function showWhenFree(form, player) {
	for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
		const response = await form.show(player);

		if (response.canceled && response.cancelationReason === FormCancelationReason.UserBusy) {
			await system.waitTicks(RETRY_TICKS);
			continue;
		}
		return response;
	}
	return undefined;
}
