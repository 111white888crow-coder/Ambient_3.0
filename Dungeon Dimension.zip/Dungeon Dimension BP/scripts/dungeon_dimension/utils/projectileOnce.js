/**
 * Один удар на снаряд.
 *
 * Стрела втыкается в блок и остаётся в нём торчать — так и должно быть. Но
 * попадание засчитывается ей снова и снова: блок на каждое срабатывание меняет
 * перестановку (прячет и возвращает кости), торчащая стрела всякий раз заново
 * упирается в него, и блок срабатывает без остановки. У колокола это слышно
 * прямо: звон без конца.
 *
 * Здесь удар считается один раз на снаряд. Стрела спокойно висит в блоке,
 * больше его не трогая; новый выстрел — новый снаряд, новое срабатывание.
 *
 * Память общая, но раздельная по метке: стрела, позвонившая в колокол, всё ещё
 * может качнуть горшок. Номера протухают через пару минут и чистятся прямо при
 * обходе — стрела живёт около минуты, дольше помнить её незачем, а карта не
 * растёт.
 */
import { system } from "@minecraft/server";

const MEMORY = 2400;
const seen = new Map();

/**
 * @param {import("@minecraft/server").Entity | undefined} projectile
 * @param {string} tag чей это счёт — у каждого блока свой
 * @returns {boolean} первый ли это удар этого снаряда по такому блоку
 */
export function firstHit(projectile, tag) {
	const id = projectile?.id;
	if (id === undefined) return true;

	const key = `${tag}|${id}`;
	const now = system.currentTick;
	for (const [old, tick] of seen) if (now - tick >= MEMORY) seen.delete(old);

	if (seen.has(key)) return false;
	seen.set(key, now);
	return true;
}
