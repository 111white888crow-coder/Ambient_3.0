/**
 * Сущность на время анимации.
 *
 * Блок анимировать нельзя, сущность можно. Раньше у колокола, камертона и
 * горшка сущность висела при блоке всегда — и всё время норовила потеряться:
 * взрыв, `/kill @e`, лимит сущностей, чужой аддон. Приходилось её сторожить:
 * тег хозяина, снятие дублей, обход сирот, досмотр вокруг игроков.
 *
 * Эталонный Create делает иначе (`Create (BE)/blocks/create/utilities/
 * desk_bell.b.json` и `entities/create/support/desk_bell.bpe.json`): колокольчик
 * при нажатии на мгновение становится мобом и тут же возвращается блоком.
 *
 *   — блок рисует себя сам и прячет только те кости, которые сейчас двигаются;
 *   — сущность заводится на удар, играет и **гасит себя сама**: у неё
 *     `minecraft:timer`, по нему событие, событие вешает группу с
 *     `minecraft:instant_despawn`. Скрипту для этого делать нечего;
 *   — скрипт возвращает кости блоку, когда анимация кончилась.
 *
 * Сторожить больше нечего: сущности между ударами просто нет. Потерять её можно
 * только в те полсекунды, пока она играет, — и это ничем не кончится, потому
 * что через мгновение блок и так забирает кости назад.
 */
import { world, system } from "@minecraft/server";

/** Состояние «сейчас играет сущность»: по нему блок прячет свои кости. */
export const BUSY_STATE = "dd:has_entity";

/**
 * Семейство всех служебных сущностей-подменышей. По нему клетку можно вычистить,
 * не зная, чей это блок, — этим пользуется уборка после поршня.
 */
export const BLOCK_ENTITY_FAMILY = "dd_block_entity";

const floorOf = (location) => ({ x: Math.floor(location.x), y: Math.floor(location.y), z: Math.floor(location.z) });

/** Сущность стоит в середине клетки, на её полу. */
export function anchorOf(location) {
	const { x, y, z } = floorOf(location);
	return { x: x + 0.5, y, z: z + 0.5 };
}

/** Играет ли сейчас сущность при этом блоке. */
export function isBusy(block) {
	try { return block.permutation.getState(BUSY_STATE) === true; }
	catch { return false; }
}

function setBusy(block, busy) {
	try {
		const perm = block.permutation;
		if (perm.getState(BUSY_STATE) === busy) return;
		block.setPermutation(perm.withState(BUSY_STATE, busy));
	} catch { /* блок ушёл */ }
}

/** Снимает всех, кто стоит в клетке блока: слом, взрыв, замена. */
export function removeBlockEntity(dimension, location, entityType) {
	try {
		for (const entity of dimension.getEntities({ type: entityType, location: anchorOf(location), maxDistance: 0.5 })) {
			entity.remove();
		}
	} catch { /* чанк выгружен */ }
}

/** Есть ли сейчас в клетке хоть один подменыш — чей угодно. */
function cellHasEntity(dimension, location) {
	try {
		for (const _ of dimension.getEntities({ families: [BLOCK_ENTITY_FAMILY], location: anchorOf(location), maxDistance: 0.5 })) return true;
	} catch { return true; /* не видно — считаем, что занято, и не трогаем */ }
	return false;
}

/** Снимает из клетки любого подменыша, не спрашивая, чей это блок. */
function clearCell(dimension, location) {
	try {
		for (const entity of dimension.getEntities({ families: [BLOCK_ENTITY_FAMILY], location: anchorOf(location), maxDistance: 0.5 })) {
			entity.remove();
		}
	} catch { /* чанк выгружен */ }
}

const cellKey = (dimension, location) => {
	const { x, y, z } = floorOf(location);
	return `${dimension.id}|${x},${y},${z}`;
};

/**
 * Что сейчас играет в клетке: `{ id, dimension, location, entityType, ownerType }`.
 *
 * По номеру `id` отложенный конец понимает, что его уже сменил новый удар:
 * старый счётчик молча уходит, а гасит сущность и возвращает кости блоку только
 * самый свежий. Без этого повторное нажатие обрывалось бы на чужом сроке —
 * старый конец снимал бы только что заведённую сущность.
 *
 * Остальное нужно стражу (ниже): по нему он каждый тик смотрит, стоит ли ещё
 * блок в своей клетке.
 *
 * Ключ живёт ровно от удара до его конца и стирается там же, так что карта не
 * растёт.
 */
const sessions = new Map();

/**
 * Номера сквозные, а не свои на каждую клетку: клетку можно оборвать досрочно
 * (поршень) и завести в ней игру заново, и при отсчёте с нуля старый конец
 * совпал бы номером с новой игрой и оборвал её.
 */
let nextSession = 0;

/**
 * Страж играющих клеток.
 *
 * Сущность не блок и с блоком никуда не едет. Поршень уносит блок, а она
 * остаётся висеть в воздухе на всю анимацию, и вместе с блоком уезжает
 * состояние «сейчас играет сущность» — на новом месте блок так и стоит с
 * припрятанными костями.
 *
 * Событие поршня об этом рассказывает (оно ниже и срабатывает раньше, в тот же
 * тик), но верить одному ему нельзя: у него свои причуды со списком увозимых
 * блоков, а клетку блок может покинуть и без поршня — слом, взрыв, `setblock`,
 * чужой аддон. Поэтому пока хоть что-то играет, каждый тик проверяется простое:
 * тот ли блок всё ещё стоит в клетке. Нет — сущность снимается сразу, а кости
 * возвращаются тому, кто уехал.
 *
 * Обходятся только играющие клетки, а их в мире считанные единицы и лишь
 * полсекунды каждая, так что обход пустой почти всегда — и тогда страж сам
 * останавливается.
 */
let watch;

function startWatch() {
	if (watch !== undefined) return;

	watch = system.runInterval(() => {
		if (sessions.size === 0) {
			system.clearRun(watch);
			watch = undefined;
			return;
		}

		for (const [key, play] of sessions) {
			let owner;
			try { owner = play.dimension.getBlock(play.location); }
			catch { continue; /* чанк выгружен — блок никуда не делся, просто не виден */ }

			if (owner === undefined || owner.typeId === play.ownerType) continue;

			abortPlay(key, play);
		}
	}, 1);
}

/** Снимает сущность по самой сущности, а не по клетке: где бы она ни оказалась. */
function dropEntity(entity) {
	try { entity?.remove(); } catch { /* уже снята или чанк выгружен */ }
}

/**
 * Блок покинул клетку. Сущность снимается, кости возвращаются тому, кто уехал.
 *
 * Сущность снимается дважды: сперва по ссылке — так надёжнее всего, потому что
 * искать её больше не надо, — потом обходом клетки, на случай если в ней остался
 * чужой подменыш (например, от прошлого запуска, который не успели прибрать).
 */
function abortPlay(key, play) {
	if (sessions.get(key)?.id === play.id) sessions.delete(key);

	dropEntity(play.entity);
	clearCell(play.dimension, play.location);
	releaseAround(play.dimension, play.location);
}

/**
 * Игра кончается досрочно, а блок на месте: снимаем сущность и тут же возвращаем
 * ему кости. Так обрывается анимация, когда в подменыша попал снаряд.
 */
function endPlay(key, play) {
	if (sessions.get(key)?.id === play.id) sessions.delete(key);

	dropEntity(play.entity);
	clearCell(play.dimension, play.location);

	let owner;
	try { owner = play.dimension.getBlock(play.location); } catch { return; }
	if (owner?.typeId === play.ownerType) setBusy(owner, false);
}

/**
 * Заводит сущность на одну анимацию.
 *
 * Повторный удар не отбрасывается: прежняя сущность снимается, новая заводится
 * с начала анимации. Так ведут себя и ванильный колокол, и колокольчик из
 * эталонного Create — по ним можно бить сколько угодно часто.
 *
 * @param {import("@minecraft/server").Block} block
 * @param {string} entityType
 * @param {number} ticks сколько длится анимация
 * @param {(entity: import("@minecraft/server").Entity) => void} [setup]
 *   что рассказать сущности о блоке: поворот, уровень, какую анимацию играть
 * @returns {boolean} завелась ли
 */
export function playBlockEntity(block, entityType, ticks, setup) {
	if (!block) return false;

	const dimension = block.dimension;
	const location = { ...block.location };
	const ownerType = block.typeId;
	const key = cellKey(dimension, location);
	const session = ++nextSession;
	sessions.set(key, { id: session, dimension, location, entityType, ownerType });
	startWatch();

	removeBlockEntity(dimension, location, entityType);

	const anchor = anchorOf(location);

	let entity;
	try { entity = dimension.spawnEntity(entityType, anchor); }
	catch (error) {
		console.warn(`[blockEntity] ${entityType}: ${error}`);
		if (sessions.get(key)?.id === session) sessions.delete(key);
		return false;
	}

	/* Сама сущность, а не только её клетка: снять её потом можно будет по ссылке,
	   даже если её к тому времени отнесло от места, где завели */
	const play = sessions.get(key);
	if (play?.id === session) play.entity = entity;

	try { entity.teleport(anchor); } catch { /* ушла между спавном и посадкой */ }

	if (setup) {
		try { setup(entity); }
		catch (error) { console.warn(`[blockEntity] настройка ${entityType}: ${error}`); }
	}

	setBusy(block, true);

	system.runTimeout(() => {
		if (sessions.get(key)?.id !== session) return;

		let owner;
		try { owner = dimension.getBlock(location); } catch { owner = undefined; }
		if (owner !== undefined) setBusy(owner, false);

		system.runTimeout(() => {
			if (sessions.get(key)?.id !== session) return;
			sessions.delete(key);
			dropEntity(entity);
			removeBlockEntity(dimension, location, entityType);
		}, 1);
	}, Math.max(1, ticks));

	return true;
}

/* ─── Снаряды ────────────────────────────────────────────────────────────── */

/** Наш ли это подменыш — спрашиваем у самой сущности, а не у клетки. */
function isBlockEntity(entity) {
	try { return entity.getComponent("minecraft:type_family")?.hasTypeFamily(BLOCK_ENTITY_FAMILY) === true; }
	catch { return false; }
}

/**
 * Стрела, попавшая в подменыша, не может приземлиться.
 *
 * У ванильной стрелы `should_bounce: "if_no_damage_dealt"`, а подменыш урона не
 * принимает (`damage_sensor` с `deals_damage: "no"`) — значит отскок. Стрела
 * отлетает, падает обратно в тот же хитбокс, снова отскакивает и так дёргается
 * на месте, вместо того чтобы воткнуться в колокол.
 *
 * Правильное лечение — чтобы снаряд в подменыша вовсе не попадал: у сущностей
 * стоит `minecraft:custom_hit_test` с хитбоксом 0×0, как у сиденья в эталонном
 * Create. Но если движок этот хитбокс всё-таки раздувает, отскок остаётся, и
 * тогда спасает только одно: убрать подменыша с дороги. Анимация обрывается на
 * полудвижении — это заметно, но лучше, чем стрела, дрожащая в воздухе.
 *
 * Сама сущность на попадание снаряда тоже гасит себя, через `on_damage` в
 * `damage_sensor`. Сработает любой из двух путей — стрела упадёт.
 */
world.afterEvents.projectileHitEntity.subscribe((event) => {
	let entity;
	try { entity = event.getEntityHit?.()?.entity; } catch { return; }
	if (entity === undefined || !isBlockEntity(entity)) return;

	let key;
	try { key = cellKey(entity.dimension, entity.location); } catch { dropEntity(entity); return; }

	const play = sessions.get(key);
	if (play === undefined) { dropEntity(entity); return; }

	endPlay(key, play);
});

/* ─── Ничьи подменыши ────────────────────────────────────────────────────── */

/** Как часто искать подменышей, которых никто не заводил. */
const SWEEP_INTERVAL = 20;

/**
 * Подметание.
 *
 * Всё выше снимает сущность там, где её оставили, — но ровно поэтому оно
 * бессильно, если сущность оказалась не там: её отнесло, клетку посчитали не ту,
 * скрипт перезапустился и забыл про неё. Такой подменыш висит в воздухе, пока не
 * догорит его собственный таймер, а если и с таймером что-то не так — то и
 * вовсе.
 *
 * Подметание не разбирается, как так вышло: подменыш, в чьей клетке сейчас никто
 * не играет, — ничей, и его снимают. Раз в секунду и только в тех измерениях, где
 * стоят игроки: в других чанки всё равно выгружены и сущностей там не видно.
 */
system.runInterval(() => {
	const dimensions = new Map();
	for (const player of world.getAllPlayers()) {
		try { dimensions.set(player.dimension.id, player.dimension); }
		catch { /* игрок вышел */ }
	}

	for (const dimension of dimensions.values()) {
		let strays;
		try { strays = dimension.getEntities({ families: [BLOCK_ENTITY_FAMILY] }); }
		catch { continue; }

		for (const entity of strays) {
			let key;
			try { key = cellKey(dimension, entity.location); } catch { continue; }
			if (sessions.has(key)) continue;
			dropEntity(entity);
		}
	}
}, SWEEP_INTERVAL);

/* ─── Уехавшие блоки ─────────────────────────────────────────────────────── */

/**
 * Поршень уносит блок, а сущность остаётся стоять где стояла: она не блок и с
 * ним не едет. Своим таймером она бы догорела за пару секунд, но эти секунды
 * видно — посреди воздуха висит колокол.
 *
 * Хуже другое: состояние «сейчас играет сущность» уезжает вместе с блоком. На
 * новом месте блок так и остался бы с припрятанными костями, и вернуть их
 * некому — отложенный конец сторожит прежнюю клетку.
 *
 * Поэтому клетки, которые блоки покинули, чистятся от подменышей, а блоки,
 * доехавшие занятыми, но без сущности, отпускаются. Зовётся это двумя путями: с
 * события поршня — чтобы оборвать игру в тот же миг, и от стража выше — чтобы
 * ничего не потерялось, если событие соврало или блок унесло не поршнем.
 */
const NEIGHBOURS = [
	{ x: 0, y: -1, z: 0 },
	{ x: 0, y: 1, z: 0 },
	{ x: 0, y: 0, z: -1 },
	{ x: 0, y: 0, z: 1 },
	{ x: -1, y: 0, z: 0 },
	{ x: 1, y: 0, z: 0 }
];

const shift = (location, step) => ({
	x: location.x + step.x,
	y: location.y + step.y,
	z: location.z + step.z
});

/**
 * Обрывает игру в клетке немедленно: отложенный конец обезличивается, сущность
 * снимается, кости возвращаются блоку. Зовётся, пока блок ещё на месте.
 */
function abortCell(dimension, location) {
	sessions.delete(cellKey(dimension, location));
	clearCell(dimension, location);

	let block;
	try { block = dimension.getBlock(location); } catch { return; }
	if (block !== undefined) setBusy(block, false);
}

/** Доехал занятым, а сущности при нём нет — значит занятость приехала зря. */
function releaseStuck(dimension, location) {
	let block;
	try { block = dimension.getBlock(location); } catch { return; }
	if (block === undefined || !isBusy(block)) return;
	if (cellHasEntity(dimension, location)) return;
	setBusy(block, false);
}

/**
 * Ищет уехавший блок вокруг покинутой клетки и возвращает ему кости.
 *
 * Куда именно он уехал, знать не нужно: поршень двигает ровно на клетку, так что
 * осмотреть достаточно шесть соседних. Занятый блок, при котором нет сущности,
 * может быть только тем самым, кто увёз состояние с собой, — у играющего соседа
 * сущность на месте, и его `releaseStuck` не трогает.
 *
 * Дважды, потому что поршень ходит не мгновенно: на третий тик блок уже обычно
 * доехал, но если чанк тяжёлый, то ещё нет.
 */
function releaseAround(dimension, location) {
	const sweep = () => {
		releaseStuck(dimension, location);
		for (const step of NEIGHBOURS) releaseStuck(dimension, shift(location, step));
	};

	system.runTimeout(sweep, 3);
	system.runTimeout(sweep, 8);
}

world.afterEvents.pistonActivate.subscribe((event) => {
	const dimension = event.dimension;

	let moved;
	try { moved = event.piston.getAttachedBlocksLocations(); } catch { return; }
	if (!moved || moved.length === 0) return;

	const cells = moved.map((location) => ({ ...location }));

	/* Событие приходит, когда блоки ещё не тронулись с места, — гасим прямо
	   здесь, чтобы играющий блок переставал играть в тот же миг, а не доезжал
	   с сущностью, оставленной позади. Дальше клетки осматривает та же уборка,
	   что и у стража: куда поршень толкал, выяснять не нужно */
	for (const from of cells) {
		abortCell(dimension, from);
		releaseAround(dimension, from);
	}
});
