import { LiquidType } from "@minecraft/server";
import { NOT_FULL, STAIRS, WEIRDO_DIRECTION, matches } from "../data/blockSets.js";

export function shapeFromStates(states, face) {
    if (!states) return null;

    if (states["dd:block_bit"] === true) return true;

    if (states.open_bit === true || states["dd:open_bit"] === true) return false;

    if (typeof states["minecraft:vertical_half"] === "string") {
        return face === "down" && states["minecraft:vertical_half"] === "bottom";
    }

    if (typeof states.upside_down_bit === "boolean") {
        return face === "down" && states.upside_down_bit === false;
    }

    if (typeof states.open_bit === "boolean" || typeof states["dd:open_bit"] === "boolean") return false;

    return null;
}

const STAIR_SIDES = {
    north: { left: "west", right: "east" },
    south: { left: "east", right: "west" },
    east: { left: "north", right: "south" },
    west: { left: "south", right: "north" }
};

const STAIR_AXIS = { north: "z", south: "z", east: "x", west: "x" };
const STAIR_OPPOSITE = { north: "south", south: "north", east: "west", west: "east" };
const STAIR_STEP = {
    north: { x: 0, y: 0, z: -1 },
    south: { x: 0, y: 0, z: 1 },
    east: { x: 1, y: 0, z: 0 },
    west: { x: -1, y: 0, z: 0 }
};

function stairInfo(block) {
    if (!block) return null;
    let states;
    try { states = block.permutation.getAllStates(); } catch { return null; }

    if (typeof states.weirdo_direction === "number") {
        const facing = WEIRDO_DIRECTION[states.weirdo_direction];
        return facing ? { facing, top: states.upside_down_bit === true, states } : null;
    }

    const facing = states["minecraft:cardinal_direction"];
    if (typeof facing !== "string" || !STAIR_SIDES[facing]) return null;

    let isStair = matches(block.typeId, STAIRS);
    if (!isStair) {
        try { isStair = block.hasTag("custom:stairs") || block.hasTag("dd:stairs"); } catch { }
    }
    if (!isStair) return null;

    return { facing, top: states["minecraft:vertical_half"] === "top", states };
}

function stairNeighbour(block, direction) {
    try { return block.offset(STAIR_STEP[direction]); } catch { return undefined; }
}

function canTakeShape(block, info, direction) {
    const other = stairInfo(stairNeighbour(block, direction));
    return !other || other.facing !== info.facing || other.top !== info.top;
}

function computeStairShape(block, info) {
    const front = stairInfo(stairNeighbour(block, info.facing));
    if (front && front.top === info.top && STAIR_AXIS[front.facing] !== STAIR_AXIS[info.facing]
        && canTakeShape(block, info, STAIR_OPPOSITE[front.facing])) {
        return front.facing === STAIR_SIDES[info.facing].left ? "outer_left" : "outer_right";
    }

    const back = stairInfo(stairNeighbour(block, STAIR_OPPOSITE[info.facing]));
    if (back && back.top === info.top && STAIR_AXIS[back.facing] !== STAIR_AXIS[info.facing]
        && canTakeShape(block, info, back.facing)) {
        return back.facing === STAIR_SIDES[info.facing].left ? "inner_left" : "inner_right";
    }

    return "none";
}

export function stairShape(block) {
    const info = stairInfo(block);
    return info ? computeStairShape(block, info) : null;
}

const SIDE_BIT_SHAPE = {
    normal: "none",
    front_left: "inner_left",
    front_right: "inner_right",
    behind_left: "outer_left",
    behind_right: "outer_right"
};

export function stairFullFaces(block, states) {
    const info = stairInfo(block);
    if (!info) return null;

    const source = states || info.states;
    const shape =
        source["minecraft:corner"] ??
        SIDE_BIT_SHAPE[source["dd:side_bit"]] ??
        computeStairShape(block, info);

    const { left, right } = STAIR_SIDES[info.facing];
    switch (shape) {
        case "outer_left":
        case "outer_right": return [];
        case "inner_left": return [info.facing, left];
        case "inner_right": return [info.facing, right];
        default: return [info.facing];
    }
}

const DOUBLE_SLAB = /double.*slab/;

export function faceIsFull(block, states, face) {
    let isLiquid;
    try { isLiquid = block.isLiquid; } catch { return false; }
    if (isLiquid) return false;

    if (DOUBLE_SLAB.test(block.typeId)) return true;

    const byStates = shapeFromStates(states, face);
    if (byStates !== null) return byStates;

    if (matches(block.typeId, NOT_FULL)) return false;

    try { return block.isLiquidBlocking(LiquidType.Water); } catch { return false; }
}

export function isSolidLike(block) {
    if (!block) return false;

    let isAir;
    try { isAir = block.isAir; } catch { return false; }
    if (isAir) return false;

    let states;
    try { states = block.permutation.getAllStates(); } catch { return false; }

    return faceIsFull(block, states, "cube");
}

export function safeOffset(block, offset) {
    try { return block.offset(offset); } catch { return undefined; }
}
