/**
 * Ring-out for played notes.
 *
 * Minecraft has no sustain: playSound fires a sample and that is the whole note,
 * so a melody written with long notes sounds exactly like one written with short
 * ones.
 *
 * This used to fake the missing tail by laying a bell under every note — once
 * with the attack and again every fifty ticks. It never sounded like a fade.
 * A sample has its own attack transient, so each layer arrived as another hit:
 * one struck fork answered with a little run of extra notes behind it, and the
 * longer the note the more of them there were. Delaying the first layer only
 * moved the problem. So the layering is gone: **one note is one sample.**
 *
 * The tail is bought the only way that actually works — with a sample that
 * already fades the right way. VOICES lists sounds rendered once per decay time
 * (tools/gen_harp_voice.mjs makes them); a note in such a sound is played from
 * the sample whose fade fits its length, ends on a real string tail, and needs
 * nothing layered over it. A timbre without such a set simply plays dry, the
 * way a note block does.
 */

/**
 * Seconds each harp sample takes to fall silent at pitch 1 — half an octave
 * apart. tools/gen_harp_voice.mjs renders the same list and warns if they differ.
 */
const HARP_DECAYS = [0.35, 0.5, 0.71, 1, 1.41, 2, 2.83, 4, 5.66];

/** Sound -> the samples it is played from, one per decay time. */
const VOICES = {
	"note.harp": HARP_DECAYS.map((decay) => ({
		decay,
		sound: `dd.harp.decay_${String(Math.round(decay * 1000)).padStart(4, "0")}`
	}))
};

/** Shortest fade a voiced note gets, so even a passing note ends softly, in seconds. */
const RELEASE_MIN = 0.35;

/** A plucked string sounds on past its written length: the fade lasts this many times it. */
const RELEASE_STRETCH = 1.6;

/**
 * Plays a note.
 *
 * @param {object} target either `{player}` to play where a player stands, or
 *   `{dimension, location}` to play where the note was struck.
 * @param {string} sound sound event id
 * @param {number} pitch playback pitch
 * @param {number} ticks how long the note should ring for — picks the sample
 *   whose own fade fits, for a sound that has such a set
 * @param {number} [volume]
 */
export function ringOut(target, sound, pitch, ticks, volume = 1) {
	const dimension = target.player?.dimension ?? target.dimension;
	const location = locationOf(target);

	const voice = VOICES[sound];
	play(dimension, location, voice ? voiceSample(voice, pitch, ticks) : sound, pitch, volume);
}

/**
 * The sample of a voice whose fade fits this note best.
 *
 * A sample played at a higher pitch runs faster and ends sooner, so the wanted
 * fade is scaled by the pitch before it is matched. The match is by ratio, not
 * difference: 1 s against 1.4 s is as far off as 2 s against 2.8 s.
 */
function voiceSample(samples, pitch, ticks) {
	const wanted = (RELEASE_MIN + (ticks / 20) * RELEASE_STRETCH) * pitch;

	let best = samples[0];
	for (const sample of samples) {
		if (Math.abs(Math.log(sample.decay / wanted)) < Math.abs(Math.log(best.decay / wanted))) best = sample;
	}
	return best.sound;
}

/**
 * Kept because a stopped melody used to have layers still queued behind it.
 * Nothing is queued any more — a note is over the moment it is played — so there
 * is nothing to drop. The call sites stay as they are.
 */
export function cancelRingOut() { }

function locationOf(target) {
	if (target.player) {
		try {
			return target.player.location;
		} catch {
			return undefined;
		}
	}
	return target.location;
}

function play(dimension, location, sound, pitch, volume) {
	if (!dimension || !location) return;
	try {
		dimension.playSound(sound, location, { volume, pitch });
	} catch { /* chunk unloaded */ }
}
