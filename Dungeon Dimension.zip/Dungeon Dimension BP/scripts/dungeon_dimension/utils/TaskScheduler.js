import { system, world } from "@minecraft/server";

function propKeyOf(block) {
    const { x, y, z } = block.location;
    return `task|${block.dimension.id}|${Math.floor(x)},${Math.floor(y)},${Math.floor(z)}`;
}

export const TaskScheduler = {
    _registry: new Map(),
    _interval: undefined,
    register(id, callback) {
        this._registry.set(id, callback);
    },
    schedule(block, callbackId, delayTicks, data = null) {
        const payload = JSON.stringify({
            id: callbackId,
            t: system.currentTick + delayTicks,
            d: data
        });

        world.setDynamicProperty(propKeyOf(block), payload);
    },
    cancel(block) {
        world.setDynamicProperty(propKeyOf(block), undefined);
    },
    init() {
        if (this._interval !== undefined) return;

        this._interval = system.runInterval(() => {
            const currentTick = system.currentTick;

            for (const propKey of world.getDynamicPropertyIds()) {
                if (!propKey.startsWith("task|")) continue;

                let stored;
                try {
                    stored = JSON.parse(world.getDynamicProperty(propKey));
                } catch { continue; }

                if (currentTick < stored.t) continue;

                const parts = propKey.split("|");
                const coords = parts[2].split(",").map(Number);
                const dim = world.getDimension(parts[1]);

                try {
                    const block = dim.getBlock({ x: coords[0], y: coords[1], z: coords[2] });
                    if (!block) continue;

                    world.setDynamicProperty(propKey, undefined);

                    const callback = this._registry.get(stored.id);
                    if (callback) callback({ block, dimension: dim, data: stored.d });
                } catch (e) {
                }
            }
        }, 1);
    }
};

world.afterEvents.playerJoin.subscribe(async (e) => {
    await system.waitTicks(100);
    TaskScheduler.init();
});
