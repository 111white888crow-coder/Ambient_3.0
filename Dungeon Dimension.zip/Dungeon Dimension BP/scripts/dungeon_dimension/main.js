import {
  world,
  system,
  CustomCommandStatus,
  CustomCommandParamType,
  CommandPermissionLevel
} from "@minecraft/server";
import { EnvelopeLoot } from "./templates/itemsComponents.js";
import "./ddTriggers.js";
import "./templates/_main.js";
import "./blocks/_main.js";
import "./instruments/_main.js";

import "./animations/roll.js";

const ABYSS_ID = "dd:abyss";
const HOME_ID = "overworld";

function hash(x, z, seed) {
  let h = (x * 374761393 + z * 1376312589 + seed * 981237) | 0;
  h = Math.imul(h ^ (h >>> 13), 1540483477);
  h = h ^ (h >>> 15);
  return Math.abs(h);
}

function toChunk(worldCoord) {
  return Math.floor(worldCoord / 16);
}

function chunkKey(cx, cz) {
  return `${cx},${cz}`;
}

function buildPortal(dimension, location) {
    if (!dimension.isChunkLoaded(location)) return;

    const below = dimension.getBlock({ ...location, y: location.y - 1 });
    if (!below || !below.isAir) return;

}

function sendTo(player, target) {
    const destination = arrivalPoint(target, player.location);
    player.teleport(destination, { dimension: target });

    system.runTimeout(() => buildPortal(target, destination), 10);
}

function travel(player) {
    const goingIn = player.dimension.id !== ABYSS_ID;
    sendTo(player, world.getDimension(goingIn ? ABYSS_ID : HOME_ID));
}

system.beforeEvents.startup.subscribe((event) => {
    event.dimensionRegistry.registerCustomDimension(ABYSS_ID);

    event.customCommandRegistry.registerCommand(
        {
            name: 'dd:tp',
            description: 'teleport to the Abyss',
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: true,
            optionalParameters: [
                { name: 'target', type: CustomCommandParamType.PlayerSelector }
            ]
        },
        (origin, target) => {
            const candidates = target?.length ? target : [origin.sourceEntity];
            const player = candidates.filter(
                entity => entity?.isValid && entity.typeId === 'minecraft:player'
            );

            if (player.length === 0)  {
                return { status: CustomCommandStatus.Failure, message: 'No Player' };
            }

            const plan = player.map(player => ({ player, location: { ...player.location } }));

            system.run(() => {
                const abyss = world.getDimension(ABYSS_ID);

                for (const {player, location } of plan) {
                    if (!player.isValid) continue;

                    const destination = arrivalPoint(abyss, location);
                    player.teleport(destination, { dimension: abyss });
                    system.runTimeout(() => buildPortal(abyss, destination), 10);
                }
            });
            return { status: CustomCommandStatus.Success, message: `teleport: ${player.length}` };
        }
    );

    event.blockComponentRegistry.registerCustomComponent("dd:abyss_gate", {
        onPlayerInteract: e => {
            const player = e.player;
            if (!player?.isValid) return;
            system.run(() => travel(player));
        }
    });

    event.itemComponentRegistry.registerCustomComponent("dd:envelope", EnvelopeLoot);
});
