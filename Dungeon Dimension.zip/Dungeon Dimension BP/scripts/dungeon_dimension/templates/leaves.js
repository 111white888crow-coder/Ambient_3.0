import { EquipmentSlot, GameMode, ItemStack, LocationOutOfWorldBoundariesError, system, world } from "@minecraft/server";
import { isSolidLike } from "../utils/blockChecks.js";
import { HANGING_TAG } from "./hanging_leaves.js";

export const DISTANCE_STATE = "dd:distance";
export const PERSISTENT_STATE = "dd:persistent";
export const UPDATE_STATE = "dd:update";
/**
 * Глухая листва: блок, у которого закрыты все шесть сторон, меняет текстуру на
 * `*_opaque` — сплошную, без дыр. Глохнет он целиком, всеми гранями сразу, и
 * только тот, что оказался внутри кучи.
 *
 * Однажды это состояние попробовали расщепить на три — по грани, — решив, что
 * глохнуть должна каждая граница между двумя листвяными клетками. Это неверно:
 * «внутри» относится к блоку, а не к границе, и от кучи в пару блоков тогда
 * оставались сплошные стенки вместо просвечивающей листвы.
 *
 * Причина, по которой у глухого блока было видно всего две-три грани, в другом
 * месте — в каллинге и в двусторонних плоскостях, см.
 * `DD_RP/block_culling/leaves_culling.json`.
 */
export const OPAQUE_STATE = "dd:opaque";

export const MAX_DISTANCE = 7;

const SUPPORT_TAGS = ["log", "dd:log"];

const DRAIN_LIMIT = 4096;

const DECAY_CHANCE = 1;

const DROPS_COMPONENT = "dd:leaves_drops";
const DEFAULT_DROPS = [
    { item: "minecraft:stick", chances: [2, 2.2222, 2.5, 3.3333, 10], min: 1, max: 2 }
];
const DEFAULT_PARTICLE_CHANCE = 25;

const NEIGHBOURS = [
    { x: 1, y: 0, z: 0 },
    { x: -1, y: 0, z: 0 },
    { x: 0, y: 1, z: 0 },
    { x: 0, y: -1, z: 0 },
    { x: 0, y: 0, z: 1 },
    { x: 0, y: 0, z: -1 }
];

function isLeafPermutation(permutation) {
    return permutation.getState(DISTANCE_STATE) !== undefined;
}

function isLeaf(block) {
    try {
        return block !== undefined && isLeafPermutation(block.permutation);
    }
    catch {
        return false;
    }
}

function isSupport(permutation) {
    return SUPPORT_TAGS.some(tag => permutation.hasTag(tag));
}

function readDistance(permutation) {
    const value = permutation.getState(DISTANCE_STATE);
    return typeof value === "number" ? value : MAX_DISTANCE;
}

function isVerified(permutation) {
    return permutation.getState(UPDATE_STATE) === false;
}

function survey(block) {
    let distance = MAX_DISTANCE;
    let unsettled = false;
    let closed = true;
    const leafNeighbours = [];

    for (const step of NEIGHBOURS) {
        let neighbour;
        try {
            neighbour = block.offset(step);
        }
        catch (error) {
            if (error instanceof LocationOutOfWorldBoundariesError) {
                continue;
            }
            return undefined;
        }
        if (neighbour === undefined) {
            return undefined;
        }

        const permutation = neighbour.permutation;
        if (!isLeafPermutation(permutation) && !isSolidLike(neighbour)) {
            closed = false;
        }
        if (isSupport(permutation)) {
            distance = 1;
            continue;
        }
        if (!isLeafPermutation(permutation)) {
            continue;
        }

        leafNeighbours.push(neighbour.location);
        if (!isVerified(permutation)) {
            unsettled = true;
            continue;
        }
        distance = Math.min(distance, readDistance(permutation) + 1);
    }

    return { distance: Math.min(distance, MAX_DISTANCE), leafNeighbours, unsettled, closed };
}

function hasOpaqueState(permutation) {
    return permutation.getState(OPAQUE_STATE) !== undefined;
}

function writeSurvey(block, distance, closed) {
    let permutation = block.permutation
        .withState(DISTANCE_STATE, distance)
        .withState(UPDATE_STATE, false);
    if (hasOpaqueState(permutation)) {
        permutation = permutation.withState(OPAQUE_STATE, closed);
    }
    block.setPermutation(permutation);
}

const pending = new Map();
let draining = false;

function keyOf(dimension, location) {
    return `${dimension.id}|${location.x},${location.y},${location.z}`;
}

const heights = new Map();

function heightOf(dimension) {
    let height = heights.get(dimension.id);
    if (height === undefined) {
        try {
            const range = dimension.heightRange;
            height = { min: range.min, max: range.max };
            heights.set(dimension.id, height);
        }
        catch {
            return undefined;
        }
    }
    return height;
}

function enqueue(dimension, location) {
    const height = heightOf(dimension);
    if (height !== undefined && (location.y < height.min || location.y >= height.max)) {
        return;
    }
    pending.set(keyOf(dimension, location), {
        dimension,
        location: { x: location.x, y: location.y, z: location.z }
    });
    startDrain();
}

function enqueueNeighbours(dimension, location) {
    for (const step of NEIGHBOURS) {
        enqueue(dimension, { x: location.x + step.x, y: location.y + step.y, z: location.z + step.z });
    }
}

function isQueued(dimension, location) {
    return pending.has(keyOf(dimension, location));
}

function update({ dimension, location }) {
    const block = dimension.getBlock(location);
    if (block === undefined || !isLeaf(block)) {
        return;
    }
    const permutation = block.permutation;
    const result = survey(block);
    if (result === undefined) {
        return;
    }

    const changed = result.distance !== readDistance(permutation)
        || !isVerified(permutation)
        || (hasOpaqueState(permutation) && permutation.getState(OPAQUE_STATE) !== result.closed);
    if (!changed) {
        return;
    }
    writeSurvey(block, result.distance, result.closed);
    for (const at of result.leafNeighbours) {
        enqueue(dimension, at);
    }
    if (result.unsettled) {
        enqueue(dimension, location);
    }
}

function startDrain() {
    if (draining || pending.size === 0) {
        return;
    }
    draining = true;
    system.runJob(drain());
}

function* drain() {
    try {
        for (let done = 0; done < DRAIN_LIMIT && pending.size > 0; done++) {
            const [id, entry] = pending.entries().next().value;
            pending.delete(id);
            try {
                update(entry);
            }
            catch {
            }
            yield;
        }
    }
    finally {
        draining = false;
    }
    if (pending.size > 0) {
        system.runTimeout(startDrain, 1);
    }
}

function percent(value, fallback) {
    const number = Number(value);
    return (Number.isFinite(number) ? number : fallback) / 100;
}

function dropsOf(params) {
    return Array.isArray(params?.drops) ? params.drops : DEFAULT_DROPS;
}

function rollDrops(dimension, location, drops, fortune) {
    for (const drop of drops) {
        const chances = Array.isArray(drop.chances) ? drop.chances : [drop.chances];
        if (typeof drop.item !== "string" || chances.length === 0) {
            continue;
        }
        if (Math.random() >= percent(chances[Math.min(fortune, chances.length - 1)], 0)) {
            continue;
        }
        const min = Number.isFinite(drop.min) ? drop.min : 1;
        const max = Number.isFinite(drop.max) ? Math.max(drop.max, min) : min;
        const count = min + Math.floor(Math.random() * (max - min + 1));
        try {
            dimension.spawnItem(new ItemStack(drop.item, count), location);
        }
        catch {
        }
    }
}

function rot(block) {
    const dimension = block.dimension;
    const location = block.center();
    let drops = [];
    try {
        const instance = block.getComponent(DROPS_COMPONENT);
        if (instance !== undefined) {
            drops = dropsOf(instance.customComponentParameters.params);
        }
    }
    catch {
    }
    block.setType("minecraft:air");
    dimension.playSound("dig.grass", location);
    rollDrops(dimension, location, drops, 0);
}

system.beforeEvents.startup.subscribe((init) => {
    const registry = init.blockComponentRegistry;

    registry.registerCustomComponent("dd:leaves_updates", {
        onPlace(event) {
            enqueue(event.dimension, event.block.location);
        },
        onBreak(event) {
            enqueueNeighbours(event.dimension, event.block.location);
        }
    });

    registry.registerCustomComponent("dd:leaves_opaque", {
        onRandomTick(event) {
            const block = event.block;
            const permutation = block.permutation;
            if (!hasOpaqueState(permutation)) {
                return;
            }
            const result = survey(block);
            if (result === undefined || permutation.getState(OPAQUE_STATE) === result.closed) {
                return;
            }
            try {
                block.setPermutation(block.permutation.withState(OPAQUE_STATE, result.closed));
            }
            catch { /* блок ушёл между тиком и записью */ }
        }
    });

    registry.registerCustomComponent("dd:leaves_decay", {
        onRandomTick(event) {
            const block = event.block;
            const dimension = event.dimension;
            const permutation = block.permutation;

            if (permutation.getState(PERSISTENT_STATE) === true) {
                return;
            }
            if (!isVerified(permutation)) {
                enqueue(dimension, block.location);
                return;
            }
            if (readDistance(permutation) < MAX_DISTANCE) {
                return;
            }
            if (isQueued(dimension, block.location)) {
                return;
            }
            if (Math.random() >= DECAY_CHANCE) {
                return;
            }

            const result = survey(block);
            if (result === undefined) {
                return;
            }
            if (result.distance < MAX_DISTANCE) {
                writeSurvey(block, result.distance, result.closed);
                return;
            }
            if (result.unsettled) {
                enqueue(dimension, block.location);
                return;
            }
            for (const at of result.leafNeighbours) {
                if (isQueued(dimension, at)) {
                    return;
                }
            }
            rot(block);
        }
    });

    registry.registerCustomComponent("dd:leaves_persistence", {
        beforeOnPlayerPlace(event) {
            event.permutationToPlace = event.permutationToPlace.withState(PERSISTENT_STATE, true);
        }
    });

    registry.registerCustomComponent(DROPS_COMPONENT, {
        onPlayerBreak(event, { params }) {
            const player = event.player;
            if (player === undefined || player.getGameMode() === GameMode.Creative) {
                return;
            }
            const tool = player.getComponent("minecraft:equippable")?.getEquipment(EquipmentSlot.Mainhand);
            const enchantable = tool?.getComponent("minecraft:enchantable");
            if (tool?.hasTag("minecraft:is_shears") || enchantable?.getEnchantment("silk_touch") !== undefined) {
                return;
            }
            const fortune = enchantable?.getEnchantment("fortune")?.level ?? 0;
            const dimension = event.dimension;
            const location = event.block.center();
            const drops = dropsOf(params);
            system.run(() => rollDrops(dimension, location, drops, fortune));
        }
    });

    registry.registerCustomComponent("dd:leaves_particles", {
        onRandomTick(event, { params }) {
            const particle = params.particle;
            if (typeof particle !== "string") {
                return;
            }
            if (Math.random() >= percent(params.chance, DEFAULT_PARTICLE_CHANCE)) {
                return;
            }
            let under;
            try {
                under = event.block.below();
            }
            catch {
                return;
            }
            if (under === undefined || !(under.isAir || under.isLiquid || under.hasTag(HANGING_TAG))) {
                return;
            }
            try {
                event.dimension.spawnParticle(particle, event.block.center());
            }
            catch {
            }
        }
    });
});

function affectsLeaves(permutation) {
    try {
        return isSupport(permutation) || isLeafPermutation(permutation);
    }
    catch {
        return false;
    }
}

world.afterEvents.playerPlaceBlock.subscribe((event) => {
    if (affectsLeaves(event.block.permutation)) {
        enqueueNeighbours(event.dimension, event.block.location);
    }
});

world.afterEvents.playerBreakBlock.subscribe((event) => {
    if (affectsLeaves(event.brokenBlockPermutation)) {
        enqueueNeighbours(event.dimension, event.block.location);
    }
});

world.afterEvents.blockExplode.subscribe((event) => {
    if (affectsLeaves(event.explodedBlockPermutation)) {
        enqueueNeighbours(event.dimension, event.block.location);
    }
});
