import { world, system } from "@minecraft/server";
import { isSolidLike } from "../utils/blockChecks.js";

const PART_STATE = "minecraft:multi_block_part";
const FACING_STATE = "minecraft:cardinal_direction";
const OPEN_STATE = "dd:open_bit";
const HINGE_STATE = "dd:door_hinge_bit";
const POWERED_STATE = "dd:powered_bit";

const CLOCKWISE = { north: "east", east: "south", south: "west", west: "north" };
const COUNTER_CLOCKWISE = { north: "west", west: "south", south: "east", east: "north" };
const STEP = {
    north: { x: 0, y: 0, z: -1 },
    south: { x: 0, y: 0, z: 1 },
    east: { x: 1, y: 0, z: 0 },
    west: { x: -1, y: 0, z: 0 }
};

function neighbour(dimension, location, direction) {
    const step = STEP[direction];
    if (!step) return undefined;
    try {
        return dimension.getBlock({ x: location.x + step.x, y: location.y, z: location.z + step.z });
    } catch { return undefined; }
}

function partsOf(block) {
    try {
        const parts = block.getParts();
        if (parts && parts.length) return parts;
    } catch { }
    try {
        const index = block.permutation.getState(PART_STATE);
        const other = index === 0 ? block.above() : block.below();
        if (other && other.typeId === block.typeId && other.permutation.getState(PART_STATE) === 1 - index) {
            return index === 0 ? [block, other] : [other, block];
        }
    } catch { }
    return [block];
}

function lowerPart(block) {
    return partsOf(block).find(part => part.permutation.getState(PART_STATE) === 0) ?? block;
}

function isLowerHalfOf(block, typeId) {
    return !!block && block.typeId === typeId && block.permutation.getState(PART_STATE) === 0;
}

function placementFacing(e) {
    try {
        const yaw = e.player?.getRotation().y;
        if (Number.isFinite(yaw)) {
            const index = ((Math.floor((yaw + 45) / 90) % 4) + 4) % 4;
            return ["south", "west", "north", "east"][index];
        }
    } catch { }
    return e.permutationToPlace.getState(FACING_STATE);
}

function hingeOnRight(e, facing) {
    const location = e.block.location;
    const typeId = e.permutationToPlace.type.id;
    const left = neighbour(e.dimension, location, COUNTER_CLOCKWISE[facing]);
    const right = neighbour(e.dimension, location, CLOCKWISE[facing]);
    if (isLowerHalfOf(left, typeId)) return true;
    return !isLowerHalfOf(right, typeId) && !!isSolidLike(right) && !isSolidLike(left);
}

function setOpen(block, open, params = {}) {
    let changed = false;
    for (const part of partsOf(block)) {
        try {
            const permutation = part.permutation;
            if (permutation.getState(OPEN_STATE) === open) continue;
            part.setPermutation(permutation.withState(OPEN_STATE, open));
            changed = true;
        } catch { }
    }
    const sound = open ? params.open_sound : params.close_sound;
    if (changed && sound) block.dimension.playSound(sound, block.center());
}

function updatePower(block, eventPower = 0, params = {}) {
    if (world.getDynamicProperty("dd:world_state") === 1) return;
    const parts = partsOf(block);
    const root = parts.find(part => part.permutation.getState(PART_STATE) === 0) ?? block;
    let power = eventPower;
    for (const part of parts) {
        try { power = Math.max(power, part.getRedstonePower() ?? 0); } catch { }
    }
    const powered = power > 0;
    const wasPowered = root.permutation.getState(POWERED_STATE);
    if (typeof wasPowered === "boolean") {
        if (wasPowered === powered) return;
        for (const part of parts) {
            try {
                if (typeof part.permutation.getState(POWERED_STATE) === "boolean") {
                    part.setPermutation(part.permutation.withState(POWERED_STATE, powered));
                }
            } catch { }
        }
    }
    setOpen(root, powered, params);
}

system.beforeEvents.startup.subscribe(init => {
    init.blockComponentRegistry.registerCustomComponent("dd:door_config", {
        beforeOnPlayerPlace(e) {
            const facing = placementFacing(e);
            if (!CLOCKWISE[facing]) return;
            let permutation = e.permutationToPlace
                .withState(FACING_STATE, facing)
                .withState(HINGE_STATE, hingeOnRight(e, facing))
                .withState(OPEN_STATE, false);
            if (typeof permutation.getState(POWERED_STATE) === "boolean") {
                permutation = permutation.withState(POWERED_STATE, false);
            }
            e.permutationToPlace = permutation;
        },
        onPlace(e, p) {
            const block = e.block;
            if (block.permutation.getState(PART_STATE) !== 0) return;
            const typeId = block.typeId;
            const params = p?.params ?? {};
            system.run(() => {
                try {
                    if (block.typeId !== typeId) return;
                    const source = block.permutation;
                    for (const part of partsOf(block)) {
                        if (part.permutation.getState(PART_STATE) === 0) continue;
                        let target = part.permutation;
                        for (const state of [FACING_STATE, HINGE_STATE, OPEN_STATE, POWERED_STATE]) {
                            const value = source.getState(state);
                            if (value !== undefined && target.getState(state) !== value) {
                                target = target.withState(state, value);
                            }
                        }
                        part.setPermutation(target);
                    }
                    updatePower(block, 0, params);
                } catch { }
            });
        },
        onPlayerInteract(e, p) {
            const block = lowerPart(e.block);
            setOpen(block, block.permutation.getState(OPEN_STATE) !== true, p?.params ?? {});
        },
        onRedstoneUpdate(e, p) {
            updatePower(e.block, e.powerLevel, p?.params ?? {});
        }
    });
});
