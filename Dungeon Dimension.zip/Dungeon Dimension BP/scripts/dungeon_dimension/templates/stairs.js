import { ddTriggers } from "../ddTriggers.js";
import { stairShape } from "../utils/blockChecks.js";

const CORNER_STATE = "minecraft:corner";

function refresh(block) {
    if (!block) return;
    const shape = stairShape(block);
    if (shape === null) return;

    const permutation = block.permutation;
    if (permutation.getState(CORNER_STATE) === shape) return;

    try { block.setPermutation(permutation.withState(CORNER_STATE, shape)); } catch { return; }

    ddTriggers.notifyNeighbours(block);
}

ddTriggers.registerBehaviourByTag("dd:stairs", {
    onAdjacentChange(e) { refresh(e.block); }
});
