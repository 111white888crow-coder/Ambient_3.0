import { BlockPermutation } from "@minecraft/server";
import { ddTriggers, ReduceDurability } from "../ddTriggers.js";

const LOG_TAG = "dd:log";

ddTriggers.registerBehaviourByTag(LOG_TAG, {
    item_tag: "minecraft:is_axe",
    onInteract(e, params) {
        const { block, player, itemStack } = e;
        const { stripped, strip_sound } = params;
        if (!stripped) return;

        let permutation;
        try { permutation = BlockPermutation.resolve(stripped); } catch {
            console.warn(`[dd:log] неизвестный блок в param__stripped__: ${stripped}`);
            return;
        }

        for (const [name, value] of Object.entries(block.permutation.getAllStates())) {
            try { permutation = permutation.withState(name, value); } catch { }
        }

        block.setPermutation(permutation);
        if (strip_sound) block.dimension.playSound(strip_sound, block.center(), { pitch: 0.8 });
        if (itemStack) ReduceDurability(player, itemStack, 1, "Mainhand");
    }
});
