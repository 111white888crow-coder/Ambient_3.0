import { world, system } from "@minecraft/server";

const STATE = "dd:activated";
const WORLD_STATE = "dd:world_state";

/**
 * Уровень сигнала числом 0..15.
 *
 * Движок отдаёт и powerLevel, и getRedstonePower не нулём, а undefined, когда
 * сигнала нет вовсе. Раньше это не проверяли, и у лампы — единственной, кто
 * держит заряд числом, — выходило Math.min(15, undefined) === NaN. Состояние с
 * таким значением записать нельзя, запись падала с ошибкой, и лампа оставалась
 * гореть уже после того, как рычаг убрали. У створок тот же undefined проходил
 * незаметно: там сигнал сравнивали, а не записывали.
 */
const levelOf = (power) => {
	const value = Number(power ?? 0);
	if (!Number.isFinite(value)) return 0;
	return Math.max(0, Math.min(15, Math.trunc(value)));
};

/** Заряд числом: лампа светит ровно на ту силу, что до неё дошла. */
function applyCharge(block, level, params) {
	const was = block.permutation.getState(STATE);
	if (was === level) return;
	block.setPermutation(block.permutation.withState(STATE, level));

	if (level === 0 && params.off_sound) block.dimension.playSound(params.off_sound, block.location);
	else if (was === 0 && params.on_sound) block.dimension.playSound(params.on_sound, block.location);
}

/** Простое «включено/выключено». */
function applyToggle(block, powered, params) {
	const was = block.permutation.getState(STATE);
	if (was === powered) return;
	block.setPermutation(block.permutation.withState(STATE, powered));

	if (was && params.off_sound && params.on_sound) block.dimension.playSound(params.off_sound, block.location);
	else if (params.on_sound) block.dimension.playSound(params.on_sound, block.location);
}

/** Привести блок к уровню сигнала. Ничего не делает, если он уже такой. */
function apply(block, level, params) {
	if (params.is_charge) applyCharge(block, level, params);
	else applyToggle(block, level >= 1, params);
}

/* ─── Присмотр за горящими ───────────────────────────────────────────────── */

/**
 * Почему мало одного onRedstoneUpdate.
 *
 * Зажигается блок по событию исправно, а вот спада сигнала событием можно и не
 * дождаться: у лампы это уже дважды выходило боком — то запись состояния падала
 * на NaN (см. levelOf), то событие на спаде приходило с задержкой в пару секунд.
 * Лампа при этом горит, хотя рычага давно нет, и разбудить её нечем: следующего
 * события неоткуда взяться, пока кто-нибудь не тронет проводку рядом.
 *
 * Поэтому у горящих блоков есть независимая проверка: раз в пару тиков спросить
 * у самого блока, сколько до него доходит. Это опрос, но опрашиваются только те,
 * кто прямо сейчас горит, — погасший из списка уходит и больше ничего не стоит.
 */
const WATCH_INTERVAL = 2;

/**
 * Сколько подряд нулевых замеров нужно, чтобы погасить.
 *
 * Один замер мог соврать (блок в этот миг перезаписывали, чанк подгружался), а
 * ложное гашение под работающим рычагом выглядит как мигание. Два замера — это
 * четыре тика, ровно та задержка, с которой гаснет ванильная лампа.
 */
const MISSES_TO_DARK = 2;

/** Ключ клетки -> что это за блок и сколько нулей подряд у него намерили. */
const watched = new Map();

let watch;

const cellKey = (dimension, location) => `${dimension.id}|${location.x},${location.y},${location.z}`;

/** Взять блок под присмотр: он горит, значит однажды должен погаснуть. */
function enrol(block, params) {
	const dimension = block.dimension;
	const location = { ...block.location };
	const key = cellKey(dimension, location);

	const known = watched.get(key);
	if (known !== undefined) {
		known.misses = 0;
		return;
	}

	watched.set(key, { dimension, location, typeId: block.typeId, params, misses: 0 });
	startWatch();
}

function startWatch() {
	if (watch !== undefined) return;

	watch = system.runInterval(() => {
		if (watched.size === 0) {
			system.clearRun(watch);
			watch = undefined;
			return;
		}
		if (world.getDynamicProperty(WORLD_STATE) === 1) return;

		for (const [key, lit] of watched) {
			let block;
			try { block = lit.dimension.getBlock(lit.location); }
			catch { continue; /* чанк выгружен — вернёмся, когда загрузится */ }

			if (block === undefined) continue;
			if (block.typeId !== lit.typeId) { watched.delete(key); continue; }

			let power;
			try { power = levelOf(block.getRedstonePower()); }
			catch { continue; }

			if (power >= 1) {
				lit.misses = 0;
			} else if (++lit.misses < MISSES_TO_DARK) {
				continue;
			} else {
				watched.delete(key);
			}

			try { apply(block, power, lit.params); }
			catch (error) { console.warn(`[activated] присмотр ${lit.typeId}: ${error}`); }
		}
	}, WATCH_INTERVAL);
}

/** Горит ли блок сейчас — и у заряда числом, и у простого «включено». */
function isOn(block) {
	try {
		const state = block.permutation.getState(STATE);
		return state !== undefined && state !== false && state !== 0;
	} catch {
		return false;
	}
}

system.beforeEvents.startup.subscribe((init) => {
	init.blockComponentRegistry.registerCustomComponent("dd:activated_config", {
		onRedstoneUpdate(e, p) {
			if (world.getDynamicProperty(WORLD_STATE) === 1) return;
			const { block } = e;
			const level = levelOf(e.powerLevel);
			try {
				apply(block, level, p.params);
				if (level >= 1) enrol(block, p.params);
				else watched.delete(cellKey(block.dimension, block.location));
			}
			catch (error) { console.warn(`[activated] ${block?.typeId}: ${error}`); }
		},

		/**
		 * Тик нужен, чтобы вернуть под присмотр тех, кто горел ещё до запуска
		 * скриптов: список живёт в памяти, и перезагрузка мира его стирает.
		 * Погасший блок уходит отсюда сразу — ему тик ничего не стоит.
		 *
		 * У блока обязан быть minecraft:tick в **базовых** компонентах, иначе
		 * движок ругается «subscribed to 'onTick' but the block is missing the
		 * 'minecraft:tick' component» — тика в перестановках ему мало.
		 */
		onTick(e, p) {
			if (world.getDynamicProperty(WORLD_STATE) === 1) return;
			const { block } = e;
			if (!isOn(block)) return;
			enrol(block, p.params);
		}
	});
});
