import { EquipmentSlot, GameMode, system, world } from "@minecraft/server";
import { ddTriggers } from "../ddTriggers.js";

export const HANGING_TAG = "dd:hanging_leaves";
export const TIP_STATE = "dd:tip";

const BONE_MEAL = "minecraft:bone_meal";
const GROWTH_PARTICLE = "minecraft:crop_growth_emitter";
const GROWTH_SOUND = "item.bone_meal.use";

const COLUMN_LIMIT = 4096;

function blockAt(dimension, location) {
    try {
        return dimension.getBlock(location);
    }
    catch {
        return undefined;
    }
}

function above(block) {
    try {
        return block.above();
    }
    catch {
        return undefined;
    }
}

function below(block) {
    try {
        return block.below();
    }
    catch {
        return undefined;
    }
}

function cellBelow(location) {
    return { x: location.x, y: location.y - 1, z: location.z };
}

function isSegment(block, id) {
    return block !== undefined && block.typeId === id;
}

function shouldBeTip(block, id) {
    return !isSegment(below(block), id);
}

function setTip(block, tip) {
    const permutation = block.permutation;
    if (permutation.getState(TIP_STATE) === tip) {
        return;
    }
    block.setPermutation(permutation.withState(TIP_STATE, tip));
}

function findTip(block) {
    const id = block.typeId;
    let current = block;
    for (let step = 0; step < COLUMN_LIMIT; step++) {
        const next = below(current);
        if (!isSegment(next, id)) {
            break;
        }
        current = next;
    }
    return current;
}

function consumeOne(player) {
    if (player === undefined || player.getGameMode() === GameMode.Creative) {
        return;
    }
    const equipment = player.getComponent("minecraft:equippable");
    const held = equipment?.getEquipment(EquipmentSlot.Mainhand);
    if (held === undefined || held.typeId !== BONE_MEAL) {
        return;
    }
    if (held.amount > 1) {
        held.amount -= 1;
        equipment.setEquipment(EquipmentSlot.Mainhand, held);
    }
    else {
        equipment.setEquipment(EquipmentSlot.Mainhand, undefined);
    }
}

function grow(block, player) {
    if (!block.hasTag(HANGING_TAG)) {
        return false;
    }
    const tip = findTip(block);
    const target = below(tip);
    if (target === undefined || !target.isAir) {
        return false;
    }

    target.setPermutation(tip.permutation.withState(TIP_STATE, true));
    setTip(tip, false);

    const dimension = tip.dimension;
    const location = target.center();
    try {
        dimension.spawnParticle(GROWTH_PARTICLE, location);
        dimension.playSound(GROWTH_SOUND, location);
    }
    catch {
    }
    consumeOne(player);
    return true;
}

function dropIfFloating(block) {
    const support = above(block);
    if (support === undefined || !(support.isAir || support.isLiquid)) {
        return false;
    }
    const { x, y, z } = block.location;
    try {
        block.dimension.runCommand(`setblock ${x} ${y} ${z} air destroy`);
    }
    catch {
        return false;
    }
    return true;
}

function dropUnsupported(dimension, location) {
    const block = blockAt(dimension, location);
    if (block !== undefined && block.hasTag(HANGING_TAG)) {
        dropIfFloating(block);
    }
}

system.beforeEvents.startup.subscribe((init) => {
    init.blockComponentRegistry.registerCustomComponent("dd:hanging_leaves", {
        beforeOnPlayerPlace(event) {
            const permutation = event.permutationToPlace;
            event.permutationToPlace = permutation.withState(TIP_STATE, shouldBeTip(event.block, permutation.type.id));
        },

        onPlace(event) {
            const block = event.block;
            const id = block.typeId;
            setTip(block, shouldBeTip(block, id));
            const upper = above(block);
            if (isSegment(upper, id)) {
                setTip(upper, false);
            }
        },

        onBreak(event) {
            const id = event.brokenBlockPermutation.type.id;
            const block = event.block;
            if (block.typeId === id) {
                return;
            }
            const upper = above(block);
            if (isSegment(upper, id)) {
                setTip(upper, true);
            }
            const dimension = event.dimension;
            const location = cellBelow(block.location);
            system.run(() => dropUnsupported(dimension, location));
        },

        onRandomTick(event) {
            const block = event.block;
            if (dropIfFloating(block)) {
                return;
            }
            setTip(block, shouldBeTip(block, block.typeId));
        }
    });
});

world.afterEvents.playerBreakBlock.subscribe((event) => {
    dropUnsupported(event.dimension, cellBelow(event.block.location));
});

world.afterEvents.blockExplode.subscribe((event) => {
    dropUnsupported(event.dimension, cellBelow(event.block.location));
});

ddTriggers.registerBehaviourByTag(HANGING_TAG, {
    item_id: BONE_MEAL,
    onInteract(event) {
        grow(event.block, event.player);
    }
});
