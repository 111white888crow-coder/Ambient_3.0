import { BlockPermutation, ItemStack, LiquidType, MolangVariableMap, system, world } from "@minecraft/server";
import { LAYERS_STATE, MAX_LAYERS, isLayer, layerCount } from "./layer.js";

const ENTITY_ID = "dd:falling_block";
const FALLING_TAG = "dd:falling";

const VANILLA_FALLER = "minecraft:falling_block";

const PROP_BLOCK = "dd:fall_block";
const PROP_LAYERS = "dd:fall_layers";
const PROP_AGE = "dd:fall_age";
const PROP_X = "dd:fall_x";
const PROP_Z = "dd:fall_z";
const PROP_VY = "dd:fall_vy";

const SHAPE_PROPERTY = "dd:shape";
const MATERIAL_PROPERTY = "dd:material";

const MATERIALS = [
    { block: "dd:whitestone_dust", dust: { red: 0.885, green: 0.892, blue: 0.893, alpha: 1 } },
    { block: "dd:dune_sand", dust: { red: 0.784, green: 0.539, blue: 0.35, alpha: 1 } }
];

const DUST_PARTICLE = "minecraft:falling_dust_concrete_powder_particle";
const DUST_MIN = 1;
const DUST_MAX = 3;

const LAYER_SUFFIX = "_layer";
function materialIndex(typeId) {
    if (typeof typeId !== "string") {
        return 0;
    }
    const base = typeId.endsWith(LAYER_SUFFIX) ? typeId.slice(0, -LAYER_SUFFIX.length) : typeId;
    const found = MATERIALS.findIndex(m => m.block === base);
    return found < 0 ? 0 : found;
}

const MAX_FALL_TICKS = 600;
const SWEEP_INTERVAL = 20;
const SWEEP_DIMENSIONS = new Set(["overworld", "nether", "the_end", "dd:abyss"]);
const SWEEP_BATCH = 16;
const SWEEP_LIMIT = 2048;

const GRAVITY = 0.08;
const DRAG = 0.98;

const LANDING_HOLD = 2;

const MAX_CATCH_UP = 5;

const CASCADE_DELAY = 1;

const AFTER_EVENT_LAG = 1;

const STACK_SEARCH = 8;

const LAYER_HEIGHT = 2 / 16;

const SOUND = "dig.sand";

const dustVariables = new Map();
function dustColor(typeId) {
    const index = materialIndex(typeId);
    let variables = dustVariables.get(index);
    if (variables === undefined) {
        variables = new MolangVariableMap();
        variables.setColorRGBA("variable.color", MATERIALS[index].dust);
        dustVariables.set(index, variables);
    }
    return variables;
}

function isFalling(block) {
    try {
        return block !== undefined && block.hasTag(FALLING_TAG);
    }
    catch {
        return false;
    }
}

function isOpenBelow(below) {
    if (below.isAir || below.isLiquid) {
        return true;
    }
    return !below.isLiquidBlocking(LiquidType.Water);
}

function shedDust(block) {
    const count = DUST_MIN + Math.floor(Math.random() * (DUST_MAX - DUST_MIN + 1));
    const variables = dustColor(block.typeId);
    for (let mote = 0; mote < count; mote++) {
        block.dimension.spawnParticle(DUST_PARTICLE, {
            x: block.x + Math.random(),
            y: block.y - 0.05,
            z: block.z + Math.random()
        }, variables);
    }
}

function startFall(block) {
    const dimension = block.dimension;
    const { x, y, z } = block.location;
    const typeId = block.typeId;
    const layers = isLayer(block) ? layerCount(block.permutation) : undefined;

    const faller = dimension.spawnEntity(ENTITY_ID, { x: x + 0.5, y, z: z + 0.5 });
    block.setType("minecraft:air");

    faller.setDynamicProperty(PROP_BLOCK, typeId);
    faller.setDynamicProperty(PROP_AGE, 0);
    faller.setDynamicProperty(PROP_X, x);
    faller.setDynamicProperty(PROP_Z, z);
    faller.setDynamicProperty(PROP_VY, 0);
    if (layers !== undefined) {
        faller.setDynamicProperty(PROP_LAYERS, layers);
    }
    faller.setProperty(SHAPE_PROPERTY, layers ?? 0);
    faller.setProperty(MATERIAL_PROPERTY, materialIndex(typeId));
    falling.set(faller, { y, vy: 0, tick: system.currentTick, arrived: null, cell: null });
    SWEEP_DIMENSIONS.add(dimension.id);

    system.runTimeout(() => checkAround(dimension, { x, y, z }), CASCADE_DELAY);
}

function fillsTopOfCell(below, layerForm) {
    if (below.isAir || below.isLiquid) {
        return false;
    }
    if (isLayer(below) && below.typeId === layerForm) {
        return layerCount(below.permutation) > MAX_LAYERS;
    }
    return true;
}

function layerFormOf(typeId, isLayerBlock) {
    return isLayerBlock ? typeId : `${typeId}_layer`;
}

const views = new Map();

const FLOOR_EPS = 1e-6;

function viewOf(dimension) {
    const now = system.currentTick;
    const cached = views.get(dimension.id);
    if (cached !== undefined && cached.tick === now) {
        return cached;
    }
    const columns = new Map();
    try {
        for (const entity of dimension.getEntities({ type: VANILLA_FALLER })) {
            const loc = entity.location;
            const key = `${Math.floor(loc.x)},${Math.floor(loc.z)}`;
            let list = columns.get(key);
            if (list === undefined) {
                list = [];
                columns.set(key, list);
            }
            list.push({ entity, y: loc.y });
        }
    }
    catch {
    }
    const view = { tick: now, columns };
    views.set(dimension.id, view);
    return view;
}

function forgetView(dimension) {
    views.delete(dimension.id);
}

function fallersInColumn(dimension, x, z) {
    return viewOf(dimension).columns.get(`${x},${z}`);
}

function vanillaFallerIn(dimension, cell) {
    const list = fallersInColumn(dimension, cell.x, cell.z);
    if (list === undefined) {
        return false;
    }
    return list.some(item => Math.floor(item.y + FLOOR_EPS) === cell.y);
}

const HOLD_REACH = (GRAVITY / (1 - DRAG)) * (LANDING_HOLD + 1);

function vanillaFallerAbove(dimension, column, fromY) {
    const list = fallersInColumn(dimension, column.x, column.z);
    if (list === undefined) {
        return false;
    }
    return list.some(item => item.y > fromY && item.y - fromY <= HOLD_REACH);
}

const reservations = new Map();
const reservationOf = new Map();

function cellKey(dimension, cell) {
    return `${dimension.id}|${cell.x},${cell.y},${cell.z}`;
}

function reserve(faller, cell) {
    const key = cellKey(faller.dimension, cell);
    const previous = reservationOf.get(faller);
    if (previous === key) {
        return;
    }
    if (previous !== undefined && reservations.get(previous) === faller) {
        reservations.delete(previous);
    }
    reservations.set(key, faller);
    reservationOf.set(faller, key);
}

function release(faller) {
    const key = reservationOf.get(faller);
    if (key === undefined) {
        return;
    }
    if (reservations.get(key) === faller) {
        reservations.delete(key);
    }
    reservationOf.delete(faller);
}

function heldByOther(dimension, cell, self) {
    const key = cellKey(dimension, cell);
    const holder = reservations.get(key);
    if (holder === undefined || holder === self) {
        return false;
    }
    if (!holder.isValid || !falling.has(holder)) {
        reservations.delete(key);
        reservationOf.delete(holder);
        return false;
    }
    return true;
}

function cellTaken(dimension, block, cell, self) {
    if (!block.isAir && !block.isLiquid) {
        return true;
    }
    return vanillaFallerIn(dimension, cell) || heldByOther(dimension, cell, self);
}

function freeCellAbove(dimension, column, y, self) {
    for (let up = y + 1; up <= y + STACK_SEARCH; up++) {
        const cell = { x: column.x, y: up, z: column.z };
        const block = dimension.getBlock(cell);
        if (block === undefined) {
            return null;
        }
        if (!cellTaken(dimension, block, cell, self)) {
            return up;
        }
    }
    return null;
}

function checkFalling(block) {
    if (!isFalling(block)) {
        return;
    }
    let below;
    try {
        below = block.below();
    }
    catch {
        return;
    }
    if (below === undefined) {
        return;
    }
    if (!fillsTopOfCell(below, layerFormOf(block.typeId, isLayer(block)))) {
        startFall(block);
        return;
    }
    if (isOpenBelow(below)) {
        shedDust(block);
    }
}

const NEIGHBOURS = [
    { x: 0, y: 1, z: 0 },
    { x: 0, y: -1, z: 0 },
    { x: 0, y: 0, z: -1 },
    { x: 0, y: 0, z: 1 },
    { x: -1, y: 0, z: 0 },
    { x: 1, y: 0, z: 0 }
];

function checkAround(dimension, location) {
    for (const offset of NEIGHBOURS) {
        try {
            const neighbour = dimension.getBlock({
                x: location.x + offset.x,
                y: location.y + offset.y,
                z: location.z + offset.z
            });
            if (isFalling(neighbour)) {
                checkFalling(neighbour);
            }
        }
        catch {
        }
    }
}

function cellOf(faller) {
    const loc = faller.location;
    const storedX = faller.getDynamicProperty(PROP_X);
    const storedZ = faller.getDynamicProperty(PROP_Z);
    return {
        x: typeof storedX === "number" ? storedX : Math.floor(loc.x),
        y: Math.floor(loc.y + 0.1),
        z: typeof storedZ === "number" ? storedZ : Math.floor(loc.z)
    };
}

function dropAt(dimension, cell, typeId, count) {
    dimension.spawnItem(new ItemStack(typeId, count), {
        x: cell.x + 0.5,
        y: cell.y + 0.5,
        z: cell.z + 0.5
    });
}

const RESCUE_TICKS = 2;

function rescueFallers(dimension, cell) {
    const list = fallersInColumn(dimension, cell.x, cell.z);
    if (list === undefined) {
        return;
    }
    let moved = false;
    for (const item of list) {
        if (Math.floor(item.y + FLOOR_EPS) !== cell.y) {
            continue;
        }
        try {
            item.entity.teleport({ x: cell.x + 0.5, y: cell.y + 1, z: cell.z + 0.5 });
            moved = true;
        }
        catch {
        }
    }
    if (moved) {
        forgetView(dimension);
    }
}

function placeAt(dimension, cell, typeId, layers) {
    const states = layers === undefined ? undefined : { [LAYERS_STATE]: layers - 1 };
    dimension.setBlockPermutation(cell, BlockPermutation.resolve(typeId, states));
    dimension.playSound(SOUND, { x: cell.x + 0.5, y: cell.y + 0.5, z: cell.z + 0.5 });
    rescueFallers(dimension, cell);
    for (let tick = 1; tick <= RESCUE_TICKS; tick++) {
        system.runTimeout(() => rescueFallers(dimension, cell), tick);
    }
}

function settle(faller, cell = cellOf(faller)) {
    const dimension = faller.dimension;
    const typeId = faller.getDynamicProperty(PROP_BLOCK);
    const stored = faller.getDynamicProperty(PROP_LAYERS);
    const layers = typeof stored === "number" ? stored : undefined;

    if (typeof typeId !== "string") {
        faller.remove();
        return true;
    }

    const FULL = MAX_LAYERS + 1;
    const fellAsLayers = layers !== undefined;
    const layerForm = fellAsLayers ? typeId : `${typeId}_layer`;
    let left = fellAsLayers ? layers : FULL;

    const initialLeft = left;
    const retryLater = () => {
        if (left !== initialLeft) {
            faller.setDynamicProperty(PROP_BLOCK, layerForm);
            faller.setDynamicProperty(PROP_LAYERS, left);
            faller.setProperty(SHAPE_PROPERTY, left);
        }
        return false;
    };

    let blockedByFaller = false;

    for (let step = 0; step < STACK_SEARCH; step++) {
        const at = { x: cell.x, y: cell.y + step, z: cell.z };
        const target = dimension.getBlock(at);
        if (target === undefined) {
            if (step === 0) {
                return retryLater();
            }
            break;
        }

        if (isLayer(target) && target.typeId === layerForm) {
            const standing = layerCount(target.permutation);
            const room = FULL - standing;
            if (room > 0) {
                const added = Math.min(room, left);
                target.setPermutation(BlockPermutation.resolve(layerForm, { [LAYERS_STATE]: standing + added - 1 }));
                dimension.playSound(SOUND, target.center());
                left -= added;
                if (left === 0) {
                    faller.remove();
                    return true;
                }
            }
            continue;
        }

        if (target.isAir || target.isLiquid) {
            if (vanillaFallerIn(dimension, at) || heldByOther(dimension, at, faller)) {
                blockedByFaller = true;
                continue;
            }
            const support = dimension.getBlock({ x: at.x, y: at.y - 1, z: at.z });
            if (support !== undefined && !fillsTopOfCell(support, layerForm)) {
                return retryLater();
            }
            if (!fellAsLayers && left === FULL) {
                placeAt(dimension, at, typeId, undefined);
            }
            else {
                placeAt(dimension, at, layerForm, left);
            }
            faller.remove();
            return true;
        }
    }

    if (blockedByFaller) {
        return retryLater();
    }

    if (!fellAsLayers && left === FULL) {
        dropAt(dimension, cell, typeId, 1);
    }
    else {
        dropAt(dimension, cell, layerForm, left);
    }
    faller.remove();
    return true;
}

const falling = new Map();

function land(faller, cell) {
    try {
        if (settle(faller, cell) === false) {
            falling.set(faller, { y: null, vy: 0, tick: null, arrived: null, cell });
            return;
        }
        falling.delete(faller);
        release(faller);
    }
    catch {
        release(faller);
        falling.set(faller, { y: null, vy: 0, tick: null, arrived: null, cell: null });
    }
}

function columnOf(faller) {
    const storedX = faller.getDynamicProperty(PROP_X);
    const storedZ = faller.getDynamicProperty(PROP_Z);
    const loc = faller.location;
    return {
        x: typeof storedX === "number" ? storedX : Math.floor(loc.x),
        z: typeof storedZ === "number" ? storedZ : Math.floor(loc.z)
    };
}

function advance(faller, state) {
    const dimension = faller.dimension;
    const column = columnOf(faller);
    const typeId = faller.getDynamicProperty(PROP_BLOCK);
    const fellAsLayers = typeof faller.getDynamicProperty(PROP_LAYERS) === "number";
    const layerForm = typeof typeId === "string"
        ? (fellAsLayers ? typeId : `${typeId}_layer`)
        : "";

    if (state.y === null) {
        state.y = faller.location.y;
        const stored = faller.getDynamicProperty(PROP_VY);
        state.vy = typeof stored === "number" ? stored : 0;
    }

    const now = system.currentTick;
    const steps = state.tick === null ? 1 : Math.min(Math.max(now - state.tick, 1), MAX_CATCH_UP);
    state.tick = now;

    let height = state.y;
    let velocity = state.vy;
    for (let i = 0; i < steps; i++) {
        const step = velocity - GRAVITY;
        height += step;
        velocity = step * DRAG;
    }
    const nextHeight = height;

    let stopHeight = null;
    let settleCell = null;
    for (let y = Math.floor(state.y + 0.1); y >= Math.floor(nextHeight); y--) {
        const cell = { x: column.x, y, z: column.z };
        const here = dimension.getBlock(cell);
        if (here === undefined) {
            return;
        }
        if (isLayer(here) && here.typeId === layerForm && layerCount(here.permutation) <= MAX_LAYERS) {
            const top = y + layerCount(here.permutation) * LAYER_HEIGHT;
            if (top <= state.y) {
                stopHeight = top;
                settleCell = cell;
                break;
            }
        }
        else if (y <= state.y + FLOOR_EPS && cellTaken(dimension, here, cell, faller)) {
            const free = freeCellAbove(dimension, column, y, faller);
            if (free !== null) {
                stopHeight = free;
                settleCell = { x: column.x, y: free, z: column.z };
                break;
            }
        }

        const below = dimension.getBlock({ x: column.x, y: y - 1, z: column.z });
        if (below === undefined) {
            return;
        }
        if (fillsTopOfCell(below, layerForm)) {
            stopHeight = y;
            settleCell = cell;
            break;
        }
    }

    if (stopHeight !== null && nextHeight <= stopHeight) {
        const rush = vanillaFallerAbove(dimension, column, stopHeight);

        const moved = state.cell !== null && state.cell.y !== settleCell.y;
        if (state.arrived === null || moved) {
            state.arrived = now;
            state.y = stopHeight;
            state.vy = 0;
            state.cell = settleCell;
            reserve(faller, settleCell);
            faller.setDynamicProperty(PROP_VY, 0);
            faller.teleport({ x: column.x + 0.5, y: stopHeight, z: column.z + 0.5 });
            if (!rush) {
                return;
            }
        }
        if (rush || now - state.arrived >= LANDING_HOLD) {
            land(faller, state.cell);
        }
        return;
    }

    if (state.arrived !== null) {
        state.arrived = null;
        state.cell = null;
        release(faller);
    }

    state.y = nextHeight;
    state.vy = velocity;
    faller.setDynamicProperty(PROP_VY, state.vy);
    faller.teleport({ x: column.x + 0.5, y: nextHeight, z: column.z + 0.5 });
}

system.runInterval(() => {
    if (falling.size === 0) {
        return;
    }
    for (const [faller, state] of [...falling]) {
        if (!faller.isValid) {
            release(faller);
            falling.delete(faller);
            continue;
        }
        try {
            advance(faller, state);
        }
        catch {
            release(faller);
            falling.delete(faller);
        }
    }
}, 1);

system.beforeEvents.startup.subscribe((init) => {
    init.blockComponentRegistry.registerCustomComponent("dd:falling_block", {
        onPlace(event) {
            checkFalling(event.block);
        },
        onTick(event) {
            checkFalling(event.block);
        }
    });
});

world.beforeEvents.playerBreakBlock.subscribe((event) => {
    const dimension = event.dimension;
    const { x, y, z } = event.block.location;
    system.run(() => checkAround(dimension, { x, y, z }));
});

world.afterEvents.playerBreakBlock.subscribe((event) => {
    checkAround(event.dimension, event.block.location);
});

world.afterEvents.entitySpawn.subscribe((event) => {
    let dimension;
    let location;
    try {
        if (event.entity.typeId !== VANILLA_FALLER) {
            return;
        }
        dimension = event.entity.dimension;
        location = event.entity.location;
    }
    catch {
        return;
    }
    const EPSILON = 0.001;
    const from = Math.ceil(location.y - EPSILON);

    const above = {
        x: Math.floor(location.x),
        y: from + 1,
        z: Math.floor(location.z)
    };
    const start = () => {
        try {
            checkFalling(dimension.getBlock(above));
        }
        catch {
        }
    };
    const wait = CASCADE_DELAY - AFTER_EVENT_LAG;
    if (wait <= 0) {
        start();
    }
    else {
        system.runTimeout(start, wait);
    }
});

world.afterEvents.playerPlaceBlock.subscribe((event) => {
    checkAround(event.dimension, event.block.location);
});

world.afterEvents.blockExplode.subscribe((event) => {
    checkAround(event.dimension, event.block.location);
});

let sweeping = false;

system.runInterval(() => {
    if (sweeping) {
        return;
    }
    sweeping = true;
    system.runJob(sweepJob());
}, SWEEP_INTERVAL);

function* sweepJob() {
    try {
        let visited = 0;
        for (const id of [...SWEEP_DIMENSIONS]) {
            let fallers;
            try {
                fallers = world.getDimension(id).getEntities({ type: ENTITY_ID });
            }
            catch {
                continue;
            }
            for (const faller of fallers) {
                if (visited >= SWEEP_LIMIT) {
                    return;
                }
                visited++;
                try {
                    if (faller.isValid) {
                        if (!falling.has(faller)) {
                            falling.set(faller, { y: null, vy: 0, tick: null, arrived: null, cell: null });
                        }
                        sweep(faller);
                    }
                }
                catch {
                }
                if (visited % SWEEP_BATCH === 0) {
                    yield;
                }
            }
            yield;
        }
    }
    finally {
        sweeping = false;
    }
}

function sweep(faller) {
    const age = ((faller.getDynamicProperty(PROP_AGE) ?? 0) | 0) + SWEEP_INTERVAL;
    faller.setDynamicProperty(PROP_AGE, age);

    if (age > MAX_FALL_TICKS) {
        const typeId = faller.getDynamicProperty(PROP_BLOCK);
        const stored = faller.getDynamicProperty(PROP_LAYERS);
        if (typeof typeId === "string") {
            dropAt(faller.dimension, cellOf(faller), typeId, typeof stored === "number" ? stored : 1);
        }
        release(faller);
        falling.delete(faller);
        faller.remove();
    }
}
