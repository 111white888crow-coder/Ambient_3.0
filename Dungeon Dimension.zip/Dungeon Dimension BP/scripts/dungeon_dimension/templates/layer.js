import { BlockPermutation, ItemStack, system } from "@minecraft/server";

export const LAYERS_STATE = "dd:layers";
export const MAX_LAYERS = 7;
const LAYER_TAG = "dd:layer";

export function isLayer(block) {
    try {
        return block !== undefined && block.hasTag(LAYER_TAG);
    }
    catch {
        return false;
    }
}

export function layerCount(permutation) {
    const value = permutation.getAllStates()[LAYERS_STATE];
    return (typeof value === "number" ? value : 0) + 1;
}

system.beforeEvents.startup.subscribe((init) => {
    init.blockComponentRegistry.registerCustomComponent("dd:layer_stacking", {
        beforeOnPlayerPlace(event) {
            const target = event.block;
            const id = event.permutationToPlace.type.id;

            if (target.typeId !== id) {
                return;
            }

            const current = target.permutation.getAllStates()[LAYERS_STATE];
            const height = typeof current === "number" ? current : 0;

            if (height >= MAX_LAYERS) {
                return;
            }

            event.permutationToPlace = BlockPermutation.resolve(id, { [LAYERS_STATE]: height + 1 });
        },

        onPlayerBreak(event) {
            if (event.player?.getGameMode() === "Creative") {
                return;
            }
            const permutation = event.brokenBlockPermutation;
            const count = layerCount(permutation);
            const dimension = event.dimension;
            const at = event.block.center();
            system.run(() => {
                try {
                    dimension.spawnItem(new ItemStack(permutation.type.id, count), at);
                }
                catch {
                }
            });
        }
    });
});
