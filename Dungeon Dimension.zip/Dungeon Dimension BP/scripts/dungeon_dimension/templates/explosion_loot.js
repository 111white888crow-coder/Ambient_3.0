import { ItemStack, world } from "@minecraft/server";

const EXPLOSION_TOOL = "minecraft:diamond_pickaxe";

const POWER = {
    "minecraft:tnt": 4,
    "minecraft:tnt_minecart": 4,
    "minecraft:creeper": 3,
    "minecraft:ender_crystal": 6,
    "minecraft:fireball": 1,
    "minecraft:wither_skull": 1,
    "minecraft:wither_skull_dangerous": 1,
    "minecraft:wither": 7
};
const CHARGED_CREEPER_POWER = 6;
const SOURCELESS_POWER = 5;
const TNT = new Set(["minecraft:tnt", "minecraft:tnt_minecart"]);

let explosionTool;

function dropChance(source) {
    const typeId = source?.typeId;
    if (typeId === undefined) {
        return 1 / SOURCELESS_POWER;
    }
    if (TNT.has(typeId)) {
        return world.gameRules.tntExplosionDropDecay ? 1 / POWER[typeId] : 1;
    }
    if (typeId === "minecraft:creeper") {
        let charged = false;
        try {
            charged = source.getComponent("minecraft:is_charged") !== undefined;
        }
        catch {
        }
        return 1 / (charged ? CHARGED_CREEPER_POWER : POWER[typeId]);
    }
    return 1 / (POWER[typeId] ?? SOURCELESS_POWER);
}

world.afterEvents.blockExplode.subscribe((event) => {
    const permutation = event.explodedBlockPermutation;
    if (permutation.type.id.startsWith("minecraft:")) {
        return;
    }
    const loot = world.getLootTableManager();
    const bare = loot.generateLootFromBlockPermutation(permutation);
    if (bare !== undefined && bare.length > 0) {
        return;
    }
    if (Math.random() >= dropChance(event.source)) {
        return;
    }
    explosionTool ??= new ItemStack(EXPLOSION_TOOL, 1);
    const drops = loot.generateLootFromBlockPermutation(permutation, explosionTool);
    if (drops === undefined || drops.length === 0) {
        return;
    }
    const where = event.block.center();
    for (const stack of drops) {
        try {
            event.dimension.spawnItem(stack, where);
        }
        catch {
        }
    }
});
