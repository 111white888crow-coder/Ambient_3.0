import { world, system, Player, GameMode } from "@minecraft/server";

const ENVELOPE_ID = "dd:envelope";
const ENVELOPE_TABLE = "dd/envelope/envelope";

const busy = new Set();

let tableWarned = false;

function rollLoot(path, tool) {
  const manager = world.getLootTableManager();
  const table = manager.getLootTable(path);
  if (!table) {
    if (!tableWarned) {
      tableWarned = true;
      console.warn(`Таблица лута не найдена: ${path}`);
    }
    return null;
  }
  const loot = manager.generateLootFromTable(table, tool);
  return loot?.length ? loot : null;
}

function takeOne(player, slot, item) {
  if (player.getGameMode() === GameMode.Creative) return;

  const container = player.getComponent("minecraft:inventory")?.container;
  if (!container) return;

  if (item.amount <= 1) {
    container.setItem(slot, undefined);
  } else {
    const rest = item.clone();
    rest.amount -= 1;
    container.setItem(slot, rest);
  }
}

function dropLoot(dimension, loot, loc) {
  const points = [{ x: loc.x, y: loc.y + 1, z: loc.z }, loc];

  for (const stack of loot) {
    let dropped = false;
    for (const point of points) {
      try {
        dimension.spawnItem(stack, point);
        dropped = true;
        break;
      } catch { }
    }
    if (!dropped) console.warn(`Не удалось выдать лут конверта: ${stack.typeId}`);
  }
}

function openEnvelope(player) {
  if (!player.isValid) return;

  const container = player.getComponent("minecraft:inventory")?.container;
  const slot = player.selectedSlotIndex;
  if (!container) return;

  const item = container.getItem(slot);
  if (item?.typeId !== ENVELOPE_ID) return;

  const loot = rollLoot(ENVELOPE_TABLE, item);
  if (!loot) return;

  takeOne(player, slot, item);

  system.runTimeout(() => {
    if (!player.isValid) return;
    const loc = player.location;
    const dimension = player.dimension;

    dropLoot(dimension, loot, loc);

    try {
      player.playSound("dd.envelope.sound");
    } catch { }
  }, 1);
}

function handle(event) {
  const player = event.source;
  if (!(player instanceof Player)) return;
  if (busy.has(player.id)) return;
  busy.add(player.id);

  system.runTimeout(() => {
    try {
      openEnvelope(player);
    } finally {
      busy.delete(player.id);
    }
  }, 2);
}

export const EnvelopeLoot = {
  onUse: handle,
  onUseOn: handle
};
