import { system, world, } from "@minecraft/server";
import { ddTriggers } from "../ddTriggers.js";
import { CHAINS, LANTERNS, NO_WALL_CONNECT, PANES, RODS, SKULLS, WALL_COVER_CENTRE, WALL_COVER_FULL, matches } from "../data/blockSets.js";
import { faceIsFull, stairFullFaces } from "../utils/blockChecks.js";
const WALL_TAG = "dd:wall";
const SIDES = ["north", "south", "east", "west"];
const POST_COVER = "dd:post_cover";
const TALL = {
    north: "dd:tall_north",
    south: "dd:tall_south",
    east: "dd:tall_east",
    west: "dd:tall_west",
};
const CONNECTION = {
    north: "dd:connection_north",
    south: "dd:connection_south",
    east: "dd:connection_east",
    west: "dd:connection_west",
};
const MANAGED = [...Object.values(CONNECTION), POST_COVER, ...Object.values(TALL)];
const STEP = {
    north: { x: 0, y: 0, z: -1 },
    south: { x: 0, y: 0, z: 1 },
    east: { x: 1, y: 0, z: 0 },
    west: { x: -1, y: 0, z: 0 },
};
const OPPOSITE = { north: "south", south: "north", east: "west", west: "east" };
const AXIS = { north: "z", south: "z", east: "x", west: "x" };
const FENCE_CONNECTIONS_TAG = "minecraft:has_fence_connections";
const VANILLA_ARMS = {
    north: "minecraft:connection_north",
    south: "minecraft:connection_south",
    east: "minecraft:connection_east",
    west: "minecraft:connection_west",
};
const NETHER_FENCE = "minecraft:nether_brick_fence";
const TRAPDOOR_SIDE = ["west", "east", "north", "south"];
const VANILLA_POST = "wall_post_bit";
const VANILLA_CONNECTION = {
    north: "wall_connection_type_north",
    south: "wall_connection_type_south",
    east: "wall_connection_type_east",
    west: "wall_connection_type_west",
};
const POST_OVERRIDE_IDS = new Set([
    "minecraft:torch",
    "minecraft:soul_torch",
    "minecraft:redstone_torch",
    "minecraft:unlit_redstone_torch",
    "minecraft:copper_torch",
    "minecraft:underwater_torch",
    "minecraft:colored_torch_blue",
    "minecraft:colored_torch_green",
    "minecraft:colored_torch_purple",
    "minecraft:colored_torch_red",
    "minecraft:trip_wire",
    "minecraft:standing_banner",
    "minecraft:wall_banner",
    "minecraft:standing_sign",
    "minecraft:wall_sign",
]);
const POST_OVERRIDE_SUFFIXES = [
    "_pressure_plate",
    "_standing_sign",
    "_wall_sign",
];
const POST_OVERRIDE_TAG = "dd:wall_post_override";
const NOTHING = {
    centre: false,
    sides: { north: false, south: false, east: false, west: false },
    forcesPost: false,
};
const EVERYTHING = {
    centre: true,
    sides: { north: true, south: true, east: true, west: true },
    forcesPost: false,
};
const CENTRE_ONLY = {
    centre: true,
    sides: { north: false, south: false, east: false, west: false },
    forcesPost: false,
};
function connected(states, side) {
    return states[CONNECTION[side]] === true;
}
function structuralPost(states) {
    const north = connected(states, "north");
    const south = connected(states, "south");
    const east = connected(states, "east");
    const west = connected(states, "west");
    const bare = !north && !south && !east && !west;
    return bare || north !== south || east !== west;
}
function coverFromArms(post, sides) {
    return {
        centre: post || sides.north || sides.south || sides.east || sides.west,
        sides,
        forcesPost: post,
    };
}
function coverFromPostAndArms(sides) {
    return { centre: true, sides, forcesPost: false };
}
function coverFromWall(above) {
    const states = above.permutation.getAllStates();
    return coverFromArms(showsPost(above), {
        north: connected(states, "north"),
        south: connected(states, "south"),
        east: connected(states, "east"),
        west: connected(states, "west"),
    });
}
function coverFromVanillaWall(states) {
    return coverFromArms(states[VANILLA_POST] === true, {
        north: states[VANILLA_CONNECTION.north] !== "none",
        south: states[VANILLA_CONNECTION.south] !== "none",
        east: states[VANILLA_CONNECTION.east] !== "none",
        west: states[VANILLA_CONNECTION.west] !== "none",
    });
}
function coverFromGate(states) {
    if (states.open_bit === true || states["dd:open_bit"] === true) {
        return NOTHING;
    }
    const facing = AXIS[states["minecraft:cardinal_direction"]];
    if (facing === undefined) {
        return NOTHING;
    }
    const sides = {};
    for (const side of SIDES) {
        sides[side] = AXIS[side] !== facing;
    }
    return { centre: true, sides, forcesPost: false };
}
function isPostOverride(block) {
    if (POST_OVERRIDE_IDS.has(block.typeId)) {
        return true;
    }
    for (const suffix of POST_OVERRIDE_SUFFIXES) {
        if (block.typeId.endsWith(suffix)) {
            return true;
        }
    }
    return block.hasTag(POST_OVERRIDE_TAG);
}
function isWall(block) {
    try {
        return block !== undefined && block.hasTag(WALL_TAG);
    }
    catch {
        return false;
    }
}
function isVanillaWall(states) {
    return typeof states[VANILLA_POST] === "boolean";
}
function isPane(block) {
    return matches(block.typeId, PANES);
}
function isGate(block) {
    return block.typeId === "minecraft:fence_gate" || block.typeId.endsWith("_fence_gate");
}
function isFence(block) {
    if (block.typeId.startsWith("minecraft:")) {
        return block.typeId.endsWith("_fence");
    }
    return block.hasTag(FENCE_CONNECTIONS_TAG) && !isGate(block) && !isWall(block) && !block.typeId.endsWith("_wall");
}
function coversCentre(block, states) {
    const id = block.typeId;
    if (matches(id, WALL_COVER_CENTRE)) {
        return true;
    }
    if (matches(id, LANTERNS) && typeof states.hanging === "boolean") {
        return !states.hanging;
    }
    if (matches(id, CHAINS) && typeof states.pillar_axis === "string") {
        return states.pillar_axis === "y";
    }
    if (matches(id, RODS) && typeof states.facing_direction === "number") {
        return states.facing_direction === 0 || states.facing_direction === 1;
    }
    if (matches(id, SKULLS) && typeof states.facing_direction === "number") {
        return states.facing_direction === 1;
    }
    return false;
}
function coverAbove(wall) {
    let above;
    try {
        above = wall.above();
    }
    catch {
        return NOTHING;
    }
    if (above === undefined || above.isAir || above.isLiquid) {
        return NOTHING;
    }
    if (isWall(above)) {
        return coverFromWall(above);
    }
    const states = above.permutation.getAllStates();
    if (isVanillaWall(states)) {
        return coverFromVanillaWall(states);
    }
    if (isPostOverride(above)) {
        return CENTRE_ONLY;
    }
    if (isGate(above)) {
        return coverFromGate(states);
    }
    if (isFence(above)) {
        return coverFromPostAndArms(armsOf(above, states, fenceAttaches));
    }
    if (isPane(above)) {
        return coverFromPostAndArms(armsOf(above, states, paneAttaches));
    }
    if (matches(above.typeId, WALL_COVER_FULL)) {
        return EVERYTHING;
    }
    if (coversCentre(above, states)) {
        return CENTRE_ONLY;
    }
    return faceIsFull(above, states, "down") ? EVERYTHING : NOTHING;
}
function tallSides(states, cover) {
    return {
        north: connected(states, "north") && cover.sides.north,
        south: connected(states, "south") && cover.sides.south,
        east: connected(states, "east") && cover.sides.east,
        west: connected(states, "west") && cover.sides.west,
    };
}
function postFor(cover, tall) {
    if (cover.forcesPost) {
        return true;
    }
    if ((tall.north && tall.south) || (tall.east && tall.west)) {
        return false;
    }
    return cover.centre;
}
function shapeFor(wall, states = wall.permutation.getAllStates()) {
    const cover = coverAbove(wall);
    const tall = tallSides(states, cover);
    return { post: postFor(cover, tall), tall };
}
function showsPost(wall) {
    if (structuralPost(wall.permutation.getAllStates())) {
        return true;
    }
    return shapeFor(wall).post;
}
function gateConnects(states, side) {
    const facing = states["minecraft:cardinal_direction"];
    return AXIS[facing] !== undefined && AXIS[facing] !== AXIS[side];
}
function solidToward(neighbour, states, side) {
    const stairFaces = stairFullFaces(neighbour, states);
    if (stairFaces !== null) {
        return stairFaces.includes(OPPOSITE[side]);
    }
    if (neighbour.typeId.endsWith("trapdoor") && typeof states.direction === "number") {
        return states.open_bit === true && TRAPDOOR_SIDE[states.direction] === OPPOSITE[side];
    }
    if (matches(neighbour.typeId, NO_WALL_CONNECT)) {
        return false;
    }
    return faceIsFull(neighbour, states, "side");
}
function connectsTo(neighbour, side) {
    if (neighbour === undefined || neighbour === null) {
        return false;
    }
    try {
        if (neighbour.isAir || neighbour.isLiquid) {
            return false;
        }
        const states = neighbour.permutation.getAllStates();
        if (isWall(neighbour) || isVanillaWall(states) || isPane(neighbour)) {
            return true;
        }
        if (isGate(neighbour)) {
            return gateConnects(states, side);
        }
        if (isFence(neighbour)) {
            return false;
        }
        return solidToward(neighbour, states, side);
    }
    catch {
        return false;
    }
}
function fenceAttaches(neighbour, side, fence) {
    if (neighbour === undefined || neighbour === null) {
        return false;
    }
    try {
        if (neighbour.isAir || neighbour.isLiquid) {
            return false;
        }
        const states = neighbour.permutation.getAllStates();
        if (isGate(neighbour)) {
            return gateConnects(states, side);
        }
        if (isFence(neighbour)) {
            return (fence.typeId === NETHER_FENCE) === (neighbour.typeId === NETHER_FENCE);
        }
        if (isWall(neighbour) || isVanillaWall(states) || isPane(neighbour)) {
            return false;
        }
        return solidToward(neighbour, states, side);
    }
    catch {
        return false;
    }
}
function paneAttaches(neighbour, side) {
    if (neighbour === undefined || neighbour === null) {
        return false;
    }
    try {
        if (neighbour.isAir || neighbour.isLiquid) {
            return false;
        }
        const states = neighbour.permutation.getAllStates();
        if (isPane(neighbour) || isWall(neighbour) || isVanillaWall(states)) {
            return true;
        }
        if (isGate(neighbour) || isFence(neighbour)) {
            return false;
        }
        return solidToward(neighbour, states, side);
    }
    catch {
        return false;
    }
}
function neighbourOf(block, side) {
    try {
        return block.offset(STEP[side]);
    }
    catch {
        return undefined;
    }
}
function armsOf(block, states, attaches) {
    const arms = {};
    for (const side of SIDES) {
        const stored = states[VANILLA_ARMS[side]];
        arms[side] = typeof stored === "boolean" ? stored : attaches(neighbourOf(block, side), side, block);
    }
    return arms;
}
function connectionsFor(block) {
    const sides = {};
    for (const side of SIDES) {
        sides[side] = connectsTo(neighbourOf(block, side), side);
    }
    return sides;
}
function shapeStates(block, states) {
    const next = { ...states };
    const sides = connectionsFor(block);
    for (const side of SIDES) {
        next[CONNECTION[side]] = sides[side];
    }
    const { post, tall } = shapeFor(block, next);
    next[POST_COVER] = post;
    for (const side of SIDES) {
        next[TALL[side]] = tall[side];
    }
    return next;
}
function withShape(permutation, states, next) {
    let result = permutation;
    for (const name of MANAGED) {
        if (states[name] !== next[name]) {
            result = result.withState(name, next[name]);
        }
    }
    return result;
}
function refresh(wall) {
    const current = wall.permutation;
    const states = current.getAllStates();
    const permutation = withShape(current, states, shapeStates(wall, states));
    if (permutation === current) {
        return;
    }
    wall.setPermutation(permutation);
    refreshWallAt(wall.dimension, { x: wall.x, y: wall.y - 1, z: wall.z });
}
function refreshWallAt(dimension, position) {
    try {
        const block = dimension.getBlock(position);
        if (isWall(block)) {
            refresh(block);
        }
    }
    catch {
    }
}
function refreshAround(dimension, position) {
    const { x, y, z } = position;
    const cells = [
        { x, y, z },
        { x: x + 1, y, z },
        { x: x - 1, y, z },
        { x, y, z: z + 1 },
        { x, y, z: z - 1 },
    ];
    for (const cell of cells) {
        refreshWallAt(dimension, cell);
        refreshWallAt(dimension, { x: cell.x, y: cell.y - 1, z: cell.z });
    }
}
function scheduleRefresh(dimension, position) {
    const { x, y, z } = position;
    system.run(() => refreshAround(dimension, { x, y, z }));
}
system.beforeEvents.startup.subscribe((init) => {
    init.blockComponentRegistry.registerCustomComponent("dd:wall_above", {
        beforeOnPlayerPlace(event) {
            const states = event.permutationToPlace.getAllStates();
            event.permutationToPlace = withShape(event.permutationToPlace, states, shapeStates(event.block, states));
        },
        onPlace(event) {
            scheduleRefresh(event.block.dimension, event.block.location);
        },
    });
});
world.afterEvents.playerPlaceBlock.subscribe((event) => {
    refreshAround(event.dimension, event.block.location);
});
world.afterEvents.playerBreakBlock.subscribe((event) => {
    refreshAround(event.dimension, event.block.location);
});
world.afterEvents.playerInteractWithBlock.subscribe((event) => {
    refreshAround(event.block.dimension, event.block.location);
});
ddTriggers.registerBehaviourByTag(WALL_TAG, {
    onAdjacentChange(event) {
        if (event.player !== undefined) {
            return;
        }
        refreshWallAt(event.dimension, event.block.location);
    },
});
world.afterEvents.blockExplode.subscribe((event) => {
    scheduleRefresh(event.dimension, event.block.location);
});
world.afterEvents.pistonActivate.subscribe((event) => {
    const dimension = event.dimension;
    const locations = [event.block.location];
    try {
        locations.push(...event.piston.getAttachedBlocksLocations());
    }
    catch {
    }
    system.runTimeout(() => {
        for (const location of locations) {
            refreshAround(dimension, location);
        }
    }, 3);
});
