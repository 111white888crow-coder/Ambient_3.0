import { world, system } from '@minecraft/server';
import { TaskScheduler } from "../utils/TaskScheduler.js";

system.beforeEvents.startup.subscribe((init) => {
    init.blockComponentRegistry.registerCustomComponent("dd:button_config", {
        onPlayerInteract(e, p) {
            const { block, player, dimension } = e;
            const { on_sound, off_sound } = p.params;

            const state = block.permutation.getState("dd:button_pressed_bit");
            if (state === true) return;

            block.setPermutation(block.permutation.withState("dd:button_pressed_bit", true));

            if (on_sound) block.dimension.playSound(on_sound, block.center(), { pitch: 1.25 });

            TaskScheduler.schedule(block, "dd:button_active", 30, { sound: off_sound });
        }
    });
});

TaskScheduler.register("dd:button_active", ({ block, data }) => {
    if (block) {
        block.setPermutation(block.permutation.withState("dd:button_pressed_bit", false));
        if (data.sound) block.dimension.playSound(data.sound, block.center());
    }
});

world.afterEvents.playerBreakBlock.subscribe((e) => {
    const { block, brokenBlockPermutation } = e;

    if (brokenBlockPermutation.getState("dd:button_pressed_bit") === true) {
        TaskScheduler.cancel(block);
    }
});
