import { world, system, EquipmentSlot, BlockPermutation } from "@minecraft/server";
import { ddTriggers } from "../ddTriggers.js";

const SOUND_PARAM = "param__placing_sound__";

const adjacentFunction = {
    Down: b => b.above(),
    Up: b => b.below()
};

const FACE_OFFSET = {
    Up: { x: 0, y: 1, z: 0 },
    Down: { x: 0, y: -1, z: 0 },
    North: { x: 0, y: 0, z: -1 },
    South: { x: 0, y: 0, z: 1 },
    East: { x: 1, y: 0, z: 0 },
    West: { x: -1, y: 0, z: 0 }
};

const slabItemCache = new Map();

function isSlabItem(typeId) {
    let known = slabItemCache.get(typeId);
    if (known === undefined) {
        try { known = BlockPermutation.resolve(typeId).hasTag("dd:slab"); }
        catch { known = false; }
        slabItemCache.set(typeId, known);
    }
    return known;
}

function mergesIntoDoubleSlab(slabBlock, face, toPlaceId) {
    if (!slabBlock || slabBlock.typeId !== toPlaceId) return false;
    if (slabBlock.permutation.getState("dd:block_bit") === true) return false;

    const verticalHalf = slabBlock.permutation.getState("minecraft:vertical_half");
    return (face === "Down" && verticalHalf === "top") ||
           (face === "Up" && verticalHalf === "bottom");
}

function placingSound(block) {
    for (const t of block.getTags()) {
        if (t.startsWith(SOUND_PARAM)) return t.slice(SOUND_PARAM.length);
    }
    return null;
}

function consumeOne(player, itemStack) {
    if (player.getGameMode() === "Creative") return;

    const equippable = player.getComponent("minecraft:equippable");
    if (!equippable) return;

    const held = equippable.getEquipment(EquipmentSlot.Mainhand);
    if (!held || held.typeId !== itemStack?.typeId) return;

    if (held.amount > 1) {
        held.amount -= 1;
        equippable.setEquipment(EquipmentSlot.Mainhand, held);
    } else {
        equippable.setEquipment(EquipmentSlot.Mainhand, undefined);
    }
}

function makeDouble(slabBlock, player, itemStack) {
    slabBlock.setPermutation(slabBlock.permutation.withState("dd:block_bit", true));

    const sound = placingSound(slabBlock);
    if (sound) slabBlock.dimension.playSound(sound, slabBlock.center());

    consumeOne(player, itemStack);

    ddTriggers.notifyNeighbours(slabBlock, { player });
}

system.beforeEvents.startup.subscribe((init) => {
    init.blockComponentRegistry.registerCustomComponent("dd:slab_config", {
        beforeOnPlayerPlace(e) {
            const { block, permutationToPlace, face } = e;

            if (face !== "Down" && face !== "Up") return;

            const slabBlock = adjacentFunction[face](block);
            if (mergesIntoDoubleSlab(slabBlock, face, permutationToPlace.type.id)) {
                e.cancel = true;
            }
        },
        onBlockStateChange(e) {
            ddTriggers.notifyNeighbours(e.block);
        }
    });
});

ddTriggers.registerBehaviourByTag("dd:slab", {
    customFilter: (itemStack, block, face) => {
        if (!itemStack) return false;
        return mergesIntoDoubleSlab(block, face, itemStack.typeId);
    },
    onInteract(e) {
        makeDouble(e.block, e.player, e.itemStack);
    }
});

world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
    const { block, blockFace, player, itemStack, isFirstEvent } = event;
    if (!isFirstEvent || !itemStack || !block || !player) return;
    if (!isSlabItem(itemStack.typeId)) return;
    if (mergesIntoDoubleSlab(block, blockFace, itemStack.typeId)) return;

    const offset = FACE_OFFSET[blockFace];
    if (!offset) return;

    const loc = block.location;
    let target;
    try {
        target = block.dimension.getBlock({ x: loc.x + offset.x, y: loc.y + offset.y, z: loc.z + offset.z });
    } catch { return; }

    if (!target || target.typeId !== itemStack.typeId) return;
    if (target.permutation.getState("dd:block_bit") === true) return;

    event.cancel = true;
    system.run(() => makeDouble(target, player, itemStack));
});
