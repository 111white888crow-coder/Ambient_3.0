import { system } from "@minecraft/server";

function chanceOf(params) {
    const value = Number(params.chance);
    return Number.isFinite(value) ? value / 100 : 1;
}

system.beforeEvents.startup.subscribe((init) => {
    init.blockComponentRegistry.registerCustomComponent("dd:ambient_particles", {
        onTick(event, { params }) {
            const particle = params.particle;
            if (typeof particle !== "string") {
                return;
            }
            if (Math.random() >= chanceOf(params)) {
                return;
            }
            try {
                event.dimension.spawnParticle(particle, event.block.center());
            }
            catch {
            }
        }
    });
});
