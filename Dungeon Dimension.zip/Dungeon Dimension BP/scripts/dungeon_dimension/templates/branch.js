import { world, system, EquipmentSlot, GameMode } from "@minecraft/server";
import { ddTriggers } from "../ddTriggers.js";

const BRANCH_TAG = "dd:branch";
const BIT_STATE = "dd:branch_bit";
const LEAVES_STATE = "dd:leaves";
const FACE_STATE = "minecraft:block_face";

const SLOTS = ["north", "south", "west", "east"];

const SLOT_OFFSETS = {
    up: {
        north: { x: 0, y: 0, z: -1 },
        south: { x: 0, y: 0, z: 1 },
        west: { x: -1, y: 0, z: 0 },
        east: { x: 1, y: 0, z: 0 }
    },

    down: {
        north: { x: 0, y: 0, z: -1 },
        south: { x: 0, y: 0, z: 1 },
        west: { x: -1, y: 0, z: 0 },
        east: { x: 1, y: 0, z: 0 }
    },

    north: {
        north: { x: 0, y: -1, z: 0 },
        south: { x: 0, y: 1, z: 0 },
        west: { x: -1, y: 0, z: 0 },
        east: { x: 1, y: 0, z: 0 }
    },

    south: {
        north: { x: 0, y: 1, z: 0 },
        south: { x: 0, y: -1, z: 0 },
        west: { x: -1, y: 0, z: 0 },
        east: { x: 1, y: 0, z: 0 }
    },

    west: {
        north: { x: 0, y: -1, z: 0 },
        south: { x: 0, y: 1, z: 0 },
        west: { x: 0, y: 0, z: 1 },
        east: { x: 0, y: 0, z: -1 }
    },

    east: {
        north: { x: 0, y: -1, z: 0 },
        south: { x: 0, y: 1, z: 0 },
        west: { x: 0, y: 0, z: -1 },
        east: { x: 0, y: 0, z: 1 }
    }
};

const LEAF_BY_ITEM = new Map([
    ["minecraft:oak_leaves", "oak"],
    ["minecraft:spruce_leaves", "spruce"],
    ["minecraft:birch_leaves", "birch"],
    ["minecraft:jungle_leaves", "jungle"],
    ["minecraft:acacia_leaves", "acacia"],
    ["minecraft:dark_oak_leaves", "dark_oak"],
    ["minecraft:mangrove_leaves", "mangrove"],
    ["minecraft:cherry_leaves", "cherry"],
    ["minecraft:pale_oak_leaves", "pale_oak"],
    ["minecraft:azalea_leaves", "azalea"],
    ["minecraft:azalea_leaves_flowered", "flowering_azalea"],
    ["dd:wild_birch_yellow_leaves", "yellow"],
    ["dd:wild_birch_orange_leaves", "orange"]
]);

const FACE_OFFSETS = [
    { x: 0, y: 0, z: -1 },
    { x: 0, y: 0, z: 1 },
    { x: -1, y: 0, z: 0 },
    { x: 1, y: 0, z: 0 },
    { x: 0, y: 1, z: 0 },
    { x: 0, y: -1, z: 0 },
];

function isBranch(block) {
    try {
        return block !== undefined && block.hasTag(BRANCH_TAG);
    } catch {
        return false;
    }
}

function slotOffsets(blockFace) {
    return SLOT_OFFSETS[blockFace] ?? SLOT_OFFSETS.up;
}

/*
 * Нормаль нижней грани соседней ветки.
 *
 * Нам нужно, чтобы:
 *
 *       [сосед]
 *       нижняя грань
 *           ↓
 *       [текущая]
 *
 * То есть нижняя сторона соседа должна смотреть НА текущий блок.
 */
const BOTTOM_NORMAL_BY_FACE = {
    up: {
        x: 0,
        y: -1,
        z: 0
    },

    down: {
        x: 0,
        y: -1,
        z: 0
    },

    north: {
        x: 0,
        y: 0,
        z: 1
    },

    south: {
        x: 0,
        y: 0,
        z: -1
    },

    west: {
        x: 1,
        y: 0,
        z: 0
    },

    east: {
        x: -1,
        y: 0,
        z: 0
    },
};

/*
 * Проверяет, разрешено ли соединение с соседом.
 *
 * directionToNeighbour — направление от текущего блока к соседу.
 *
 * Соединение разрешено только если нижняя грань соседа
 * направлена обратно на текущий блок.
 */
function isBottomFacingBlock(neighbour, directionToNeighbour) {
    if (!isBranch(neighbour)) {
        return false;
    }

    const neighbourFace =
        neighbour.permutation.getState(FACE_STATE) ?? "up";

    const bottom =
        BOTTOM_NORMAL_BY_FACE[neighbourFace];

    if (!bottom) {
        return false;
    }

    return (
        bottom.x === -directionToNeighbour.x &&
        bottom.y === -directionToNeighbour.y &&
        bottom.z === -directionToNeighbour.z
    );
}

/*
 * Определяем branch_bit.
 *
 * ВАЖНО:
 * соединение считается только по схеме:
 *
 * бок текущего блока
 *        ↓
 * нижняя сторона соседнего блока
 *
 * Поэтому бок ↔ бок НЕ соединяется.
 */
function activeSlots(block, blockFace) {
    const offsets = slotOffsets(blockFace);
    const active = {};

    for (const slot of SLOTS) {
        let neighbour;

        try {
            neighbour = block.offset(offsets[slot]);
        } catch {
            neighbour = undefined;
        }

        active[slot] =
            isBottomFacingBlock(
                neighbour,
                offsets[slot]
            );
    }

    return active;
}

/*
 * Если соседей нет:
 *
 * branch_bit = none
 *
 * А не north.
 */
function bitName(active) {
    const parts = SLOTS.filter(
        (slot) => active[slot]
    );

    return parts.length > 0
        ? parts.join("_")
        : "none";
}

function shapeFor(block, blockFace) {
    return bitName(
        activeSlots(
            block,
            blockFace
        )
    );
}

function refreshBranch(block) {
    const current = block.permutation;

    const blockFace =
        current.getState(FACE_STATE) ?? "up";

    const next =
        shapeFor(
            block,
            blockFace
        );

    if (
        current.getState(BIT_STATE) === next
    ) {
        return;
    }

    block.setPermutation(
        current.withState(
            BIT_STATE,
            next
        )
    );
}

function refreshBranchNeighbours(block) {
    for (const offset of FACE_OFFSETS) {
        let neighbour;

        try {
            neighbour =
                block.offset(offset);
        } catch {
            continue;
        }

        if (isBranch(neighbour)) {
            refreshBranch(neighbour);
        }
    }
}

function refreshAround(
    dimension,
    location
) {
    const { x, y, z } = location;

    const cells = [
        {
            x,
            y,
            z
        },

        {
            x: x + 1,
            y,
            z
        },

        {
            x: x - 1,
            y,
            z
        },

        {
            x,
            y: y + 1,
            z
        },

        {
            x,
            y: y - 1,
            z
        },

        {
            x,
            y,
            z: z + 1
        },

        {
            x,
            y,
            z: z - 1
        },
    ];

    for (const cell of cells) {
        let block;

        try {
            block =
                dimension.getBlock(cell);
        } catch {
            continue;
        }

        if (isBranch(block)) {
            refreshBranch(block);
        }
    }
}

function leafStateFromItem(itemStack) {
    return itemStack
        ? LEAF_BY_ITEM.get(itemStack.typeId)
        : undefined;
}

function consumeOne(
    player,
    itemStack
) {
    if (player.getGameMode() === GameMode.Creative) {
        return;
    }

    const equippable =
        player.getComponent(
            "minecraft:equippable"
        );

    if (!equippable) {
        return;
    }

    const held =
        equippable.getEquipment(
            EquipmentSlot.Mainhand
        );

    if (
        !held ||
        held.typeId !==
            itemStack?.typeId
    ) {
        return;
    }

    if (held.amount > 1) {
        held.amount -= 1;

        equippable.setEquipment(
            EquipmentSlot.Mainhand,
            held
        );
    } else {
        equippable.setEquipment(
            EquipmentSlot.Mainhand,
            undefined
        );
    }
}

function applyLeaves(
    block,
    player,
    itemStack
) {
    const leaf =
        leafStateFromItem(
            itemStack
        );

    if (leaf === undefined) {
        return;
    }

    const current =
        block.permutation;

    if (
        current.getState(
            LEAVES_STATE
        ) === leaf
    ) {
        return;
    }

    block.setPermutation(
        current.withState(
            LEAVES_STATE,
            leaf
        )
    );

    consumeOne(
        player,
        itemStack
    );
}

system.beforeEvents.startup.subscribe(
    (init) => {
        init.blockComponentRegistry
            .registerCustomComponent(
                "dd:branch_config",
                {
                    onPlace(event) {
                        refreshBranch(
                            event.block
                        );

                        refreshBranchNeighbours(
                            event.block
                        );
                    },

                    onBlockStateChange(event) {
                        ddTriggers.notifyNeighbours(
                            event.block
                        );
                    },
                }
            );
    }
);

ddTriggers.registerBehaviourByTag(
    BRANCH_TAG,
    {
        customFilter: (itemStack, block, _face, player) => {
            if (leafStateFromItem(itemStack) === undefined) {
                return false;
            }

            if (player?.isSneaking) {
                return false;
            }

            try {
                return block?.permutation.getState(LEAVES_STATE) === "none";
            } catch {
                return false;
            }
        },

        onInteract(e) {
            applyLeaves(
                e.block,
                e.player,
                e.itemStack
            );
        },

        onAdjacentChange(event) {
            if (
                event.player !==
                undefined
            ) {
                return;
            }

            refreshBranch(
                event.block
            );
        },
    }
);

world.afterEvents.playerPlaceBlock.subscribe(
    (event) => {
        refreshAround(
            event.dimension,
            event.block.location
        );
    }
);

world.afterEvents.playerBreakBlock.subscribe(
    (event) => {
        refreshAround(
            event.dimension,
            event.block.location
        );
    }
);