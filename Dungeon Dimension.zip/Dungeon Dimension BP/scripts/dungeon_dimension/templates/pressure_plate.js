import { system } from "@minecraft/server";
import { ddTriggers } from "../ddTriggers.js";

const PRESSURE_TAG = "dd:pressure_plate";

const RELEASE_RADIUS = 0.6;

ddTriggers.registerBehaviourByTag(PRESSURE_TAG, {
    onPassingIn(e) {
        const { block } = e;
        const permutation = block.permutation;
        if (permutation.getState(PRESSURE_TAG) === "on") return;
        block.setPermutation(permutation.withState(PRESSURE_TAG, "on"));
    },
    onPassingOut(e) {
        const { block } = e;
        const permutation = block.permutation;
        if (permutation.getState(PRESSURE_TAG) !== "on") return;
        block.setPermutation(permutation.withState(PRESSURE_TAG, "wait"));
    }
});

system.beforeEvents.startup.subscribe((init) => {
    init.blockComponentRegistry.registerCustomComponent("dd:pressure_plate_setting", {
        onTick(e) {
            const { block, dimension } = e;
            const permutation = block.permutation;
            if (permutation.getState(PRESSURE_TAG) !== "wait") return;

            const center = block.center();
            let entities = [];
            try { entities = dimension.getEntities({ maxDistance: RELEASE_RADIUS, location: center }); } catch { }

            block.setPermutation(permutation.withState(PRESSURE_TAG, entities.length > 0 ? "on" : "off"));
        },
        onBlockStateChange(e, p) {
            const previous = e.previousPermutation.getState(PRESSURE_TAG);
            const current = e.block.permutation.getState(PRESSURE_TAG);
            if (previous === current) return;

            const { on_sound, off_sound } = p.params;

            const sound = (previous === "off" && current === "on") ? on_sound
                : (current === "off") ? off_sound
                    : null;
            if (sound) e.block.dimension.playSound(sound, e.block.center());
        }
    });
});
