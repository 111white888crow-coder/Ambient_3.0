// scripts/quiver/quiver_const.js
// ── Все константы и конфигурация системы колчана ──

export const QUIVER_ITEM_TAG = "sag:quiver";
export const STORE_ENTITY_ID = "sag:quiver_store";

export const QUIVER_SLOTS = 5;
export const PER_SLOT_CAP = 64;
export const BUFFER_COUNT = 2;

export const DIM_IDS = ["overworld", "nether", "the_end"];

// Hidden lore keys
export const HIDDEN = "§0";
export const LORE_ID_PREFIX = "qid:";
export const LORE_SEL_PREFIX = "sel:";
export const BUF_PREFIX = "buf:";
export const BUF_SRC_PREFIX = "bsl:";

export const LOAD_COOLDOWN_TICKS = 10;
export const SWITCH_COOLDOWN_TICKS = 5;

export const PREFERRED_BUFFER_SLOTS = [0, 1, 2, 3, 4, 5, 6, 7, 8];
export const OFFHAND_SLOT = -1;

// Store anchoring
export const STORE_ANCHOR_DIM_ID = "overworld";
export const STORE_ANCHOR_X = 0.5;
export const STORE_ANCHOR_Z = 0.5;
export const STORE_ANCHOR_Y = 1000;
export const STORE_TICKING_ID = "sag_quiver_anchor";
