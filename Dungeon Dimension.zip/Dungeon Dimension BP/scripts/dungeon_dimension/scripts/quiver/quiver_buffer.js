// scripts/quiver/quiver_buffer.js
// ── Buffer arrow management ──

import { system } from "@minecraft/server";
import {
    QUIVER_SLOTS, PER_SLOT_CAP, BUFFER_COUNT, PREFERRED_BUFFER_SLOTS
} from "./quiver_const.js";
import {
    isArrow, canStack, spawnItemNearPlayer,
    getBufferQid, getBufferSrcSlot, markAsBuffer, clearBufferMarks
} from "./quiver_utils.js";

// ═══════════════════════════════════════════════
//  Legitimate Buffer Tracking
// ═══════════════════════════════════════════════

/** player.id → Set<slotIndex> */
export const legitimateBufferSlots = new Map();

// ═══════════════════════════════════════════════
//  Buffer Slot Operations
// ═══════════════════════════════════════════════

export function findBufferSlot(inv, quiverSlot, qid) {
    for (let i = 0; i < inv.size; i++) {
        if (i === quiverSlot) continue;
        const it = inv.getItem(i);
        if (it && isArrow(it) && getBufferQid(it) === qid) return i;
    }
    return -1;
}

export function chooseBufferSlot(inv, quiverSlot, qid) {
    const existing = findBufferSlot(inv, quiverSlot, qid);
    if (existing >= 0) return existing;
    for (const s of PREFERRED_BUFFER_SLOTS) {
        if (s !== quiverSlot && !inv.getItem(s)) return s;
    }
    for (let i = 0; i < inv.size; i++) {
        if (i !== quiverSlot && !inv.getItem(i)) return i;
    }
    return -1;
}

// ═══════════════════════════════════════════════
//  Store ← Item Operations
// ═══════════════════════════════════════════════

export function addToStore(storeInv, item) {
    if (!item) return 0;
    clearBufferMarks(item);
    let remaining = item.amount;

    for (let i = 0; i < QUIVER_SLOTS && remaining > 0; i++) {
        const st = storeInv.getItem(i);
        if (!st || !canStack(st, item)) continue;
        const space = PER_SLOT_CAP - st.amount;
        if (space <= 0) continue;
        const add = Math.min(space, remaining);
        st.amount += add;
        storeInv.setItem(i, st);
        remaining -= add;
    }

    for (let i = 0; i < QUIVER_SLOTS && remaining > 0; i++) {
        if (storeInv.getItem(i)) continue;
        const stack = item.clone();
        stack.amount = Math.min(PER_SLOT_CAP, remaining);
        storeInv.setItem(i, stack);
        remaining -= stack.amount;
    }

    return item.amount - remaining;
}

// ═══════════════════════════════════════════════
//  Buffer CRUD
// ═══════════════════════════════════════════════

export function createBuffer(player, inv, quiverSlot, storeInv, selected, qid) {
    const src = storeInv.getItem(selected);
    if (!src) return false;

    const bufferSlot = chooseBufferSlot(inv, quiverSlot, qid);
    if (bufferSlot < 0) return false;

    const take = Math.min(BUFFER_COUNT, src.amount);
    if (take <= 0) return false;

    const buffer = src.clone();
    buffer.amount = take;
    markAsBuffer(buffer, qid, selected);

    if (player) {
        let slots = legitimateBufferSlots.get(player.id);
        if (!slots) {
            slots = new Set();
            legitimateBufferSlots.set(player.id, slots);
        }
        slots.add(bufferSlot);
        system.runTimeout(() => {
            const s = legitimateBufferSlots.get(player.id);
            if (s) s.delete(bufferSlot);
        }, 2);
    }

    inv.setItem(bufferSlot, buffer);
    if (src.amount === take) storeInv.setItem(selected, undefined);
    else { src.amount -= take; storeInv.setItem(selected, src); }

    return true;
}

export function returnBufferToStore(inv, quiverSlot, storeInv, qid) {
    const bufferSlot = findBufferSlot(inv, quiverSlot, qid);
    if (bufferSlot < 0) return null;

    const bufferItem = inv.getItem(bufferSlot);
    if (!bufferItem) return null;

    const srcSlot = getBufferSrcSlot(bufferItem);
    inv.setItem(bufferSlot, undefined);
    clearBufferMarks(bufferItem);

    let remaining = bufferItem.amount;

    if (srcSlot >= 0 && srcSlot < QUIVER_SLOTS && remaining > 0) {
        const st = storeInv.getItem(srcSlot);
        if (!st) {
            const stack = bufferItem.clone();
            stack.amount = remaining;
            storeInv.setItem(srcSlot, stack);
            remaining = 0;
        } else if (canStack(st, bufferItem)) {
            const add = Math.min(PER_SLOT_CAP - st.amount, remaining);
            if (add > 0) { st.amount += add; storeInv.setItem(srcSlot, st); remaining -= add; }
        }
    }

    for (let i = 0; i < QUIVER_SLOTS && remaining > 0; i++) {
        const st = storeInv.getItem(i);
        if (!st || !canStack(st, bufferItem)) continue;
        const add = Math.min(PER_SLOT_CAP - st.amount, remaining);
        if (add > 0) { st.amount += add; storeInv.setItem(i, st); remaining -= add; }
    }

    for (let i = 0; i < QUIVER_SLOTS && remaining > 0; i++) {
        if (storeInv.getItem(i)) continue;
        const stack = bufferItem.clone();
        stack.amount = remaining;
        storeInv.setItem(i, stack);
        remaining = 0;
    }

    if (remaining > 0) {
        const leftover = bufferItem.clone();
        leftover.amount = remaining;
        return leftover;
    }
    return null;
}

export function refillBuffer(player, inv, quiverSlot, storeInv, selected, qid) {
    let bufferSlot = findBufferSlot(inv, quiverSlot, qid);
    if (bufferSlot < 0) { createBuffer(player, inv, quiverSlot, storeInv, selected, qid); return; }

    const bufferItem = inv.getItem(bufferSlot);
    if (!bufferItem) { createBuffer(player, inv, quiverSlot, storeInv, selected, qid); return; }

    const src = storeInv.getItem(selected);
    if (!src) return;

    const tmp = bufferItem.clone();
    clearBufferMarks(tmp);

    if (!canStack(tmp, src)) {
        const leftover = returnBufferToStore(inv, quiverSlot, storeInv, qid);
        if (leftover) spawnItemNearPlayer(player, leftover);
        createBuffer(player, inv, quiverSlot, storeInv, selected, qid);
        return;
    }

    const need = BUFFER_COUNT - bufferItem.amount;
    if (need <= 0) return;

    const take = Math.min(need, src.amount);
    if (take <= 0) return;

    bufferItem.amount += take;
    inv.setItem(bufferSlot, bufferItem);

    if (src.amount === take) storeInv.setItem(selected, undefined);
    else { src.amount -= take; storeInv.setItem(selected, src); }
}

export function clearAllBuffersForQid(inv, quiverSlot, qid) {
    for (let i = 0; i < inv.size; i++) {
        if (i === quiverSlot) continue;
        const it = inv.getItem(i);
        if (it && isArrow(it) && getBufferQid(it) === qid) {
            clearBufferMarks(it);
            inv.setItem(i, it);
        }
    }
}
