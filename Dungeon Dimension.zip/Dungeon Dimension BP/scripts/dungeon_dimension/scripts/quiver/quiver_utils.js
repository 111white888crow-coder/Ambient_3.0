// scripts/quiver/quiver_utils.js
// ── Helpers: inventory, items, lore, display, quiver lookup, buffer sync ──

import { EntityComponentTypes, EquipmentSlot, ItemStack } from "@minecraft/server";
import {
    QUIVER_ITEM_TAG, QUIVER_SLOTS, HIDDEN, OFFHAND_SLOT,
    LORE_ID_PREFIX, LORE_SEL_PREFIX, BUF_PREFIX, BUF_SRC_PREFIX
} from "./quiver_const.js";

// ═══════════════════════════════════════════════
//  Inventory Helpers
// ═══════════════════════════════════════════════

export const getInv = (player) => player.getComponent(EntityComponentTypes.Inventory)?.container;
export const getEquipment = (player) => player.getComponent(EntityComponentTypes.Equippable);

export function getOffhandItem(player) {
    try { return getEquipment(player)?.getEquipment(EquipmentSlot.Offhand) ?? null; }
    catch { return null; }
}

export function setOffhandItem(player, item) {
    try {
        const equip = getEquipment(player);
        if (!equip) return false;
        equip.setEquipment(EquipmentSlot.Offhand, item);
        return true;
    } catch { return false; }
}

// ═══════════════════════════════════════════════
//  Item Type Checks
// ═══════════════════════════════════════════════

export function isArrow(item) {
    if (!item) return false;
    try { if (item.hasTag?.("minecraft:arrow") || item.hasTag?.("sag:quiver_use")) return true; } catch { }
    const id = item.typeId;
    return id === "minecraft:arrow" || id === "minecraft:spectral_arrow" || id === "minecraft:tipped_arrow" || id.includes("arrow");
}

export function isArrowEntity(entity) {
    if (!entity) return false;
    try { if (entity.hasTag?.("sag:quiver_use")) return true; } catch { }
    const id = entity.typeId;
    return id === "minecraft:arrow" || id === "minecraft:spectral_arrow" || id.includes("arrow");
}

export function isQuiver(item) {
    if (!item) return false;
    try { return item.hasTag?.(QUIVER_ITEM_TAG) ?? false; }
    catch { return item.typeId?.includes("quiver") ?? false; }
}

export function getLoadedQuiverId(typeId) {
    if (!typeId || typeId.endsWith("_arrows")) return typeId;
    return typeId + "_arrows";
}

export function getEmptyQuiverId(typeId) {
    if (!typeId) return typeId;
    return typeId.endsWith("_arrows") ? typeId.slice(0, -7) : typeId;
}

export function convertQuiverItem(oldItem, newTypeId) {
    if (!oldItem || !newTypeId) return null;
    try {
        const newItem = new ItemStack(newTypeId, 1);
        const lore = oldItem.getLore?.() ?? [];
        if (lore.length > 0) newItem.setLore(lore);
        try { if (oldItem.nameTag) newItem.nameTag = oldItem.nameTag; } catch { }
        return newItem;
    } catch { return oldItem; }
}

export function canStack(a, b) {
    if (!a || !b) return false;
    try { return a.isStackableWith(b); }
    catch { return a.typeId === b.typeId; }
}

export function spawnItemNearPlayer(player, item) {
    if (!item) return;
    try {
        const loc = player.location;
        player.dimension.spawnItem(item, {
            x: loc.x + (Math.random() - 0.5) * 0.6,
            y: loc.y + 0.5,
            z: loc.z + (Math.random() - 0.5) * 0.6,
        });
    } catch { }
}

// ═══════════════════════════════════════════════
//  Lore Helpers
// ═══════════════════════════════════════════════

export function getHiddenValue(item, keyPrefix) {
    if (!item) return null;
    const lore = item.getLore?.() ?? [];
    const fullPrefix = HIDDEN + keyPrefix;
    for (let i = 0; i < lore.length; i++) {
        if (lore[i].startsWith(fullPrefix)) return lore[i].slice(fullPrefix.length);
    }
    return null;
}

export function setHiddenValue(item, keyPrefix, value) {
    if (!item) return;
    const lore = item.getLore?.() ?? [];
    const fullPrefix = HIDDEN + keyPrefix;
    const line = fullPrefix + String(value);
    const idx = lore.findIndex(l => l.startsWith(fullPrefix));
    if (idx >= 0) lore[idx] = line;
    else lore.push(line);
    item.setLore(lore);
}

export function removeHiddenKey(item, keyPrefix) {
    if (!item) return;
    const lore = item.getLore?.() ?? [];
    const fullPrefix = HIDDEN + keyPrefix;
    const filtered = lore.filter(l => !l.startsWith(fullPrefix));
    if (filtered.length !== lore.length) item.setLore(filtered);
}

export function ensureLore(item) {
    if (!item) return [];
    const lore = item.getLore?.() ?? [];
    let changed = false;
    if (!lore.some(l => l.startsWith(HIDDEN + LORE_ID_PREFIX))) {
        lore.unshift(HIDDEN + LORE_ID_PREFIX + Math.random().toString(36).slice(2));
        changed = true;
    }
    if (!lore.some(l => l.startsWith(HIDDEN + LORE_SEL_PREFIX))) {
        lore.splice(1, 0, HIDDEN + LORE_SEL_PREFIX + "0");
        changed = true;
    }
    if (changed) item.setLore(lore);
    return lore;
}

export const getQidFromItem = (item) => getHiddenValue(item, LORE_ID_PREFIX);

export function parseSelected(item) {
    const v = parseInt(getHiddenValue(item, LORE_SEL_PREFIX) ?? "0");
    return Number.isFinite(v) ? Math.max(0, Math.min(QUIVER_SLOTS - 1, v)) : 0;
}

export const setSelected = (item, idx) =>
    setHiddenValue(item, LORE_SEL_PREFIX, Math.max(0, Math.min(QUIVER_SLOTS - 1, idx)));

export function markAsBuffer(item, qid, srcSlot) {
    setHiddenValue(item, BUF_PREFIX, qid);
    setHiddenValue(item, BUF_SRC_PREFIX, srcSlot);
}

export const getBufferQid = (item) => getHiddenValue(item, BUF_PREFIX);

export function getBufferSrcSlot(item) {
    const v = parseInt(getHiddenValue(item, BUF_SRC_PREFIX) ?? "-1");
    return Number.isFinite(v) ? v : -1;
}

export function clearBufferMarks(item) {
    removeHiddenKey(item, BUF_PREFIX);
    removeHiddenKey(item, BUF_SRC_PREFIX);
}

export function getArrowEffectLabel(item) {
    try {
        const id = item.getComponent?.("minecraft:potion")?.potionEffectType?.id;
        return id ? ` §b(${id.replace("minecraft:", "")})` : "";
    } catch { return ""; }
}

// ═══════════════════════════════════════════════
//  Lore Display
// ═══════════════════════════════════════════════

export function updateQuiverLore(quiverItem, storeInv, selected) {
    const lore = [];
    const oldLore = quiverItem.getLore?.() ?? [];
    const qidLine = oldLore.find(l => l.startsWith(HIDDEN + LORE_ID_PREFIX));
    if (qidLine) lore.push(qidLine);
    lore.push(HIDDEN + LORE_SEL_PREFIX + selected);

    let hasAny = false;
    for (let i = 0; i < QUIVER_SLOTS; i++) {
        const st = storeInv.getItem(i);
        if (!st || st.amount <= 0) continue;
        hasAny = true;
        const name = st.typeId?.replace("minecraft:", "").replace(/_/g, " ") ?? "";
        const eff = getArrowEffectLabel(st);
        const prefix = (i === selected) ? "§a> " : "§7- ";
        lore.push(`${prefix}${name} x${st.amount}${eff}`);
    }
    if (!hasAny) lore.push("§7Empty");
    quiverItem.setLore(lore);
}

// ═══════════════════════════════════════════════
//  Quiver Lookup
// ═══════════════════════════════════════════════

export function findQuiverByQid(inv, qid, player) {
    for (let i = 0; i < inv.size; i++) {
        const it = inv.getItem(i);
        if (isQuiver(it) && getQidFromItem(it) === qid) return { slot: i, item: it, isOffhand: false };
    }
    if (player) {
        const offhandItem = getOffhandItem(player);
        if (isQuiver(offhandItem) && getQidFromItem(offhandItem) === qid) {
            return { slot: OFFHAND_SLOT, item: offhandItem, isOffhand: true };
        }
    }
    return null;
}

export function findActiveQuiver(player) {
    const inv = getInv(player);
    if (!inv) return null;

    const selectedSlot = player.selectedSlotIndex;
    const selectedItem = inv.getItem(selectedSlot);
    if (isQuiver(selectedItem)) {
        const qid = getQidFromItem(selectedItem);
        if (qid) return { slot: selectedSlot, item: selectedItem, isOffhand: false, qid };
    }

    const offhandItem = getOffhandItem(player);
    if (isQuiver(offhandItem)) {
        const qid = getQidFromItem(offhandItem);
        if (qid) return { slot: OFFHAND_SLOT, item: offhandItem, isOffhand: true, qid };
    }

    for (let i = 0; i < inv.size; i++) {
        if (i === selectedSlot) continue;
        const it = inv.getItem(i);
        if (isQuiver(it)) {
            const qid = getQidFromItem(it);
            if (qid) return { slot: i, item: it, isOffhand: false, qid };
        }
    }
    return null;
}

// ═══════════════════════════════════════════════
//  Buffer Sync (очистка orphaned буферов)
// ═══════════════════════════════════════════════

export function syncBufferState(player) {
    const inv = getInv(player);
    if (!inv) return;

    const activeQids = new Set();
    for (let i = 0; i < inv.size; i++) {
        const it = inv.getItem(i);
        if (isQuiver(it)) {
            const qid = getQidFromItem(it);
            if (qid) activeQids.add(qid);
        }
    }

    const offhandItem = getOffhandItem(player);
    if (isQuiver(offhandItem)) {
        const qid = getQidFromItem(offhandItem);
        if (qid) activeQids.add(qid);
    }

    const seenBufferQids = new Set();
    for (let i = 0; i < inv.size; i++) {
        const it = inv.getItem(i);
        if (!it || !isArrow(it)) continue;
        const qid = getBufferQid(it);
        if (!qid) continue;

        if (!activeQids.has(qid) || seenBufferQids.has(qid)) {
            clearBufferMarks(it);
            inv.setItem(i, it);
        } else {
            seenBufferQids.add(qid);
        }
    }
}
