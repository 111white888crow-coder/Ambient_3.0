// scripts/quiver/quiver.js
// ── Orchestration: interactions, events, shooting, cleanup ──
// Оптимизации vs оригинал:
//   • Store entity кэшируется (quiver_store.js) — нет сканинга 3 измерений
//   • Cleanup интервал: 10 тиков → 100 тиков, без сканинга item entities (entitySpawn покрывает)
//   • syncBufferState: 20 тиков → 40 тиков
//   • Модульная структура: 5 файлов вместо 1 монолита

import { world, system, EntityComponentTypes } from "@minecraft/server";

import {
    QUIVER_SLOTS, OFFHAND_SLOT, BUFFER_COUNT,
    LOAD_COOLDOWN_TICKS, SWITCH_COOLDOWN_TICKS, PER_SLOT_CAP,
    BUF_PREFIX, LORE_ID_PREFIX, DIM_IDS
} from "./quiver_const.js";

import {
    getInv, getOffhandItem, setOffhandItem,
    isArrow, isArrowEntity, isQuiver,
    getQidFromItem, ensureLore, parseSelected, setSelected,
    getBufferQid, clearBufferMarks, markAsBuffer, setHiddenValue,
    getLoadedQuiverId, getEmptyQuiverId, convertQuiverItem, canStack, spawnItemNearPlayer,
    updateQuiverLore,
    findQuiverByQid, findActiveQuiver, syncBufferState
} from "./quiver_utils.js";

import {
    findStore, getStoreInv, getOrCreateStore, isStoreEmpty, clearStoreCache
} from "./quiver_store.js";

import {
    findBufferSlot, addToStore, createBuffer, returnBufferToStore,
    refillBuffer, clearAllBuffersForQid, legitimateBufferSlots
} from "./quiver_buffer.js";

// ════════════════════════════════════════════════
//  Shared State
// ════════════════════════════════════════════════

const interactCooldowns = new Map();
const playerActiveQuiver = new Map();
const pendingShotUntil = new Map();

// ════════════════════════════════════════════════
//  Duplicate QID Protection
// ════════════════════════════════════════════════

function checkAndFixDuplicateQid(player, quiverItem, qid, quiverSlot, isOffhand) {
    const inv = getInv(player);
    if (!inv) return qid;

    let duplicateFound = false;

    for (let i = 0; i < inv.size; i++) {
        if (!isOffhand && i === quiverSlot) continue;
        const it = inv.getItem(i);
        if (isQuiver(it) && getQidFromItem(it) === qid) { duplicateFound = true; break; }
    }

    if (!duplicateFound && !isOffhand) {
        const offhand = getOffhandItem(player);
        if (isQuiver(offhand) && getQidFromItem(offhand) === qid) duplicateFound = true;
    }

    if (!duplicateFound) {
        for (const p of world.getAllPlayers()) {
            if (p.id === player.id) continue;
            const pInv = getInv(p);
            if (pInv) {
                for (let i = 0; i < pInv.size; i++) {
                    const it = pInv.getItem(i);
                    if (isQuiver(it) && getQidFromItem(it) === qid) { duplicateFound = true; break; }
                }
            }
            if (!duplicateFound) {
                const pOff = getOffhandItem(p);
                if (isQuiver(pOff) && getQidFromItem(pOff) === qid) duplicateFound = true;
            }
            if (duplicateFound) break;
        }
    }

    if (!duplicateFound) return qid;

    const oldQid = qid;
    const newQid = Math.random().toString(36).slice(2);
    setHiddenValue(quiverItem, LORE_ID_PREFIX, newQid);

    const store = findStore(oldQid);
    if (store) {
        try { store.removeTag(oldQid); } catch { }
        try { store.addTag(newQid); } catch { }
        clearStoreCache(oldQid);
    }

    for (let i = 0; i < inv.size; i++) {
        if (!isOffhand && i === quiverSlot) continue;
        const it = inv.getItem(i);
        if (it && isArrow(it) && getBufferQid(it) === oldQid) {
            setHiddenValue(it, BUF_PREFIX, newQid);
            inv.setItem(i, it);
        }
    }

    if (playerActiveQuiver.get(player.id) === oldQid) playerActiveQuiver.set(player.id, newQid);
    return newQid;
}

// ════════════════════════════════════════════════
//  Quiver Interaction (LOAD / UNLOAD / SWITCH)
// ════════════════════════════════════════════════

function handleQuiverInteraction(player, quiverSlot, isOffhand) {
    const inv = getInv(player);
    if (!inv) return;

    let quiverItem = isOffhand ? getOffhandItem(player) : inv.getItem(quiverSlot);
    if (!isQuiver(quiverItem)) return;

    const now = system.currentTick;
    const cooldownKey = player.id + (isOffhand ? "_off" : "");
    const last = interactCooldowns.get(cooldownKey) ?? 0;
    const cooldown = player.isSneaking ? SWITCH_COOLDOWN_TICKS : LOAD_COOLDOWN_TICKS;
    if (now - last < cooldown) return;
    interactCooldowns.set(cooldownKey, now);

    ensureLore(quiverItem);
    let qid = getQidFromItem(quiverItem);
    if (!qid) return;

    qid = checkAndFixDuplicateQid(player, quiverItem, qid, quiverSlot, isOffhand);

    // Normalize foreign buffers
    const validQids = new Set([qid]);
    for (let i = 0; i < inv.size; i++) {
        const it = inv.getItem(i);
        if (isQuiver(it)) { const q = getQidFromItem(it); if (q) validQids.add(q); }
    }
    const offhand = getOffhandItem(player);
    if (isQuiver(offhand)) { const q = getQidFromItem(offhand); if (q) validQids.add(q); }

    for (let i = 0; i < inv.size; i++) {
        if (!isOffhand && i === quiverSlot) continue;
        const it = inv.getItem(i);
        if (it && isArrow(it)) {
            const bufQid = getBufferQid(it);
            if (bufQid && !validQids.has(bufQid)) {
                clearBufferMarks(it);
                inv.setItem(i, it);
            }
        }
    }

    let selected = parseSelected(quiverItem);
    const store = getOrCreateStore(player, qid);
    const storeInv = getStoreInv(store);
    if (!storeInv) return;

    playerActiveQuiver.set(player.id, qid);
    const empty = isStoreEmpty(storeInv);

    const saveQuiver = (item) => {
        if (isOffhand) setOffhandItem(player, item);
        else inv.setItem(quiverSlot, item);
    };

    if (!player.isSneaking) {
        if (empty) {
            // ── LOAD ──
            const arrowSlots = [];
            for (let i = 0; i < inv.size; i++) {
                if (!isOffhand && i === quiverSlot) continue;
                const it = inv.getItem(i);
                if (!it || !isArrow(it)) continue;
                const bufQid = getBufferQid(it);
                if (bufQid && bufQid !== qid) continue;
                if (bufQid === qid) { clearBufferMarks(it); inv.setItem(i, it); }
                arrowSlots.push({ slot: i, item: it.clone() });
            }
            if (arrowSlots.length === 0) return;

            const typeGroups = [];
            for (const e of arrowSlots) {
                let found = typeGroups.find(g => canStack(g.representative, e.item));
                if (found) {
                    found.totalCount += e.item.amount;
                    found.slots.push({ slot: e.slot, item: e.item, amount: e.item.amount });
                } else {
                    typeGroups.push({
                        representative: e.item.clone(),
                        totalCount: e.item.amount,
                        slots: [{ slot: e.slot, item: e.item, amount: e.item.amount }]
                    });
                }
            }

            const validGroups = typeGroups.filter(g => g.totalCount > BUFFER_COUNT);
            if (validGroups.length === 0) return;

            let bufferGroup = validGroups[0];
            for (const g of validGroups) {
                if (g.slots[0].slot < bufferGroup.slots[0].slot) bufferGroup = g;
            }

            for (const group of validGroups) {
                group.slots.sort((a, b) => a.slot - b.slot);
                for (const slotData of group.slots) {
                    const currentItem = inv.getItem(slotData.slot);
                    if (!currentItem) continue;
                    const originalAmount = currentItem.amount;
                    const added = addToStore(storeInv, currentItem);
                    if (added === 0) continue;
                    if (added < originalAmount) {
                        currentItem.amount = originalAmount - added;
                        inv.setItem(slotData.slot, currentItem);
                    } else {
                        inv.setItem(slotData.slot, undefined);
                    }
                }
            }

            let bufferStoreSlot = 0;
            const tmpBuf = bufferGroup.representative.clone();
            clearBufferMarks(tmpBuf);
            for (let i = 0; i < QUIVER_SLOTS; i++) {
                const st = storeInv.getItem(i);
                if (st && canStack(st, tmpBuf)) { bufferStoreSlot = i; break; }
            }

            createBuffer(player, inv, quiverSlot, storeInv, bufferStoreSlot, qid);

            selected = bufferStoreSlot;
            if (!storeInv.getItem(selected)) {
                for (let i = 0; i < QUIVER_SLOTS; i++) {
                    if (storeInv.getItem(i)) { selected = i; break; }
                }
            }
            setSelected(quiverItem, selected);
            updateQuiverLore(quiverItem, storeInv, selected);

            const loadedTypeId = getLoadedQuiverId(quiverItem.typeId);
            if (loadedTypeId !== quiverItem.typeId) {
                const loadedQuiver = convertQuiverItem(quiverItem, loadedTypeId);
                saveQuiver(loadedQuiver || quiverItem);
            } else {
                saveQuiver(quiverItem);
            }

            try { player.playSound("random.pop"); } catch { }
            return;
        }

        // ── UNLOAD ──
        const leftoverBuf = returnBufferToStore(inv, quiverSlot, storeInv, qid);
        if (leftoverBuf) {
            const leftover = inv.addItem(leftoverBuf);
            if (leftover) spawnItemNearPlayer(player, leftover);
        }

        clearAllBuffersForQid(inv, quiverSlot, qid);

        for (let i = 0; i < QUIVER_SLOTS; i++) {
            const st = storeInv.getItem(i);
            if (!st) continue;
            storeInv.setItem(i, undefined);
            const leftover = inv.addItem(st);
            if (leftover) spawnItemNearPlayer(player, leftover);
        }

        selected = 0;
        setSelected(quiverItem, selected);
        updateQuiverLore(quiverItem, storeInv, selected);

        const emptyTypeId = getEmptyQuiverId(quiverItem.typeId);
        if (emptyTypeId !== quiverItem.typeId) {
            const emptyQuiver = convertQuiverItem(quiverItem, emptyTypeId);
            saveQuiver(emptyQuiver || quiverItem);
        } else {
            saveQuiver(quiverItem);
        }

        try { player.playSound("random.pop"); } catch { }
        return;
    }

    // ── SWITCH ──
    const leftover = returnBufferToStore(inv, quiverSlot, storeInv, qid);
    if (leftover) spawnItemNearPlayer(player, leftover);

    let next = selected;
    for (let k = 1; k <= QUIVER_SLOTS; k++) {
        const idx = (selected + k) % QUIVER_SLOTS;
        if (storeInv.getItem(idx)) { next = idx; break; }
    }

    selected = next;
    setSelected(quiverItem, selected);
    createBuffer(player, inv, quiverSlot, storeInv, selected, qid);
    updateQuiverLore(quiverItem, storeInv, selected);
    saveQuiver(quiverItem);

    try { player.playSound("random.click"); } catch { }
}

// ════════════════════════════════════════════════
//  Event Subscriptions — Interaction
// ════════════════════════════════════════════════

world.afterEvents.itemUse.subscribe((ev) => {
    const player = ev.source;
    if (!player || player.typeId !== "minecraft:player") return;
    const inv = getInv(player);
    if (!inv) return;
    const quiverSlot = player.selectedSlotIndex;
    if (!isQuiver(inv.getItem(quiverSlot))) return;
    handleQuiverInteraction(player, quiverSlot, false);
});

try {
    world.afterEvents.entityHitEntity.subscribe((ev) => {
        const player = ev.damagingEntity;
        if (!player || player.typeId !== "minecraft:player") return;
        if (!isQuiver(getOffhandItem(player))) return;
        handleQuiverInteraction(player, OFFHAND_SLOT, true);
    });
} catch { }

try {
    world.afterEvents.entityHitBlock.subscribe((ev) => {
        const player = ev.damagingEntity;
        if (!player || player.typeId !== "minecraft:player") return;
        if (!isQuiver(getOffhandItem(player))) return;
        handleQuiverInteraction(player, OFFHAND_SLOT, true);
    });
} catch { }

// ════════════════════════════════════════════════
//  Shooting Detection
// ════════════════════════════════════════════════

function tryActivateQuiverForShooting(player) {
    const inv = getInv(player);
    if (!inv) return null;

    const quiverData = findActiveQuiver(player);
    if (!quiverData) return null;

    const { slot, item, isOffhand, qid } = quiverData;

    if (findBufferSlot(inv, slot, qid) >= 0) {
        playerActiveQuiver.set(player.id, qid);
        return qid;
    }

    const store = getOrCreateStore(player, qid);
    const storeInv = getStoreInv(store);
    if (!storeInv || isStoreEmpty(storeInv)) return null;

    const selected = parseSelected(item);
    const ok = createBuffer(player, inv, slot, storeInv, selected, qid);
    if (!ok) return null;

    updateQuiverLore(item, storeInv, selected);
    if (isOffhand) setOffhandItem(player, item);
    else inv.setItem(slot, item);

    playerActiveQuiver.set(player.id, qid);
    return qid;
}

function handleArrowConsumedFromBuffer(player, qid) {
    const inv = getInv(player);
    if (!inv) return;

    const quiverData = findQuiverByQid(inv, qid, player);
    if (!quiverData) return;

    const store = getOrCreateStore(player, qid);
    if (!store) return;
    const storeInv = getStoreInv(store);
    if (!storeInv) return;

    const { slot: quiverSlot, isOffhand } = quiverData;
    let quiverItem = isOffhand ? getOffhandItem(player) : inv.getItem(quiverSlot);
    if (!isQuiver(quiverItem)) return;

    const selected = parseSelected(quiverItem);
    refillBuffer(player, inv, quiverSlot, storeInv, selected, qid);

    if (isStoreEmpty(storeInv)) {
        const emptyTypeId = getEmptyQuiverId(quiverItem.typeId);
        if (emptyTypeId !== quiverItem.typeId) {
            const emptyQuiver = convertQuiverItem(quiverItem, emptyTypeId);
            if (emptyQuiver) quiverItem = emptyQuiver;
        }
    }

    updateQuiverLore(quiverItem, storeInv, selected);
    if (isOffhand) setOffhandItem(player, quiverItem);
    else inv.setItem(quiverSlot, quiverItem);
}

try {
    world.afterEvents.itemReleaseUse.subscribe((ev) => {
        const player = ev.source;
        if (!player || player.typeId !== "minecraft:player") return;
        const id = ev.itemStack?.typeId;
        if (id !== "minecraft:bow" && id !== "minecraft:crossbow" && id !== "sag:hanter_bow") return;
        const qid = tryActivateQuiverForShooting(player);
        if (qid) pendingShotUntil.set(player.id, { until: system.currentTick + 12, qid });
        else pendingShotUntil.delete(player.id);
    });
} catch { }

// ════════════════════════════════════════════════
//  Inventory Change Detection
// ════════════════════════════════════════════════

let HAS_INV_CHANGE_EVENT = false;
try {
    if (world.afterEvents.playerInventoryItemChange?.subscribe) {
        HAS_INV_CHANGE_EVENT = true;
        world.afterEvents.playerInventoryItemChange.subscribe((ev) => {
            const player = ev.player;
            if (!player || player.typeId !== "minecraft:player") return;

            const before = ev.beforeItemStack;
            const after = ev.itemStack;
            const slot = ev.slot;

            // Handle externally obtained arrows with buffer lore
            const afterQid = isArrow(after) ? getBufferQid(after) : null;
            const beforeQid = isArrow(before) ? getBufferQid(before) : null;

            if (afterQid) {
                if (beforeQid !== afterQid) {
                    const legitSlots = legitimateBufferSlots.get(player.id);
                    if (!legitSlots || !legitSlots.has(slot)) {
                        clearBufferMarks(after);
                        try {
                            const inv = getInv(player);
                            if (inv) inv.setItem(slot, after);
                        } catch { }
                    }
                }
            }

            // Auto-convert picked arrows to buffer if matching store
            if (isArrow(after) && !getBufferQid(after)) {
                const beforeAmt = before?.amount ?? 0;
                const afterAmt = after?.amount ?? 0;

                if (afterAmt > beforeAmt) {
                    try {
                        const inv = getInv(player);
                        if (!inv) return;

                        // Используем findActiveQuiver вместо ручного поиска
                        const quiverData = findActiveQuiver(player);
                        if (!quiverData) return;

                        const { slot: quiverSlot, item: quiverItem, qid } = quiverData;

                        if (findBufferSlot(inv, quiverSlot, qid) >= 0) return;

                        const store = getOrCreateStore(player, qid);
                        if (!store) return;
                        const storeInv = getStoreInv(store);
                        if (!storeInv || isStoreEmpty(storeInv)) return;

                        const cleanAfter = after.clone();
                        clearBufferMarks(cleanAfter);

                        let matchingSlot = -1;
                        const selected = parseSelected(quiverItem);

                        const selectedArrow = storeInv.getItem(selected);
                        if (selectedArrow && canStack(cleanAfter, selectedArrow)) {
                            matchingSlot = selected;
                        } else {
                            for (let i = 0; i < QUIVER_SLOTS; i++) {
                                const storeArrow = storeInv.getItem(i);
                                if (storeArrow && canStack(cleanAfter, storeArrow)) {
                                    matchingSlot = i;
                                    break;
                                }
                            }
                        }

                        if (matchingSlot < 0) return;

                        const bufferAmount = Math.min(after.amount, BUFFER_COUNT);
                        const remainder = after.amount - bufferAmount;

                        const bufferArrow = after.clone();
                        bufferArrow.amount = bufferAmount;
                        markAsBuffer(bufferArrow, qid, matchingSlot);

                        if (remainder > 0) {
                            inv.setItem(slot, bufferArrow);
                            const remainderArrow = after.clone();
                            remainderArrow.amount = remainder;

                            let placed = false;
                            for (let i = 0; i < inv.size; i++) {
                                if (i === slot || i === quiverSlot) continue;
                                const existing = inv.getItem(i);
                                if (!existing) {
                                    inv.setItem(i, remainderArrow);
                                    placed = true;
                                    break;
                                } else if (canStack(existing, remainderArrow) && existing.amount < existing.maxAmount) {
                                    const add = Math.min(remainder, existing.maxAmount - existing.amount);
                                    existing.amount += add;
                                    inv.setItem(i, existing);
                                    if (add >= remainder) { placed = true; break; }
                                    remainderArrow.amount = remainder - add;
                                }
                            }
                            if (!placed && remainderArrow.amount > 0) spawnItemNearPlayer(player, remainderArrow);
                        } else {
                            inv.setItem(slot, bufferArrow);
                        }
                    } catch { }
                }
            }

            // Shooting detection via inventory change
            const ps = pendingShotUntil.get(player.id);
            if (!ps || system.currentTick > ps.until) return;
            if (!isArrow(before) && !isArrow(after)) return;

            const beforeAmt2 = before?.amount ?? 0;
            const afterAmt2 = after?.amount ?? 0;
            if (beforeAmt2 <= afterAmt2) return;

            const detectedQid = getBufferQid(before) || getBufferQid(after);
            pendingShotUntil.delete(player.id);
            if (!detectedQid) return;
            system.runTimeout(() => {
                try { handleArrowConsumedFromBuffer(player, detectedQid); } catch { }
            }, 1);
        });
    }
} catch { HAS_INV_CHANGE_EVENT = false; }

// ════════════════════════════════════════════════
//  Entity Spawn — arrow projectiles + dropped items
// ════════════════════════════════════════════════

world.afterEvents.entitySpawn.subscribe((ev) => {
    const entity = ev.entity;

    // Очистка buffer marks с дропнутых предметов
    if (entity?.typeId === "minecraft:item") {
        try {
            const comp = entity.getComponent("minecraft:item");
            const stack = comp?.itemStack;
            if (stack && isArrow(stack) && getBufferQid(stack)) {
                clearBufferMarks(stack);
                try { comp.itemStack = stack; } catch { }
            }
        } catch { }
        return;
    }

    // Fallback shooting detection (если нет playerInventoryItemChange)
    if (HAS_INV_CHANGE_EVENT) return;
    if (!entity || !isArrowEntity(entity)) return;

    let owner;
    try { owner = entity.getComponent("minecraft:projectile")?.owner; } catch { return; }
    if (!owner || owner.typeId !== "minecraft:player") return;

    const ps = pendingShotUntil.get(owner.id);
    if (!ps || system.currentTick > ps.until) return;
    pendingShotUntil.delete(owner.id);

    const qid = ps.qid ?? (playerActiveQuiver.get(owner.id) ?? null);
    if (!qid) return;

    system.runTimeout(() => {
        try { handleArrowConsumedFromBuffer(owner, qid); } catch { }
    }, 10);
});

// ════════════════════════════════════════════════
//  Periodic Cleanup (ОПТИМИЗИРОВАНО: 10 тиков → 100 тиков)
// ════════════════════════════════════════════════

// Синхронизация буферов — увеличен интервал: 20 → 40 тиков
system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        try { syncBufferState(player); } catch { }
    }
}, 40);

// Очистка buffer marks в вагонетках — 10 → 100 тиков
// Item entities уже обрабатываются через entitySpawn выше
system.runInterval(() => {
    for (const dimId of DIM_IDS) {
        try {
            const dim = world.getDimension(dimId);

            for (const entity of dim.getEntities({ type: "minecraft:hopper_minecart" })) {
                try {
                    const container = entity.getComponent(EntityComponentTypes.Inventory)?.container;
                    if (!container) continue;
                    for (let i = 0; i < container.size; i++) {
                        const item = container.getItem(i);
                        if (item && isArrow(item) && getBufferQid(item)) {
                            clearBufferMarks(item);
                            container.setItem(i, item);
                        }
                    }
                } catch { }
            }

            for (const entity of dim.getEntities({ type: "minecraft:chest_minecart" })) {
                try {
                    const container = entity.getComponent(EntityComponentTypes.Inventory)?.container;
                    if (!container) continue;
                    for (let i = 0; i < container.size; i++) {
                        const item = container.getItem(i);
                        if (item && isArrow(item) && getBufferQid(item)) {
                            clearBufferMarks(item);
                            container.setItem(i, item);
                        }
                    }
                } catch { }
            }
        } catch { }
    }
}, 100);

// ════════════════════════════════════════════════
//  Death & Lifecycle
// ════════════════════════════════════════════════

world.afterEvents.entityDie.subscribe((ev) => {
    const entity = ev.deadEntity;
    if (!entity || entity.typeId !== "minecraft:item") return;

    try {
        const item = entity.getComponent("minecraft:item")?.itemStack;
        if (!isQuiver(item)) return;

        const qid = getQidFromItem(item);
        if (!qid) return;

        const store = findStore(qid);
        if (!store) return;

        const storeInv = getStoreInv(store);
        if (!storeInv) return;

        const dim = entity.dimension;
        const loc = entity.location;

        for (let i = 0; i < QUIVER_SLOTS; i++) {
            const st = storeInv.getItem(i);
            if (!st) continue;
            storeInv.setItem(i, undefined);
            try { dim.spawnItem(st, loc); } catch { }
        }

        clearStoreCache(qid);
        try { store.remove(); } catch { }
    } catch { }
});

world.afterEvents.playerSpawn.subscribe((ev) => {
    const player = ev.player;
    if (!player) return;
    system.runTimeout(() => { try { syncBufferState(player); } catch { } }, 5);
});

world.afterEvents.playerLeave.subscribe((ev) => {
    const pid = ev.playerId;
    interactCooldowns.delete(pid);
    playerActiveQuiver.delete(pid);
    pendingShotUntil.delete(pid);
    legitimateBufferSlots.delete(pid);
});