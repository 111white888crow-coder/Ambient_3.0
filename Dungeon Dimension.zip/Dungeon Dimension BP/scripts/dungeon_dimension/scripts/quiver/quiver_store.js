// scripts/quiver/quiver_store.js
// ── Store entity management с кэшированием + ticking area ──

import { world, system, EntityComponentTypes } from "@minecraft/server";
import {
    DIM_IDS, QUIVER_SLOTS, STORE_ENTITY_ID,
    STORE_ANCHOR_DIM_ID, STORE_ANCHOR_X, STORE_ANCHOR_Z, STORE_ANCHOR_Y,
    STORE_TICKING_ID
} from "./quiver_const.js";

// ═══════════════════════════════════════════════
//  Store Cache — ключевая оптимизация
// ═══════════════════════════════════════════════

const _storeCache = new Map(); // qid → Entity

export function clearStoreCache(qid) {
    if (qid) _storeCache.delete(qid);
    else _storeCache.clear();
}

// ═══════════════════════════════════════════════
//  Ticking Area
// ═══════════════════════════════════════════════

let anchorTickingReady = false;
let anchorTickingInFlight = false;

const getAnchorDimension = () => {
    try { return world.getDimension(STORE_ANCHOR_DIM_ID); }
    catch { return world.getDimension("overworld"); }
};

const getAnchorPos = () => ({ x: STORE_ANCHOR_X, y: STORE_ANCHOR_Y, z: STORE_ANCHOR_Z });

export async function ensureAnchorTickingArea() {
    if (anchorTickingReady || anchorTickingInFlight) return;
    anchorTickingInFlight = true;
    try {
        const dim = getAnchorDimension();
        const baseX = Math.floor(STORE_ANCHOR_X / 16) * 16;
        const baseZ = Math.floor(STORE_ANCHOR_Z / 16) * 16;
        const from = { x: baseX, y: 0, z: baseZ };
        const to = { x: baseX + 15, y: 0, z: baseZ + 15 };

        try {
            const tam = world.tickingAreaManager;
            if (tam?.hasTickingArea?.(STORE_TICKING_ID)) { anchorTickingReady = true; return; }
            if (tam?.createTickingArea) {
                await tam.createTickingArea(STORE_TICKING_ID, { dimension: dim, from, to });
                anchorTickingReady = true;
                return;
            }
        } catch { }

        try {
            await dim.runCommandAsync(`/tickingarea add ${from.x} 0 ${from.z} ${to.x} 0 ${to.z} ${STORE_TICKING_ID} true`);
            anchorTickingReady = true;
        } catch { }
    } finally {
        anchorTickingInFlight = false;
    }
}

// Инициализация при загрузке
system.runTimeout(() => { try { void ensureAnchorTickingArea(); } catch { } }, 1);
system.runInterval(() => { try { void ensureAnchorTickingArea(); } catch { } }, 200);

// ═══════════════════════════════════════════════
//  Store Entity Operations
// ═══════════════════════════════════════════════

export function findStore(qid) {
    // 1. Кэш — O(1)
    const cached = _storeCache.get(qid);
    if (cached) {
        try { if (cached.isValid()) return cached; } catch { }
        _storeCache.delete(qid);
    }

    // 2. Полный поиск (только при промахе кэша)
    for (const dimId of DIM_IDS) {
        try {
            for (const e of world.getDimension(dimId).getEntities({ type: STORE_ENTITY_ID, tags: [qid] })) {
                _storeCache.set(qid, e);
                return e;
            }
        } catch { }
    }
    return null;
}

export const getStoreInv = (store) => store?.getComponent(EntityComponentTypes.Inventory)?.container;

function safeSpawnStoreAtAnchor(dim, qid) {
    const pos = getAnchorPos();
    let store;
    try { store = dim.spawnEntity(STORE_ENTITY_ID, pos); }
    catch {
        let fallbackY = 319;
        try { const hr = dim.heightRange; if (hr?.max) fallbackY = Math.floor(hr.max) - 1; } catch { }
        store = dim.spawnEntity(STORE_ENTITY_ID, { x: pos.x, y: fallbackY, z: pos.z });
    }
    store.addTag(qid);
    store.addTag("quiver_store");
    _storeCache.set(qid, store);
    return store;
}

function safeTeleportStoreToAnchor(store, dim) {
    const pos = getAnchorPos();
    try { store.teleport(pos, { dimension: dim }); return true; }
    catch {
        let fallbackY = 319;
        try { const hr = dim.heightRange; if (hr?.max) fallbackY = Math.floor(hr.max) - 1; } catch { }
        try { store.teleport({ x: pos.x, y: fallbackY, z: pos.z }, { dimension: dim }); return true; }
        catch { return false; }
    }
}

export function getOrCreateStore(player, qid) {
    try { void ensureAnchorTickingArea(); } catch { }
    const anchorDim = getAnchorDimension();
    let store = findStore(qid);

    if (store) {
        if (store.dimension.id !== anchorDim.id) {
            const oldInv = getStoreInv(store);
            const items = [];
            for (let i = 0; i < QUIVER_SLOTS; i++) items.push(oldInv?.getItem(i));
            try { store.remove(); } catch { }
            store = safeSpawnStoreAtAnchor(anchorDim, qid);
            const newInv = getStoreInv(store);
            if (newInv) for (let i = 0; i < QUIVER_SLOTS; i++) if (items[i]) newInv.setItem(i, items[i]);
        }
        safeTeleportStoreToAnchor(store, anchorDim);
        return store;
    }

    store = safeSpawnStoreAtAnchor(anchorDim, qid);
    safeTeleportStoreToAnchor(store, anchorDim);
    return store;
}

export function isStoreEmpty(storeInv) {
    for (let i = 0; i < QUIVER_SLOTS; i++) if (storeInv.getItem(i)) return false;
    return true;
}
