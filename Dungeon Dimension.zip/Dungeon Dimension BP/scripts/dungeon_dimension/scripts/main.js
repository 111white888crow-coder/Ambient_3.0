//scripts/main.js
// ═══════════════════════════════════════════════════════════
// Точка входа — загрузка всех систем
// ═══════════════════════════════════════════════════════════

import './controlers/main_.js';
import './quiver/main_.js';
import './bow/main_.js';

// ★ Боевая система (полная инициализация) ★
import './combat_core/index.js';

import "./SlideOnly.js";

import "./handlers/Rolls.js";