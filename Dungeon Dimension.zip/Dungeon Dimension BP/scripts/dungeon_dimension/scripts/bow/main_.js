// scripts/bow/main_.js
import './hanter_bow.js';
