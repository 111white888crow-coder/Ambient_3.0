// scripts/bow/hanter_bow.js
// ── Скрипт стрельбы для кастомного лука sag:hanter_bow ──
// Обрабатывает зарядку, выстрел стрелой (ванильной) и расход прочности.

import {
    world, system,
    EquipmentSlot, EntityComponentTypes, GameMode,
    ItemStack
} from "@minecraft/server";

const BOW_ID = "sag:hanter_bow";
const MIN_CHARGE_TICKS = 3;        // минимум тиков зарядки для выстрела
const MAX_CHARGE_TICKS = 20;       // полная зарядка (1 секунда)
const BASE_ARROW_SPEED = 3.0;      // скорость стрелы при полной зарядке
const MIN_ARROW_SPEED = 0.5;       // минимальная скорость (при минимальной зарядке)
const BASE_ARROW_DAMAGE = 6;       // базовый урон стрелы

// ── Хранилище состояний зарядки ──
/** @type {Map<string, number>} playerId → tick когда начал заряжать */
const chargingPlayers = new Map();

// ════════════════════════════════════════════════
//  Утилиты
// ════════════════════════════════════════════════

function getEquippable(player) {
    try {
        return player.getComponent(EntityComponentTypes.Equippable) ?? null;
    } catch { return null; }
}

function getMainhandItem(player) {
    try {
        return getEquippable(player)?.getEquipment(EquipmentSlot.Mainhand) ?? null;
    } catch { return null; }
}

function isHanterBow(item) {
    return item && item.typeId === BOW_ID;
}

/**
 * Ищет стрелу в инвентаре игрока и возвращает слот и предмет.
 * Приоритет: offhand → hotbar слева направо → инвентарь.
 */
function findArrowInInventory(player) {
    const equippable = getEquippable(player);

    // 1) Проверяем offhand
    try {
        const offhand = equippable?.getEquipment(EquipmentSlot.Offhand);
        if (offhand && offhand.typeId.includes("arrow")) {
            return { slot: -1, item: offhand, isOffhand: true };
        }
    } catch { }

    // 2) Проверяем инвентарь
    try {
        const inv = player.getComponent(EntityComponentTypes.Inventory)?.container;
        if (!inv) return null;

        for (let i = 0; i < inv.size; i++) {
            const item = inv.getItem(i);
            if (item && item.typeId.includes("arrow")) {
                return { slot: i, item, isOffhand: false };
            }
        }
    } catch { }

    return null;
}

/**
 * Убирает одну стрелу из найденного слота.
 */
function consumeArrow(player, arrowInfo) {
    if (!arrowInfo) return;

    try {
        if (arrowInfo.isOffhand) {
            const equippable = getEquippable(player);
            if (arrowInfo.item.amount <= 1) {
                equippable.setEquipment(EquipmentSlot.Offhand, undefined);
            } else {
                arrowInfo.item.amount -= 1;
                equippable.setEquipment(EquipmentSlot.Offhand, arrowInfo.item);
            }
        } else {
            const inv = player.getComponent(EntityComponentTypes.Inventory)?.container;
            if (!inv) return;
            if (arrowInfo.item.amount <= 1) {
                inv.setItem(arrowInfo.slot, undefined);
            } else {
                arrowInfo.item.amount -= 1;
                inv.setItem(arrowInfo.slot, arrowInfo.item);
            }
        }
    } catch { }
}

/**
 * Уменьшает прочность лука на 1.
 */
function damageBow(player) {
    try {
        const equippable = getEquippable(player);
        const bow = equippable?.getEquipment(EquipmentSlot.Mainhand);
        if (!bow || !isHanterBow(bow)) return;

        const durability = bow.getComponent("minecraft:durability");
        if (!durability) return;

        durability.damage += 1;
        if (durability.damage >= durability.maxDurability) {
            // Лук сломался
            equippable.setEquipment(EquipmentSlot.Mainhand, undefined);
            try { player.playSound("random.break"); } catch { }
        } else {
            equippable.setEquipment(EquipmentSlot.Mainhand, bow);
        }
    } catch { }
}

/**
 * Проверяет, находится ли игрок в креативе.
 */
function isCreative(player) {
    try {
        return player.getGameMode() === GameMode.creative;
    } catch { return false; }
}

// ════════════════════════════════════════════════
//  Events
// ════════════════════════════════════════════════

// ── Начало зарядки (ПКМ зажат) ──
world.afterEvents.itemStartUse.subscribe((ev) => {
    const player = ev.source;
    if (!player || player.typeId !== "minecraft:player") return;
    if (!isHanterBow(ev.itemStack)) return;

    // Проверяем наличие стрел (в креативе не нужно)
    if (!isCreative(player)) {
        const arrow = findArrowInInventory(player);
        if (!arrow) return;
    }

    chargingPlayers.set(player.id, system.currentTick);
});

// ── Отпускание (выстрел) ──
world.afterEvents.itemReleaseUse.subscribe((ev) => {
    const player = ev.source;
    if (!player || player.typeId !== "minecraft:player") return;
    if (!isHanterBow(ev.itemStack)) return;

    const startTick = chargingPlayers.get(player.id);
    chargingPlayers.delete(player.id);

    if (startTick === undefined) return;

    const chargeDuration = system.currentTick - startTick;
    if (chargeDuration < MIN_CHARGE_TICKS) return;

    // Определяем силу выстрела (0..1)
    const chargeRatio = Math.min(chargeDuration / MAX_CHARGE_TICKS, 1.0);
    const speed = MIN_ARROW_SPEED + (BASE_ARROW_SPEED - MIN_ARROW_SPEED) * chargeRatio;

    const creative = isCreative(player);

    // Ищем стрелу
    let arrowInfo = null;
    let arrowTypeId = "minecraft:arrow";

    if (!creative) {
        arrowInfo = findArrowInInventory(player);
        if (!arrowInfo) return;
        arrowTypeId = arrowInfo.item.typeId;
    }

    // Спавним стрелу
    try {
        const viewDir = player.getViewDirection();
        const headLoc = player.getHeadLocation();

        // Спавним немного впереди игрока
        const spawnLoc = {
            x: headLoc.x + viewDir.x * 0.5,
            y: headLoc.y + viewDir.y * 0.5 - 0.1,
            z: headLoc.z + viewDir.z * 0.5
        };

        const arrow = player.dimension.spawnEntity(arrowTypeId, spawnLoc);

        // Настраиваем проджектайл
        const projectile = arrow.getComponent("minecraft:projectile");
        if (projectile) {
            projectile.owner = player;
            projectile.shoot(
                { x: viewDir.x * speed, y: viewDir.y * speed, z: viewDir.z * speed }
            );
        }

        // Звук выстрела
        try {
            player.playSound("random.bow", { volume: 1.0, pitch: 1.0 / (1.0 + (1.0 - chargeRatio) * 0.5) });
        } catch { }

        // Расходуем стрелу (кроме креатива)
        if (!creative) {
            consumeArrow(player, arrowInfo);
        }

        // Урон по прочности лука
        if (!creative) {
            damageBow(player);
        }

    } catch (e) { }
});

// ── Прервали использование ──
world.afterEvents.itemStopUse.subscribe((ev) => {
    const player = ev.source;
    if (!player || player.typeId !== "minecraft:player") return;
    if (ev.itemStack && isHanterBow(ev.itemStack)) {
        chargingPlayers.delete(player.id);
    }
});

// ── Очистка при выходе ──
world.afterEvents.playerLeave.subscribe((ev) => {
    chargingPlayers.delete(ev.playerId);
});
