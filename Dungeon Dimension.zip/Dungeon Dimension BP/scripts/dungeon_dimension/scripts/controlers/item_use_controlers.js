// scripts/controlers/item_use_controlers.js
// ── Контроллер использования/удара предметами ──
// Отслеживает ВСЕ действия игрока с предметами через event-driven подход.
// Другие скрипты импортируют функции и константы для проверки состояний.

import { world, system, EquipmentSlot, EntityComponentTypes } from "@minecraft/server";

// ═══════════════════════════════════════════════
//  Константы действий (экспортируются)
// ═══════════════════════════════════════════════

// ── Удары (melee) ──
export const HIT_ENTITY = "HIT_ENTITY";        // ударил моба/игрока
export const HIT_BLOCK = "HIT_BLOCK";          // ударил по блоку (ЛКМ)

// ── Swing (анимация взмаха) — новое в API! ──
export const SWING_ATTACK = "SWING_ATTACK";       // взмах: атака
export const SWING_MINE = "SWING_MINE";         // взмах: копание
export const SWING_BUILD = "SWING_BUILD";        // взмах: строительство
export const SWING_INTERACT = "SWING_INTERACT";     // взмах: взаимодействие
export const SWING_USE_ITEM = "SWING_USE_ITEM";     // взмах: использование предмета
export const SWING_DROP_ITEM = "SWING_DROP_ITEM";    // взмах: выброс предмета
export const SWING_THROW_ITEM = "SWING_THROW_ITEM";   // взмах: бросок предмета

// ── Использование предмета ──
export const ITEM_USE = "ITEM_USE";           // предмет использован (ПКМ — еда, зелье, и т.д.)
export const ITEM_USE_ON_BLOCK = "ITEM_USE_ON_BLOCK";  // предмет использован на блоке
export const ITEM_USE_ON_ENTITY = "ITEM_USE_ON_ENTITY"; // взаимодействие с мобом (ПКМ)

// ── Заряжаемые предметы (лук, арбалет, трезубец) ──
export const ITEM_START_CHARGE = "ITEM_START_CHARGE";  // начал заряжать
export const ITEM_CHARGING = "ITEM_CHARGING";      // заряжает (активное состояние)
export const ITEM_RELEASE = "ITEM_RELEASE";       // отпустил (выстрел)
export const ITEM_COMPLETE_USE = "ITEM_COMPLETE_USE";  // зарядка завершена (еда доедена)
export const ITEM_STOP_USE = "ITEM_STOP_USE";      // прервал использование

// ── Блоки ──
export const BREAK_BLOCK = "BREAK_BLOCK";        // сломал блок
export const PLACE_BLOCK = "PLACE_BLOCK";        // поставил блок

// ── Проджектайлы ──
export const PROJECTILE_HIT_ENTITY = "PROJECTILE_HIT_ENTITY"; // снаряд попал в моба
export const PROJECTILE_HIT_BLOCK = "PROJECTILE_HIT_BLOCK";  // снаряд попал в блок

// ── Получение урона ──
export const ENTITY_HURT = "ENTITY_HURT";        // игрок получил урон

// ═══════════════════════════════════════════════
//  Внутреннее хранилище
// ═══════════════════════════════════════════════

/**
 * @typedef {Object} ActionEntry
 * @property {string} action — константа действия
 * @property {number} tick — system.currentTick когда произошло
 * @property {import("@minecraft/server").ItemStack} [item] — предмет в руке
 * @property {import("@minecraft/server").Entity} [targetEntity] — целевая сущность
 * @property {import("@minecraft/server").Block} [targetBlock] — целевой блок
 * @property {string} [swingSource] — источник взмаха (EntitySwingSource)
 * @property {object} [extra] — доп. данные
 */

/** @type {Map<string, ActionEntry[]>} playerId → массив последних действий */
const _actionLog = new Map();

/** @type {Map<string, ActionEntry>} playerId → последнее действие */
const _lastAction = new Map();

/** @type {Map<string, Set<string>>} playerId → текущие активные состояния */
const _activeStates = new Map();

// Макс. количество записей в логе на игрока
const MAX_LOG_SIZE = 20;

// Длительность "активности" действия в тиках
const ACTION_ACTIVE_TICKS = 5;

// ═══════════════════════════════════════════════
//  Внутренние хелперы
// ═══════════════════════════════════════════════

function getHeldItem(player) {
    try {
        return player.getComponent(EntityComponentTypes.Equippable)
            ?.getEquipment(EquipmentSlot.Mainhand) ?? null;
    } catch { return null; }
}

function pushAction(playerId, entry) {
    entry.tick = system.currentTick;

    _lastAction.set(playerId, entry);

    let log = _actionLog.get(playerId);
    if (!log) {
        log = [];
        _actionLog.set(playerId, log);
    }
    log.push(entry);
    if (log.length > MAX_LOG_SIZE) log.shift();

    // Добавляем в активные состояния
    let states = _activeStates.get(playerId);
    if (!states) {
        states = new Set();
        _activeStates.set(playerId, states);
    }
    states.add(entry.action);

    // Убираем через ACTION_ACTIVE_TICKS
    system.runTimeout(() => {
        const s = _activeStates.get(playerId);
        if (s) s.delete(entry.action);
    }, ACTION_ACTIVE_TICKS);
}

// ═══════════════════════════════════════════════
//  Подписки на события
// ═══════════════════════════════════════════════

// ── playerSwingStart — взмах руки (КЛЮЧЕВОЕ событие!) ──
// Даёт swingSource: Attack, Mine, Build, Interact, UseItem, DropItem, ThrowItem
try {
    world.afterEvents.playerSwingStart.subscribe((ev) => {
        const { player, heldItemStack, swingSource } = ev;
        if (!player) return;

        const sourceMap = {
            "Attack": SWING_ATTACK,
            "Mine": SWING_MINE,
            "Build": SWING_BUILD,
            "Interact": SWING_INTERACT,
            "UseItem": SWING_USE_ITEM,
            "DropItem": SWING_DROP_ITEM,
            "ThrowItem": SWING_THROW_ITEM,
        };

        const action = sourceMap[swingSource];
        if (action) {
            pushAction(player.id, {
                action,
                item: heldItemStack ?? null,
                swingSource,
            });
        }
    });
} catch { }

// ── entityHitEntity — melee удар по мобу/игроку ──
try {
    world.afterEvents.entityHitEntity.subscribe((ev) => {
        const player = ev.damagingEntity;
        if (!player || player.typeId !== "minecraft:player") return;
        pushAction(player.id, {
            action: HIT_ENTITY,
            item: getHeldItem(player),
            targetEntity: ev.hitEntity,
        });
    });
} catch { }

// ── entityHitBlock — melee удар по блоку ──
try {
    world.afterEvents.entityHitBlock.subscribe((ev) => {
        const player = ev.damagingEntity;
        if (!player || player.typeId !== "minecraft:player") return;
        pushAction(player.id, {
            action: HIT_BLOCK,
            item: getHeldItem(player),
            targetBlock: ev.hitBlock,
        });
    });
} catch { }

// ── itemUse — использование предмета (ПКМ) ──
try {
    world.afterEvents.itemUse.subscribe((ev) => {
        const player = ev.source;
        if (!player || player.typeId !== "minecraft:player") return;
        pushAction(player.id, {
            action: ITEM_USE,
            item: ev.itemStack,
        });
    });
} catch { }

// ── itemStartUseOn — использование предмета НА блоке ──
try {
    world.afterEvents.itemStartUseOn.subscribe((ev) => {
        const player = ev.source;
        if (!player || player.typeId !== "minecraft:player") return;
        pushAction(player.id, {
            action: ITEM_USE_ON_BLOCK,
            item: ev.itemStack,
            targetBlock: ev.block,
            extra: { blockFace: ev.blockFace },
        });
    });
} catch { }

// ── playerInteractWithEntity — ПКМ по мобу ──
try {
    world.afterEvents.playerInteractWithEntity.subscribe((ev) => {
        const player = ev.player;
        if (!player) return;
        pushAction(player.id, {
            action: ITEM_USE_ON_ENTITY,
            item: ev.itemStack,
            targetEntity: ev.target,
        });
    });
} catch { }

// ── playerInteractWithBlock — ПКМ по блоку (открыть сундук и т.д.) ──
try {
    world.afterEvents.playerInteractWithBlock.subscribe((ev) => {
        const player = ev.player;
        if (!player) return;
        pushAction(player.id, {
            action: ITEM_USE_ON_BLOCK,
            item: ev.itemStack,
            targetBlock: ev.block,
            extra: { blockFace: ev.blockFace, isFirstEvent: ev.isFirstEvent },
        });
    });
} catch { }

// ── itemStartUse — начал заряжать (лук, арбалет, еда) ──
try {
    world.afterEvents.itemStartUse.subscribe((ev) => {
        const player = ev.source;
        if (!player || player.typeId !== "minecraft:player") return;

        // Отмечаем как активное состояние ITEM_CHARGING
        let states = _activeStates.get(player.id);
        if (!states) {
            states = new Set();
            _activeStates.set(player.id, states);
        }
        states.add(ITEM_CHARGING);

        pushAction(player.id, {
            action: ITEM_START_CHARGE,
            item: ev.itemStack,
            extra: { useDuration: ev.useDuration },
        });
    });
} catch { }

// ── itemReleaseUse — отпустил (выстрел из лука) ──
try {
    world.afterEvents.itemReleaseUse.subscribe((ev) => {
        const player = ev.source;
        if (!player || player.typeId !== "minecraft:player") return;

        // Снимаем ITEM_CHARGING
        const states = _activeStates.get(player.id);
        if (states) states.delete(ITEM_CHARGING);

        pushAction(player.id, {
            action: ITEM_RELEASE,
            item: ev.itemStack,
            extra: { useDuration: ev.useDuration },
        });
    });
} catch { }

// ── itemCompleteUse — зарядка завершена (еда доедена) ──
try {
    world.afterEvents.itemCompleteUse.subscribe((ev) => {
        const player = ev.source;
        if (!player || player.typeId !== "minecraft:player") return;

        const states = _activeStates.get(player.id);
        if (states) states.delete(ITEM_CHARGING);

        pushAction(player.id, {
            action: ITEM_COMPLETE_USE,
            item: ev.itemStack,
            extra: { useDuration: ev.useDuration },
        });
    });
} catch { }

// ── itemStopUse — прервал использование ──
try {
    world.afterEvents.itemStopUse.subscribe((ev) => {
        const player = ev.source;
        if (!player || player.typeId !== "minecraft:player") return;

        const states = _activeStates.get(player.id);
        if (states) states.delete(ITEM_CHARGING);

        pushAction(player.id, {
            action: ITEM_STOP_USE,
            item: ev.itemStack,
            extra: { useDuration: ev.useDuration },
        });
    });
} catch { }

// ── playerBreakBlock ──
try {
    world.afterEvents.playerBreakBlock.subscribe((ev) => {
        pushAction(ev.player.id, {
            action: BREAK_BLOCK,
            item: ev.itemStackAfterBreak,
            targetBlock: ev.block,
            extra: { brokenBlockPermutation: ev.brokenBlockPermutation },
        });
    });
} catch { }

// ── playerPlaceBlock ──
try {
    world.afterEvents.playerPlaceBlock.subscribe((ev) => {
        pushAction(ev.player.id, {
            action: PLACE_BLOCK,
            item: getHeldItem(ev.player),
            targetBlock: ev.block,
        });
    });
} catch { }

// ── projectileHitEntity ──
try {
    world.afterEvents.projectileHitEntity.subscribe((ev) => {
        const owner = ev.source;
        if (!owner || owner.typeId !== "minecraft:player") return;
        pushAction(owner.id, {
            action: PROJECTILE_HIT_ENTITY,
            extra: {
                projectileId: ev.projectile?.typeId,
                hitEntity: ev.getEntityHit()?.entity,
            },
        });
    });
} catch { }

// ── projectileHitBlock ──
try {
    world.afterEvents.projectileHitBlock.subscribe((ev) => {
        const owner = ev.source;
        if (!owner || owner.typeId !== "minecraft:player") return;
        pushAction(owner.id, {
            action: PROJECTILE_HIT_BLOCK,
            extra: {
                projectileId: ev.projectile?.typeId,
                hitBlock: ev.getBlockHit()?.block,
            },
        });
    });
} catch { }

// ── entityHurt (игрок получает урон) ──
try {
    world.afterEvents.entityHurt.subscribe((ev) => {
        const entity = ev.hurtEntity;
        if (!entity || entity.typeId !== "minecraft:player") return;
        pushAction(entity.id, {
            action: ENTITY_HURT,
            extra: {
                damage: ev.damage,
                damageSource: ev.damageSource,
            },
        });
    });
} catch { }

// ═══════════════════════════════════════════════
//  Очистка при выходе
// ═══════════════════════════════════════════════

world.afterEvents.playerLeave.subscribe((ev) => {
    _actionLog.delete(ev.playerId);
    _lastAction.delete(ev.playerId);
    _activeStates.delete(ev.playerId);
});

// ═══════════════════════════════════════════════
//  Публичный API
// ═══════════════════════════════════════════════

const _emptySet = Object.freeze(new Set());

/**
 * Проверить, активно ли действие прямо сейчас (в пределах ACTION_ACTIVE_TICKS).
 * @param {import("@minecraft/server").Player} player
 * @param {string} action — одна из экспортированных констант
 * @returns {boolean}
 *
 * @example
 * import { isActionActive, SWING_ATTACK } from "./controlers/item_use_controlers";
 * if (isActionActive(player, SWING_ATTACK)) { // игрок только что атаковал }
 */
export function isActionActive(player, action) {
    const s = _activeStates.get(player.id);
    return s ? s.has(action) : false;
}

/**
 * Получить Set всех текущих активных действий.
 * @param {import("@minecraft/server").Player} player
 * @returns {ReadonlySet<string>}
 */
export function getActiveActions(player) {
    return _activeStates.get(player.id) ?? _emptySet;
}

/**
 * Получить последнее действие игрока.
 * @param {import("@minecraft/server").Player} player
 * @returns {ActionEntry|null}
 */
export function getLastAction(player) {
    return _lastAction.get(player.id) ?? null;
}

/**
 * Получить последнее действие определённого типа.
 * @param {import("@minecraft/server").Player} player
 * @param {string} action
 * @returns {ActionEntry|null}
 */
export function getLastActionOfType(player, action) {
    const log = _actionLog.get(player.id);
    if (!log) return null;
    for (let i = log.length - 1; i >= 0; i--) {
        if (log[i].action === action) return log[i];
    }
    return null;
}

/**
 * Проверить, произошло ли действие в последние N тиков.
 * @param {import("@minecraft/server").Player} player
 * @param {string} action
 * @param {number} [withinTicks=10]
 * @returns {boolean}
 *
 * @example
 * import { didAction, HIT_ENTITY, ITEM_USE } from "./controlers/item_use_controlers";
 * // Игрок ударил моба в последние 10 тиков?
 * if (didAction(player, HIT_ENTITY)) { ... }
 * // Игрок использовал предмет в последние 3 тика?
 * if (didAction(player, ITEM_USE, 3)) { ... }
 */
export function didAction(player, action, withinTicks = 10) {
    const log = _actionLog.get(player.id);
    if (!log) return false;
    const threshold = system.currentTick - withinTicks;
    for (let i = log.length - 1; i >= 0; i--) {
        if (log[i].tick < threshold) return false;
        if (log[i].action === action) return true;
    }
    return false;
}

/**
 * Проверить, произошли ли ВСЕ указанные действия в последние N тиков.
 * @param {import("@minecraft/server").Player} player
 * @param {string[]} actions
 * @param {number} [withinTicks=10]
 * @returns {boolean}
 */
export function didAllActions(player, actions, withinTicks = 10) {
    for (const a of actions) {
        if (!didAction(player, a, withinTicks)) return false;
    }
    return true;
}

/**
 * Проверить, заряжает ли игрок предмет прямо сейчас (лук, арбалет, еда...).
 * @param {import("@minecraft/server").Player} player
 * @returns {boolean}
 */
export function isCharging(player) {
    return isActionActive(player, ITEM_CHARGING);
}

/**
 * Получить полный лог действий игрока (последние MAX_LOG_SIZE записей).
 * @param {import("@minecraft/server").Player} player
 * @returns {ReadonlyArray<ActionEntry>}
 */
export function getActionLog(player) {
    return _actionLog.get(player.id) ?? [];
}
