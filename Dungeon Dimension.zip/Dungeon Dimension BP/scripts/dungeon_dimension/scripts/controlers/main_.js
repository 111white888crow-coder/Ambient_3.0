// scripts/controlers/main_.js
import './move_controlers.js';
import './item_use_controlers.js';