// scripts/controlers/move_controlers.js
// ── Утилита для определения действий игрока (движение, прыжок, и т.д.) ──
// Другие скрипты импортируют getPlayerActions(player) чтобы получить текущие действия.

import { world, system } from "@minecraft/server";

// ═══════════════════════════════════════════════
//  Константы действий
// ═══════════════════════════════════════════════
export const MOVE_FORWARD = "MOVE_FORWARD";
export const MOVE_BACKWARD = "MOVE_BACKWARD";
export const STRAFE_LEFT = "STRAFE_LEFT";
export const STRAFE_RIGHT = "STRAFE_RIGHT";
export const JUMPING = "JUMPING";
export const FALLING = "FALLING";
export const SNEAKING = "SNEAKING";
export const SPRINTING = "SPRINTING";
export const SWIMMING = "SWIMMING";
export const GLIDING = "GLIDING";
export const FLYING = "FLYING";
export const CLIMBING = "CLIMBING";
export const ON_GROUND = "ON_GROUND";
export const IDLE = "IDLE";

// ═══════════════════════════════════════════════
//  Внутреннее хранилище
// ═══════════════════════════════════════════════

/** @type {Map<string, Set<string>>} playerId → Set<action> */
const _actions = new Map();

/** @type {Map<string, {x:number, y:number, z:number}>} playerId → prevLocation */
const _prevLoc = new Map();

// Порог квадрата горизонтальной скорости, ниже которого игрок "стоит"
const MOVE_THRESHOLD_SQ = 0.0001; // ~0.01 блока/тик

// ═══════════════════════════════════════════════
//  Основной цикл — 1 раз/тик
// ═══════════════════════════════════════════════
system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        if (!player) continue;
        computeActions(player);
    }
});

// ═══════════════════════════════════════════════
//  Вычисление действий 
// ═══════════════════════════════════════════════

/**
 * @param {import("@minecraft/server").Player} player
 */
function computeActions(player) {
    const id = player.id;
    const actions = new Set();

    // ── Простые флаги (читаются напрямую, без вычислений) ──
    if (player.isSneaking) actions.add(SNEAKING);
    if (player.isSprinting) actions.add(SPRINTING);
    if (player.isJumping) actions.add(JUMPING);
    if (player.isFalling) actions.add(FALLING);
    if (player.isOnGround) actions.add(ON_GROUND);
    if (player.isSwimming) actions.add(SWIMMING);
    if (player.isGliding) actions.add(GLIDING);
    if (player.isFlying) actions.add(FLYING);
    if (player.isClimbing) actions.add(CLIMBING);

    // ── Определение направления движения ──
    const loc = player.location;
    const prev = _prevLoc.get(id);

    if (prev) {
        const dx = loc.x - prev.x;
        const dz = loc.z - prev.z;
        const distSq = dx * dx + dz * dz;

        if (distSq > MOVE_THRESHOLD_SQ) {
            // Вектор направления взгляда (горизонт)
            const view = player.getViewDirection();
            const vx = view.x;
            const vz = view.z;

            // Нормализация вектора взгляда на горизонтальной плоскости
            const vLen = Math.sqrt(vx * vx + vz * vz);
            if (vLen > 0.001) {
                const fwdX = vx / vLen;
                const fwdZ = vz / vLen;

                // Вектор "вправо" (перпендикуляр на горизонтальной плоскости)
                const rightX = -fwdZ;
                const rightZ = fwdX;

                // Нормализация вектора движения
                const dist = Math.sqrt(distSq);
                const mx = dx / dist;
                const mz = dz / dist;

                // Проекция движения на forward и right
                const dotFwd = mx * fwdX + mz * fwdZ;
                const dotRight = mx * rightX + mz * rightZ;

                // Пороги — cos(67.5°) ≈ 0.38 позволяет детектить диагональное движение
                const DIR_THRESHOLD = 0.38;

                if (dotFwd > DIR_THRESHOLD) actions.add(MOVE_FORWARD);
                if (dotFwd < -DIR_THRESHOLD) actions.add(MOVE_BACKWARD);
                if (dotRight > DIR_THRESHOLD) actions.add(STRAFE_RIGHT);
                if (dotRight < -DIR_THRESHOLD) actions.add(STRAFE_LEFT);
            }
        }
    }

    // Если ни одно направление движения не найдено и на земле — IDLE
    if (!actions.has(MOVE_FORWARD) &&
        !actions.has(MOVE_BACKWARD) &&
        !actions.has(STRAFE_LEFT) &&
        !actions.has(STRAFE_RIGHT) &&
        !actions.has(JUMPING) &&
        !actions.has(FALLING) &&
        player.isOnGround) {
        actions.add(IDLE);
    }

    // Сохраняем для следующего тика
    _prevLoc.set(id, { x: loc.x, y: loc.y, z: loc.z });
    _actions.set(id, actions);
}

// ═══════════════════════════════════════════════
//  Публичный API
// ═══════════════════════════════════════════════

/**
 * Получить Set текущих действий игрока.
 * @param {import("@minecraft/server").Player} player
 * @returns {Set<string>} 
 * 
 * @example
 * import { getPlayerActions, MOVE_FORWARD } from "./controlers/move_controlers";
 * 
 * // В другом скрипте:
 * const actions = getPlayerActions(player);
 * if (actions.has(MOVE_FORWARD)) {
 *     // игрок идёт вперёд
 * }
 */
export function getPlayerActions(player) {
    return _actions.get(player.id) ?? _emptySet;
}

/**
 * Проверить, выполняет ли игрок конкретное действие.
 * @param {import("@minecraft/server").Player} player
 * @param {string} action — одна из экспортированных констант
 * @returns {boolean}
 * 
 * @example
 * import { hasAction, MOVE_FORWARD, SPRINTING } from "./controlers/move_controlers";
 * 
 * if (hasAction(player, MOVE_FORWARD) && hasAction(player, SPRINTING)) {
 *     // игрок бежит вперёд
 * }
 */
export function hasAction(player, action) {
    const set = _actions.get(player.id);
    return set ? set.has(action) : false;
}

/**
 * Проверить, выполняет ли игрок ВСЕ указанные действия одновременно.
 * @param {import("@minecraft/server").Player} player
 * @param {...string} actions
 * @returns {boolean}
 * 
 * @example
 * import { hasAllActions, MOVE_FORWARD, SNEAKING } from "./controlers/move_controlers";
 * 
 * if (hasAllActions(player, MOVE_FORWARD, SNEAKING)) {
 *     // крадётся вперёд
 * }
 */
export function hasAllActions(player, ...actions) {
    const set = _actions.get(player.id);
    if (!set) return false;
    for (let i = 0; i < actions.length; i++) {
        if (!set.has(actions[i])) return false;
    }
    return true;
}

/**
 * Проверить, выполняет ли игрок ХОТЯ БЫ ОДНО из указанных действий.
 * @param {import("@minecraft/server").Player} player
 * @param {...string} actions
 * @returns {boolean}
 */
export function hasAnyAction(player, ...actions) {
    const set = _actions.get(player.id);
    if (!set) return false;
    for (let i = 0; i < actions.length; i++) {
        if (set.has(actions[i])) return true;
    }
    return false;
}

// Пустой Set-заглушка (чтобы не создавать каждый раз новый)
const _emptySet = Object.freeze(new Set());

// ── Очистка при выходе игрока ──
world.afterEvents.playerLeave.subscribe((e) => {
    _prevLoc.delete(e.playerId);
    _actions.delete(e.playerId);
});
