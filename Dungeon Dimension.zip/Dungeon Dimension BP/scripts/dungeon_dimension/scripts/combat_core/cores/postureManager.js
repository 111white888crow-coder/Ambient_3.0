// ═══════════════════════════════════════════════════════════
// postureManager.js — Стойкость (Posture/Poise)
// Блок тратит стойкость → при 0 — guard break
// Стойкость регенерится когда блок снят + задержка
// ═══════════════════════════════════════════════════════════

import { world, EquipmentSlot } from "@minecraft/server";
import { POSTURE_CONFIG } from "./utils/constants.js";
import { nowTick } from "./utils/time.js";
import { tryOr } from "./utils/safe.js";

const _map = new Map();
const _MAX_RECALC_INTERVAL = 20; // перерасчёт макс. стойкости каждые 20 тиков

world.afterEvents.playerLeave.subscribe((ev) => {
    const pid = ev?.playerId;
    if (pid) _map.delete(pid);
});

/**
 * Рассчитать максимальную стойкость с учётом брони.
 */
function _calcMax(player) {
    const base = Number(POSTURE_CONFIG.BASE ?? 20);
    const armorBonus = Number(POSTURE_CONFIG.ARMOR_BONUS ?? 0);
    const netherBonus = Number(POSTURE_CONFIG.NETHERITE_BONUS ?? 0);

    let pieces = 0;
    let netheritePieces = 0;

    const eq = tryOr(() => player.getComponent("minecraft:equippable"), undefined);
    if (eq) {
        const slots = [EquipmentSlot.Head, EquipmentSlot.Chest, EquipmentSlot.Legs, EquipmentSlot.Feet];
        for (const slot of slots) {
            const it = tryOr(() => eq.getEquipment(slot), undefined);
            if (!it) continue;
            pieces++;

            const id = String(tryOr(() => it.typeId, ""));
            if (id.includes("netherite")) netheritePieces++;
        }
    }

    return base + (pieces * armorBonus) + (netheritePieces * netherBonus);
}

function _getOrCreate(player) {
    let st = _map.get(player.id);
    if (!st) {
        const tick = nowTick();
        const max = _calcMax(player);
        st = {
            value: max,
            max,
            lastDamageTick: tick,
            lastMaxUpdateTick: tick,
            brokenUntilTick: 0,
        };
        _map.set(player.id, st);
    }
    return st;
}

function _recalcIfNeeded(player, st, tick) {
    if ((tick - (st.lastMaxUpdateTick ?? 0)) < _MAX_RECALC_INTERVAL) return;
    st.lastMaxUpdateTick = tick;

    const max = _calcMax(player);
    st.max = max;
    st.value = Math.min(max, Math.max(0, Number(st.value ?? max)));
}

export const PostureManager = Object.freeze({

    /** Получить текущее состояние стойкости */
    getState(player) {
        const st = _getOrCreate(player);
        _recalcIfNeeded(player, st, nowTick());
        return st;
    },

    /** Может ли игрок блокировать (стойкость > 0, не в guard break) */
    canBlock(player) {
        if (!player || !tryOr(() => player.isValid, false)) return false;
        const tick = nowTick();
        const st = _getOrCreate(player);
        _recalcIfNeeded(player, st, tick);

        if (tick < Number(st.brokenUntilTick ?? 0)) return false;
        return Number(st.value ?? 0) > 0;
    },

    /** Потратить стойкость. При <= 0 → guard break */
    consume(player, amount) {
        const tick = nowTick();
        const st = _getOrCreate(player);
        _recalcIfNeeded(player, st, tick);

        const cost = Math.max(0, Number(amount ?? 0));
        const cur = Math.max(0, Number(st.value ?? 0));
        const next = Math.max(0, cur - cost);

        st.value = next;
        st.lastDamageTick = tick;

        if (next <= 0) {
            const cd = Number(POSTURE_CONFIG.GUARD_BREAK_COOLDOWN_TICKS ?? 20);
            st.brokenUntilTick = tick + Math.max(0, Math.floor(cd));
        }

        return st.value;
    },

    /** Тик — регенерация стойкости (если не блокирует и прошла задержка) */
    tickPlayer(player, isBlocking) {
        if (!player || !tryOr(() => player.isValid, false)) return;

        const tick = nowTick();
        const st = _getOrCreate(player);
        _recalcIfNeeded(player, st, tick);

        // Не регенерим во время блока
        if (isBlocking) return;
        // Не регенерим в guard break
        if (tick < Number(st.brokenUntilTick ?? 0)) return;

        // Задержка после последнего получения урона
        const delay = Number(POSTURE_CONFIG.REGEN_DELAY ?? 20);
        if ((tick - Number(st.lastDamageTick ?? 0)) < delay) return;

        const rate = Number(POSTURE_CONFIG.REGEN_RATE ?? 1);
        if (rate <= 0) return;

        st.value = Math.min(st.max, Number(st.value ?? 0) + rate);
    },

    /** Сбросить стойкость в макс. */
    reset(player) {
        if (!player) return;
        const tick = nowTick();
        const max = _calcMax(player);
        _map.set(player.id, {
            value: max,
            max,
            lastDamageTick: tick,
            lastMaxUpdateTick: tick,
            brokenUntilTick: 0,
        });
    },
});
