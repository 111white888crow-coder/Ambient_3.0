// ═══════════════════════════════════════════════════════════
// proxySystem.js — Target Proxy (прицельная сущность)
// Спавнит sag:target_proxy перед игроком
// Позиционирует по ближайшей цели или по взгляду
// ═══════════════════════════════════════════════════════════

import { world, system } from "@minecraft/server";
import { resolveWeaponForPlayer } from "./itemTagRules.js";
import { TargetingSystem } from "./utils/targetingSystem.js";

const PROXY_ID = "sag:target_proxy";
const DEFAULT_PROXY_DISTANCE = 3.0;
const ENTITY_OFFSET = 2.0;
const MIN_PROXY_DISTANCE = 0.15;
const ENTITY_DETECTION_RADIUS = 10.0;
const ENTITY_DETECTION_RADIUS_SQ = ENTITY_DETECTION_RADIUS * ENTITY_DETECTION_RADIUS;
const VIEW_CONE_COS = 0.4;

const PASSABLE_BLOCKS = new Set([
    "minecraft:air", "minecraft:cave_air", "minecraft:void_air",
    "minecraft:structure_void", "minecraft:light_block",
    "minecraft:water", "minecraft:flowing_water",
    "minecraft:lava", "minecraft:flowing_lava",
    "minecraft:fire", "minecraft:soul_fire"
]);

const playerProxies = new Map();

// ── Main loop ──
system.runInterval(() => {
    // Cleanup каждые 40 тиков
    if (system.currentTick % 40 === 0) cleanupInvalidProxies();

    for (const player of world.getAllPlayers()) {
        if (!player.isValid) continue;
        try {
            updateProxy(player);
        } catch (e) { }
    }
}, 1);

function cleanupInvalidProxies() {
    const currentPlayers = world.getAllPlayers();
    const currentPlayerIds = new Set(currentPlayers.map(p => p.id));

    for (const [playerId, data] of playerProxies) {
        if (!currentPlayerIds.has(playerId)) {
            removeProxyData(playerId, data);
            continue;
        }

        const player = currentPlayers.find(p => p.id === playerId);
        if (player && data.dimensionId !== player.dimension.id) {
            removeProxyData(playerId, data);
        } else if (data.proxy && !data.proxy.isValid) {
            data.proxy = undefined;
        } else if (data.target && !data.target.isValid) {
            data.target = undefined;
        }
    }
}

function removeProxyData(playerId, data) {
    if (data?.proxy?.isValid) {
        try { data.proxy.remove(); } catch (e) { }
    }
    playerProxies.delete(playerId);
}

function distSq(v1, v2) {
    return (v1.x - v2.x) ** 2 + (v1.y - v2.y) ** 2 + (v1.z - v2.z) ** 2;
}

function toBlockPos(loc) {
    return {
        x: Math.floor(loc.x),
        y: Math.floor(loc.y),
        z: Math.floor(loc.z)
    };
}

function getClosestPointOnHitbox(entity, fromPoint) {
    const pos = entity.location;
    const { height, width } = TargetingSystem.getCollisionBox(entity);
    const halfWidth = width / 2;

    return {
        x: Math.max(pos.x - halfWidth, Math.min(fromPoint.x, pos.x + halfWidth)),
        y: Math.max(pos.y, Math.min(fromPoint.y, pos.y + height)),
        z: Math.max(pos.z - halfWidth, Math.min(fromPoint.z, pos.z + halfWidth))
    };
}

function isInsideBlock(dimension, location) {
    try {
        const block = dimension.getBlock(toBlockPos(location));
        if (!block) return false;
        if (PASSABLE_BLOCKS.has(block.typeId)) return false;
        if (block.typeId.includes("banner")) return false;
        return true;
    } catch (e) {
        return false;
    }
}

function getFirstSolidBlockInView(player, maxDistance) {
    try {
        const hit = player.getBlockFromViewDirection({ maxDistance });
        if (!hit || !hit.block) return null;

        const block = hit.block;
        const typeId = block.typeId;

        if (PASSABLE_BLOCKS.has(typeId) || typeId.includes("banner")) {
            return null;
        }

        const head = player.getHeadLocation();
        const loc = block.location ?? block;

        if (typeof loc.x !== "number") {
            return { block, distance: maxDistance };
        }

        const cx = loc.x + 0.5;
        const cy = loc.y + 0.5;
        const cz = loc.z + 0.5;

        const dx = cx - head.x;
        const dy = cy - head.y;
        const dz = cz - head.z;
        const distance = Math.sqrt(dx * dx + dy * dy + dz * dz);

        return { block, distance };
    } catch (e) {
        return null;
    }
}

function findNearestTarget(player, currentData, solidBlockInfo) {
    const head = player.getHeadLocation();
    const viewDir = player.getViewDirection();
    const hasSolid = !!solidBlockInfo;
    const solidDist = solidBlockInfo?.distance ?? 0;

    // Проверить текущую цель (sticky target)
    if (currentData?.target?.isValid) {
        const target = currentData.target;

        if (target.dimension.id === player.dimension.id &&
            distSq(target.location, player.location) <= ENTITY_DETECTION_RADIUS_SQ) {

            const closestPoint = getClosestPointOnHitbox(target, head);
            const vx = closestPoint.x - head.x;
            const vy = closestPoint.y - head.y;
            const vz = closestPoint.z - head.z;

            const d2 = vx * vx + vy * vy + vz * vz;
            if (d2 > 0.0001) {
                const dist = Math.sqrt(d2);
                const forward = vx * viewDir.x + vy * viewDir.y + vz * viewDir.z;

                if (forward > 0 && dist <= ENTITY_DETECTION_RADIUS) {
                    const cos = forward / dist;

                    if (cos >= VIEW_CONE_COS) {
                        if (!hasSolid || forward < solidDist - 0.2) {
                            return { entity: target, closestPoint, distance: dist, forward };
                        }
                    }
                }
            }
        }

        currentData.target = undefined;
    }

    // Искать новую цель
    let entities;
    try {
        entities = player.dimension.getEntities({
            location: player.location,
            maxDistance: ENTITY_DETECTION_RADIUS,
        });
    } catch (e) {
        return null;
    }

    let nearest = null;
    let nearestForward = Infinity;

    for (const entity of entities) {
        if (!TargetingSystem.canAttack(player, entity)) continue;

        try {
            const closestPoint = getClosestPointOnHitbox(entity, head);
            const vx = closestPoint.x - head.x;
            const vy = closestPoint.y - head.y;
            const vz = closestPoint.z - head.z;

            const d2 = vx * vx + vy * vy + vz * vz;
            if (d2 > ENTITY_DETECTION_RADIUS_SQ) continue;

            const dist = Math.sqrt(d2);
            const forward = vx * viewDir.x + vy * viewDir.y + vz * viewDir.z;

            if (forward <= 0) continue;

            const cos = forward / dist;
            if (cos < VIEW_CONE_COS) continue;

            if (hasSolid && forward >= solidDist - 0.2) continue;

            if (forward < nearestForward) {
                nearestForward = forward;
                nearest = { entity, closestPoint, distance: dist, forward };
            }
        } catch (e) { }
    }

    return nearest;
}

function resolveProxyPosition(player, targetData, solidBlockInfo) {
    const head = player.getHeadLocation();
    const viewDir = player.getViewDirection();
    const hasSolid = !!solidBlockInfo;
    const solidDist = solidBlockInfo?.distance ?? 0;

    let desiredDist = DEFAULT_PROXY_DISTANCE;
    let distToMob = Infinity;

    if (targetData) {
        distToMob = targetData.distance;
        desiredDist = targetData.forward - ENTITY_OFFSET;
        if (desiredDist < MIN_PROXY_DISTANCE) desiredDist = MIN_PROXY_DISTANCE;
    }

    if (hasSolid && solidDist > 0) {
        const maxDist = solidDist - 0.2;
        if (desiredDist > maxDist) desiredDist = maxDist;
        if (desiredDist < MIN_PROXY_DISTANCE) desiredDist = MIN_PROXY_DISTANCE;
    }

    // Проверка обхода стен
    const step = 0.15;
    for (let d = desiredDist; d >= MIN_PROXY_DISTANCE; d -= step) {
        const pos = {
            x: head.x + viewDir.x * d,
            y: head.y + viewDir.y * d,
            z: head.z + viewDir.z * d
        };

        if (!isInsideBlock(player.dimension, pos)) {
            return { pos, distToMob };
        }
    }

    const fallback = {
        x: head.x + viewDir.x * MIN_PROXY_DISTANCE,
        y: head.y + viewDir.y * MIN_PROXY_DISTANCE,
        z: head.z + viewDir.z * MIN_PROXY_DISTANCE
    };
    return { pos: fallback, distToMob };
}

function updateProxy(player) {
    let data = playerProxies.get(player.id);
    if (!data) {
        data = { proxy: undefined, target: undefined, dimensionId: player.dimension.id };
        playerProxies.set(player.id, data);
    }

    if (data.proxy && !data.proxy.isValid) data.proxy = undefined;

    const resolved = resolveWeaponForPlayer(player);
    const isHolding = !!resolved.weapon;

    if (!isHolding) {
        if (data.proxy) removeProxyData(player.id, data);
        data.target = undefined;
        return;
    }

    const solidBlockInfo = getFirstSolidBlockInView(player, ENTITY_DETECTION_RADIUS);
    const targetSearchResult = findNearestTarget(player, data, solidBlockInfo);
    data.target = targetSearchResult?.entity;

    const { pos: targetPos } = resolveProxyPosition(player, targetSearchResult, solidBlockInfo);

    if (!data.proxy) {
        try {
            const existing = player.dimension.getEntities({
                type: PROXY_ID,
                location: targetPos,
                maxDistance: 2.0,
                closest: 1
            });
            if (existing.length > 0) {
                data.proxy = existing[0];
                data.dimensionId = player.dimension.id;
            }
        } catch (e) { }
    }

    if (data.proxy && data.proxy.isValid) {
        if (data.dimensionId !== player.dimension.id) {
            removeProxyData(player.id, data);
            spawnProxy(player, targetPos, data);
            return;
        }

        try {
            data.proxy.teleport(targetPos);
        } catch (e) {
            removeProxyData(player.id, data);
            spawnProxy(player, targetPos, data);
        }
        return;
    }

    spawnProxy(player, targetPos, data);
}

function spawnProxy(player, location, dataObject) {
    try {
        const proxy = player.dimension.spawnEntity(PROXY_ID, location);
        dataObject.proxy = proxy;
        dataObject.dimensionId = player.dimension.id;
    } catch (e) { }
}

// ── Cleanup events ──
world.afterEvents.playerLeave.subscribe((event) => {
    const data = playerProxies.get(event.playerId);
    if (data) removeProxyData(event.playerId, data);
});

world.afterEvents.playerDimensionChange.subscribe((event) => {
    const data = playerProxies.get(event.player.id);
    if (data) removeProxyData(event.player.id, data);
});
