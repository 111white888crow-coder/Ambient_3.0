// ═══════════════════════════════════════════════════════════
// math.js — Математические утилиты
// ═══════════════════════════════════════════════════════════

/** Ограничить значение в пределах [min, max] */
export function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
}

/** Горизонтальная скорость (sqrt(x² + z²)) */
export function horizontalMag(v) {
    if (!v) return 0;
    const x = v.x ?? 0;
    const z = v.z ?? 0;
    return Math.sqrt(x * x + z * z);
}

/** Линейная интерполяция */
export function lerp(a, b, t) {
    return a + (b - a) * clamp(t, 0, 1);
}

/** Ease-out quadratic */
export function easeOutQuad(t) {
    const x = clamp(t, 0, 1);
    return 1 - (1 - x) * (1 - x);
}

/** Нормализовать угол в градусах к [-180, 180] */
export function wrapDegrees(deg) {
    let x = deg;
    x = ((x + 180) % 360 + 360) % 360 - 180;
    return x;
}
