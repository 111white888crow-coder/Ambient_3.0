// ═══════════════════════════════════════════════════════════
// targetingSystem.js — Поиск целей, LOS, collision box
// ═══════════════════════════════════════════════════════════

import { tryOr } from "./safe.js";
import { normalize, distance3D } from "./damageMath.js";

// Сущности, которые нельзя атаковать
const NATIVE_EXCLUDE_TYPES = [
    "minecraft:item",
    "minecraft:xp_orb",
    "minecraft:arrow",
    "minecraft:fishing_hook",
    "minecraft:painting",
    "minecraft:item_frame",
    "minecraft:armor_stand",
    "sag:target_proxy",
    "minecraft:tnt",
    "minecraft:chest_minecart",
    "minecraft:hopper_minecart"
];

const NATIVE_EXCLUDE_FAMILIES = [
    "inanimate"
];

export const TargetingSystem = Object.freeze({

    /**
     * Можно ли атаковать цель.
     * Проверяет: не самого себя, не маунт, HP > 0.
     */
    canAttack(player, entity) {
        if (!entity || !entity.isValid) return false;
        if (entity === player) return false;
        if (entity.id === player.id) return false;

        // Не атакуем то, на чём сидим
        const riding = tryOr(() => player.getComponent("riding")?.entityRidingOn, undefined);
        if (riding && entity === riding) return false;

        // Проверяем HP
        const health = tryOr(() => entity.getComponent("health"), undefined);
        if (health) {
            const currentValue = tryOr(() => health.currentValue, 0);
            if (currentValue <= 0) return false;
        }

        return true;
    },

    /**
     * Найти цель по прицелу (crosshair).
     * Использует getEntitiesFromViewDirection.
     */
    getCrosshairTarget(player, maxDistance) {
        const hits = tryOr(
            () => player.getEntitiesFromViewDirection({
                maxDistance: maxDistance,
                excludeTypes: NATIVE_EXCLUDE_TYPES,
                excludeFamilies: NATIVE_EXCLUDE_FAMILIES
            }),
            []
        );

        if (hits.length === 0) return null;

        for (const hit of hits) {
            if (this.canAttack(player, hit.entity)) {
                return hit.entity;
            }
        }

        return null;
    },

    /**
     * Получить все сущности в радиусе.
     */
    getEntitiesInRadius(player, radius) {
        const origin = tryOr(() => player.location, { x: 0, y: 0, z: 0 });
        return tryOr(
            () => player.dimension.getEntities({
                location: origin,
                maxDistance: radius,
                excludeTypes: NATIVE_EXCLUDE_TYPES,
                excludeFamilies: NATIVE_EXCLUDE_FAMILIES
            }),
            []
        );
    },

    /**
     * Проверить прямую видимость (ray от головы до центра цели).
     * Если расстояние < 2.5 — считаем что видно.
     */
    hasLineOfSight(player, target) {
        try {
            const start = player.getHeadLocation();
            const targetLoc = target.location;

            const rawDist = distance3D(start, targetLoc);
            if (rawDist < 2.5) return true;

            const end = {
                x: targetLoc.x,
                y: targetLoc.y + 0.8,
                z: targetLoc.z
            };

            const vector = {
                x: end.x - start.x,
                y: end.y - start.y,
                z: end.z - start.z
            };
            const direction = normalize(vector);

            if (direction.x === 0 && direction.y === 0 && direction.z === 0) {
                return true;
            }

            const hit = player.dimension.getBlockFromRay(start, direction, {
                maxDistance: rawDist,
                includeLiquidBlocks: false,
                includePassableBlocks: false
            });

            return !hit;
        } catch {
            return true;
        }
    },

    /**
     * Фильтр: только атакуемые сущности (+ опционально LOS).
     */
    filterAttackable(player, entities, checkSight = true) {
        const result = [];
        for (const entity of entities) {
            if (!this.canAttack(player, entity)) continue;
            if (checkSight && !this.hasLineOfSight(player, entity)) continue;
            result.push(entity);
        }
        return result;
    },

    /**
     * Получить collision box сущности.
     */
    getCollisionBox(entity) {
        let height = 1.8;
        let width = 0.6;

        try {
            const cb = entity.getComponent("minecraft:collision_box");
            if (cb) {
                if (typeof cb.height === "number" && cb.height > 0) height = cb.height;
                if (typeof cb.width === "number" && cb.width > 0) width = cb.width;
            }
        } catch { }

        return { height, width };
    }
});
