// ═══════════════════════════════════════════════════════════
// safe.js — Безопасные обёртки try/catch
// ═══════════════════════════════════════════════════════════

export const DEBUG_MODE = true;

/**
 * Выполнить функцию и вернуть результат.
 * При ошибке — fallback (или выбросить если DEBUG_MODE).
 */
export function tryOr(fn, fallback) {
    if (DEBUG_MODE) {
        return fn();
    }
    try {
        return fn();
    } catch (e) {
        return fallback;
    }
}

/**
 * Выполнить функцию без возврата результата.
 * При ошибке — тихо проглотить.
 */
export function tryRun(fn) {
    if (DEBUG_MODE) {
        fn();
        return;
    }
    try {
        fn();
    } catch { }
}

/**
 * Async-вариант tryOr.
 */
export async function tryOrAsync(fn, fallback) {
    if (DEBUG_MODE) {
        return await fn();
    }
    try {
        return await fn();
    } catch {
        return fallback;
    }
}
