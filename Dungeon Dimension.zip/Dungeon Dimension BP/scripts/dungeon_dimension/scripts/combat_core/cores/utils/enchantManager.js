// ═══════════════════════════════════════════════════════════
// enchantManager.js — Бонусы урона от зачарований
// ═══════════════════════════════════════════════════════════

import { EquipmentSlot } from "@minecraft/server";
import { tryOr } from "./safe.js";

const _customEnchants = new Map();

const CONFIG = {
    SHARPNESS_PER_LEVEL: 1.25,
    SMITE_PER_LEVEL: 2.5,
    BANE_PER_LEVEL: 2.5,
};

function _getEnchantBonusFromItem(item, target) {
    if (!item) return 0;

    let bonus = 0;

    const enchantable = tryOr(() => item.getComponent("minecraft:enchantable"), undefined);
    if (!enchantable) return 0;

    // Острота (Sharpness) — бонус ко всем
    const sharp = tryOr(() => enchantable.getEnchantment("sharpness"), undefined);
    if (sharp) {
        bonus += sharp.level * CONFIG.SHARPNESS_PER_LEVEL;
    }

    // Бич нежити (Smite) — бонус vs undead
    const smite = tryOr(() => enchantable.getEnchantment("smite"), undefined);
    if (smite && _isUndead(target)) {
        bonus += smite.level * CONFIG.SMITE_PER_LEVEL;
    }

    // Гибель членистоногих (Bane of Arthropods)
    const bane = tryOr(() => enchantable.getEnchantment("bane_of_arthropods"), undefined);
    if (bane && _isArthropod(target)) {
        bonus += bane.level * CONFIG.BANE_PER_LEVEL;
    }

    return bonus;
}

export const EnchantManager = Object.freeze({
    /**
     * Зарегистрировать кастомный бонус зачарования.
     * calcFn(player, target, slot) → number
     */
    registerCustom(id, calcFn) {
        _customEnchants.set(id, calcFn);
    },

    /** Бонус от зачарований в указанном слоте */
    getDamageBonusForSlot(player, target, slot = EquipmentSlot.Mainhand) {
        let bonus = 0;
        if (!player || !target) return 0;

        const equippable = tryOr(() => player.getComponent("minecraft:equippable"), undefined);
        if (!equippable) return 0;

        const item = tryOr(() => equippable.getEquipment(slot), undefined);
        if (!item) return 0;

        bonus += _getEnchantBonusFromItem(item, target);

        // Кастомные зачарования
        for (const calc of _customEnchants.values()) {
            try {
                bonus += calc(player, target, slot);
            } catch { }
        }

        return bonus;
    },

    /** Бонус от зачарований на конкретном ItemStack */
    getDamageBonusFromItemStack(itemStack, target) {
        if (!itemStack || !target) return 0;
        return _getEnchantBonusFromItem(itemStack, target);
    },

    /** Удобный шорткат: бонус основная рука */
    getDamageBonus(player, target) {
        return this.getDamageBonusForSlot(player, target, EquipmentSlot.Mainhand);
    }
});

// ── Определение типов мобов ──

function _isUndead(entity) {
    const typeId = tryOr(() => entity.typeId, "");
    if (typeId.includes("zombie") || typeId.includes("skeleton") ||
        typeId.includes("phantom") || typeId.includes("wither") ||
        typeId.includes("drowned") || typeId.includes("husk") ||
        typeId.includes("stray") || typeId.includes("zoglin")) {
        return true;
    }

    const families = tryOr(() => {
        const comp = entity.getComponent("minecraft:type_family");
        return comp?.getTypeFamilies?.() ?? [];
    }, []);

    return families.some(f => f === "undead" || f === "zombie" || f === "skeleton" || f === "phantom");
}

function _isArthropod(entity) {
    const typeId = tryOr(() => entity.typeId, "");
    if (typeId.includes("spider") || typeId.includes("silverfish") ||
        typeId.includes("endermite") || typeId.includes("bee")) {
        return true;
    }

    const families = tryOr(() => {
        const comp = entity.getComponent("minecraft:type_family");
        return comp?.getTypeFamilies?.() ?? [];
    }, []);

    return families.some(f => f === "arthropod" || f === "spider" || f === "insect" || f === "bee");
}
