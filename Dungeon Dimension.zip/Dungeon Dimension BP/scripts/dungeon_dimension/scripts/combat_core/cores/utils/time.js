// ═══════════════════════════════════════════════════════════
// time.js — Утилиты времени (тики ↔ секунды)
// ═══════════════════════════════════════════════════════════

import { system } from "@minecraft/server";
import { TICKS_PER_SECOND } from "./constants.js";

/** Текущий серверный тик */
export function nowTick() {
    return system.currentTick;
}

/** Секунды → тики (округлённо) */
export function secondsToTicks(seconds) {
    return Math.max(0, Math.round(seconds * TICKS_PER_SECOND));
}

/** Тики → секунды */
export function ticksToSeconds(ticks) {
    return ticks / TICKS_PER_SECOND;
}

/** Проверка — прошло ли durationTicks с startTick */
export function hasTimedOut(startTick, durationTicks) {
    return nowTick() >= startTick + durationTicks;
}
