// ═══════════════════════════════════════════════════════════
// constants.js — Все константы и конфигурации боевой системы
// ═══════════════════════════════════════════════════════════

// ── Тип руки (в какой руке оружие) ──
export const HandType = Object.freeze({
    RIGHT: "RIGHT",
    LEFT: "LEFT",
    BOTH: "BOTH",
    NONE: "NONE",
});

// ── Стиль руки (влияет на анимацию) ──
export const HandStyle = Object.freeze({
    RIGHT: "RIGHT",           // одноручное, основная рука
    LEFT: "LEFT",             // одноручное, левая рука
    BOTH: "BOTH",             // двуручное (dual wield)
    SHIELD_RIGHT: "SHIELD_RIGHT", // меч main + щит off
    SHIELD_LEFT: "SHIELD_LEFT",   // меч off + щит main
    NONE: "NONE",
});

// ── Тег способа держания оружия ──
export const WeaponHandTag = Object.freeze({
    ANY_HAND: "sag:any_hand",       // можно в любой руке
    LONGSWORD: "sag:longsword",     // тег longsword (любая рука)
    DOUBLE_HAND: "double_hand",     // двуручное
    MAIN_HAND: "main_hand",         // только в основной
    ONLY_ONE_HAND: "only_one_hand", // одна рука должна быть свободна
});

// ── Анимационный контроллер ──
export const COMBAT_ANIM_CONTROLLER = "controller.sag.combat";

// ── Время ──
export const TICKS_PER_SECOND = 20;
export const COMBAT_MODE_HOLD_TICKS = 120 * TICKS_PER_SECOND; // 2 мин

// ── Entity Properties ──
export const PLAYER_PROP_COMBAT_MODE = "sag:combat_mode";
export const PLAYER_PROP_IS_ATTACKING = "sag:is_attacking";
export const PLAYER_PROP_IS_BLOCKING = "sag:is_blocking";

// ── Пороги и лимиты ──
export const MOVE_CANCEL_THRESHOLD = 0.02; // мин. скорость для cancel-to-reset
export const MAX_COMBO_CHAIN_HARD_LIMIT = 16;

// ── Pre-combo lock (slowness при замахе) ──
export const PRECOMBO_LOCK_EFFECT_ID = "slowness";
export const PRECOMBO_LOCK_AMPLIFIER = 255;
export const PRECOMBO_LOCK_SHOW_PARTICLES = false;

// ── FOV Lock ──
export const FOV_LOCK_DEGREES = 82;

// ── Теги игрока ──
export const PLAYER_TAGS = Object.freeze({
    BLOCKING: "sag:blocking",
    JUMP_ATTACK_LANDING: "sag:jump_attack_landing",
    EVADING: "sag:evading",
    ATTACK_LEFT: "sag:attack_left",
    ATTACK_RIGHT: "sag:attack",
    PARRY_WINDOW: "sag:parry_window",
});

// ── Конфигурация блока (block) ──
export const BLOCKING_CONFIG = Object.freeze({
    TAG: "sag:blocking",
    EFFECT_AMPLIFIER: 2,       // slowness при удержании блока
    DEFAULT_ANGLE: 90,         // угол блокирования (градусы)
    PARRY_WINDOW_TICKS: 8,    // тики парирующего окна с начала блока
});

// ── Конфигурация стойкости (posture/poise) ──
export const POSTURE_CONFIG = Object.freeze({
    BASE: 20,                          // базовая стойкость
    ARMOR_BONUS: 5,                    // бонус за каждый слот брони
    NETHERITE_BONUS: 0,                // доп. бонус за незерит
    REGEN_DELAY: 20,                   // тиков задержки перед регеном
    REGEN_RATE: 1,                     // стойкости за тик
    GUARD_BREAK_COOLDOWN_TICKS: 40,    // КД при пробитии стойкости
    COST_SHIELD: 2,                    // стоимость при щите
    COST_SWORD: 4,                     // стоимость при мече
});

// ── Dual wield конфиг ──
export const DUAL_WIELD_CONFIG = Object.freeze({
    OFFHAND_DAMAGE_MULTIPLIER: 1.0,
    COMBO_DELAY_TICKS: 2,
    ALLOW_SIMULTANEOUS: false,
});

// ── Щиты ──
export const SHIELD_IDS = Object.freeze([
    "minecraft:shield",
]);

// ── Конфигурации типов атак (hitbox чертежи по умолчанию) ──
export const ATTACK_TYPE_CONFIG = Object.freeze({
    thrust: {
        radius: 3.0,
        angle: 45,
        height: 2.0,
        forward: 3.0,
        side: 1.0,
        sweepMultiplier: 0.8
    },
    slash_right: {
        radius: 3.5,
        angle: 120,
        height: 2.0,
        sweepMultiplier: 1.0
    },
    slash_left: {
        radius: 3.5,
        angle: 120,
        height: 2.0,
        sweepMultiplier: 1.0
    },
    slash_sector: {
        radius: 3.0,
        angle: 120,
        height: 2.0,
        sweepMultiplier: 1.0
    },
    fall_thrust: {
        radius: 0.5,
        height: 3.0,
        sweepMultiplier: 1.0
    },
    aoe_spin: {
        radius: 3.0,
        angle: 360,
        height: 2.0,
        rotations: 2,
        sweepMultiplier: 1.0
    }
});
