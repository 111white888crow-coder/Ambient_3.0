// ═══════════════════════════════════════════════════════════
// damageMath.js — Геометрия/математика для системы урона
// ═══════════════════════════════════════════════════════════

/** Нормализовать вектор {x,y,z} */
export function normalize(vec) {
    const y = vec.y ?? 0;
    const mag = Math.sqrt(vec.x * vec.x + y * y + vec.z * vec.z);
    if (mag === 0) return { x: 0, y: 0, z: 0 };
    return { x: vec.x / mag, y: y / mag, z: vec.z / mag };
}

/** 3D дистанция между точками */
export function distance3D(a, b) {
    const dx = a.x - b.x;
    const dy = a.y - b.y;
    const dz = a.z - b.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

/** Горизонтальная дистанция (без Y) */
export function distanceHorizontal(a, b) {
    const dx = a.x - b.x;
    const dz = a.z - b.z;
    return Math.sqrt(dx * dx + dz * dz);
}

/**
 * Проверить, находится ли target в переднем секторе игрока.
 * @param {Player} player
 * @param {Entity} target
 * @param {number} halfAngle — половина угла сектора (градусы)
 */
export function isInFrontSector(player, target, halfAngle) {
    try {
        const viewDir = player.getViewDirection();
        const playerLoc = player.location;
        const targetLoc = target.location;

        const toTarget = {
            x: targetLoc.x - playerLoc.x,
            z: targetLoc.z - playerLoc.z
        };
        const toTargetMag = Math.sqrt(toTarget.x * toTarget.x + toTarget.z * toTarget.z);

        if (toTargetMag < 0.01) return true;

        const toTargetNorm = {
            x: toTarget.x / toTargetMag,
            z: toTarget.z / toTargetMag
        };

        const viewMag = Math.sqrt(viewDir.x * viewDir.x + viewDir.z * viewDir.z);
        if (viewMag < 0.01) return true;

        const viewNorm = {
            x: viewDir.x / viewMag,
            z: viewDir.z / viewMag
        };

        const dot = viewNorm.x * toTargetNorm.x + viewNorm.z * toTargetNorm.z;
        const angleRad = Math.acos(Math.max(-1, Math.min(1, dot)));
        const angleDeg = angleRad * (180 / Math.PI);

        return angleDeg <= halfAngle;
    } catch {
        return false;
    }
}

/**
 * Получить угол от игрока к цели (относительно yaw, радианы 0..2π).
 * Используется для circular/spin атак.
 */
export function getAngleToTarget(player, target) {
    try {
        const playerLoc = player.location;
        const targetLoc = target.location;
        const rotation = player.getRotation();

        const dx = targetLoc.x - playerLoc.x;
        const dz = targetLoc.z - playerLoc.z;

        let angleToTarget = Math.atan2(-dx, dz);
        const playerYaw = rotation.y * (Math.PI / 180);

        let relativeAngle = angleToTarget - playerYaw;

        while (relativeAngle < 0) relativeAngle += Math.PI * 2;
        while (relativeAngle >= Math.PI * 2) relativeAngle -= Math.PI * 2;

        return relativeAngle;
    } catch {
        return 0;
    }
}

/**
 * Проверить, находится ли точка в forward-box относительно игрока.
 */
export function isInForwardBox(player, point, forward, side, height) {
    try {
        const playerLoc = player.location;
        const rotation = player.getRotation();
        const yawRad = rotation.y * (Math.PI / 180);

        const dx = point.x - playerLoc.x;
        const dy = point.y - playerLoc.y;
        const dz = point.z - playerLoc.z;

        const cos = Math.cos(yawRad);
        const sin = Math.sin(yawRad);

        const localX = dx * cos + dz * sin;
        const localZ = dx * (-sin) + dz * cos;

        if (localZ < 0 || localZ > forward) return false;
        if (Math.abs(localX) > side / 2) return false;
        if (dy < 0 || dy > height) return false;

        return true;
    } catch {
        return false;
    }
}

/** Ограничить значение в пределах [min, max] */
export function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
}
