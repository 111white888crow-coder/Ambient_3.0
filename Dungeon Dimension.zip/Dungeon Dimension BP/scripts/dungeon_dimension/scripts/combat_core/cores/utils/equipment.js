// ═══════════════════════════════════════════════════════════
// equipment.js — Доступ к экипировке игрока
// ═══════════════════════════════════════════════════════════

import { EquipmentSlot } from "@minecraft/server";
import { tryOr } from "./safe.js";

function getEquippable(player) {
    return tryOr(() => player.getComponent("minecraft:equippable"), undefined);
}

/** Получить предмет в основной руке */
export function getMainhandItem(player) {
    const eq = getEquippable(player);
    return tryOr(() => eq?.getEquipment(EquipmentSlot.Mainhand) ?? undefined, undefined);
}

/** Получить предмет в левой руке */
export function getOffhandItem(player) {
    const eq = getEquippable(player);
    return tryOr(() => eq?.getEquipment(EquipmentSlot.Offhand) ?? undefined, undefined);
}

/** Получить typeId предмета */
export function getItemId(item) {
    return tryOr(() => item?.typeId, undefined);
}

/** Держит ли игрок предмет с данным id в основной руке */
export function isHoldingItem(player, itemId) {
    const mainItem = getMainhandItem(player);
    return getItemId(mainItem) === itemId;
}

/** Держит ли игрок предмет с данным id в левой руке */
export function isHoldingItemOffhand(player, itemId) {
    const offItem = getOffhandItem(player);
    return getItemId(offItem) === itemId;
}

/** Получить предмет из слота брони */
export function getArmorSlot(player, slot) {
    const eq = getEquippable(player);
    return tryOr(() => eq?.getEquipment(slot) ?? undefined, undefined);
}
