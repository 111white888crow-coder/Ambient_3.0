// ═══════════════════════════════════════════════════════════
// effectManager.js — Бонусы/штрафы урона от эффектов
// ═══════════════════════════════════════════════════════════

import { tryOr } from "./safe.js";

const CONFIG = {
    STRENGTH_BONUS_PER_TIER: 3.0,
    WEAKNESS_REDUCTION_PER_TIER: 4.0,
};

export const EffectManager = Object.freeze({
    /**
     * Вычислить бонус/штраф урона от Strength/Weakness.
     * @returns {number} — может быть отрицательным
     */
    getDamageBonus(player) {
        let bonus = 0;
        if (!player) return 0;

        // Сила (Strength) — бонус урона
        const strength = tryOr(() => player.getEffect("strength"), undefined);
        if (strength) {
            bonus += (strength.amplifier + 1) * CONFIG.STRENGTH_BONUS_PER_TIER;
        }

        // Слабость (Weakness) — штраф урона
        // Не считаем amplifier=255 (это наш pre-combo lock)
        const weakness = tryOr(() => player.getEffect("weakness"), undefined);
        if (weakness && weakness.amplifier < 255) {
            bonus -= (weakness.amplifier + 1) * CONFIG.WEAKNESS_REDUCTION_PER_TIER;
        }

        return bonus;
    }
});
