// ═══════════════════════════════════════════════════════════
// effectRegistry.js — Умный менеджер эффектов
// Сохраняет/восстанавливает существующие эффекты при
// перезаписи боевыми эффектами (slowness и т.д.)
// ═══════════════════════════════════════════════════════════

import { world } from "@minecraft/server";
import { nowTick } from "./utils/time.js";
import { tryOr } from "./utils/safe.js";

function normalizeEffectId(effectId) {
    if (!effectId) return effectId;
    return effectId.startsWith("minecraft:")
        ? effectId.substring("minecraft:".length)
        : effectId;
}

const _perPlayer = new Map();

function _getOrCreatePlayerMap(playerId) {
    let m = _perPlayer.get(playerId);
    if (!m) {
        m = new Map();
        _perPlayer.set(playerId, m);
    }
    return m;
}

function _getOrCreateState(playerId, effectId) {
    const eid = normalizeEffectId(effectId);
    const m = _getOrCreatePlayerMap(playerId);
    let st = m.get(eid);
    if (!st) {
        st = {
            active: false,
            scriptStartTick: 0,
            scriptEndTick: 0,
            suppressNextAddEvent: false,
            restoreCandidate: null,
        };
        m.set(eid, st);
    }
    return st;
}

function _updateRestoreCandidate(st, snap) {
    const cur = st.restoreCandidate;
    if (!cur) {
        st.restoreCandidate = snap;
        return;
    }
    if (snap.amplifier > cur.amplifier) {
        st.restoreCandidate = snap;
        return;
    }
    if (snap.amplifier === cur.amplifier && snap.durationTicks > cur.durationTicks) {
        st.restoreCandidate = snap;
    }
}

function _addEffect(player, effectId, durationTicks, amplifier, showParticles) {
    const eid = normalizeEffectId(effectId);
    const dur = Math.max(0, Math.floor(durationTicks));
    if (dur <= 0) return;

    tryOr(() => player.addEffect(eid, dur, { amplifier, showParticles }), undefined);
}

function _removeEffect(player, effectId) {
    const eid = normalizeEffectId(effectId);
    tryOr(() => player.removeEffect(eid), false);
}

export const EffectRegistry = {
    _initialized: false,

    init() {
        if (EffectRegistry._initialized) return;
        EffectRegistry._initialized = true;

        // Перехватываем добавление эффектов чтобы сохранить «оригиналы»
        world.afterEvents.effectAdd.subscribe(
            (ev) => {
                const entity = ev?.entity;
                const effect = ev?.effect;

                if (!entity || !effect) return;

                try {
                    if (!entity.isValid) return;
                    if (entity.typeId !== "minecraft:player") return;

                    const pid = entity.id;
                    const eid = normalizeEffectId(effect.typeId);

                    const pm = _perPlayer.get(pid);
                    if (!pm) return;

                    const st = pm.get(eid);
                    if (!st || !st.active) return;

                    if (st.suppressNextAddEvent) {
                        st.suppressNextAddEvent = false;
                        return;
                    }

                    const snap = {
                        amplifier: tryOr(() => effect.amplifier, 0),
                        durationTicks: tryOr(() => effect.duration, 0),
                        capturedTick: nowTick(),
                    };
                    _updateRestoreCandidate(st, snap);
                } catch (e) { }
            },
            { entityTypes: ["minecraft:player"] }
        );

        world.afterEvents.playerLeave.subscribe((ev) => {
            const pid = ev?.playerId;
            if (!pid) return;
            _perPlayer.delete(pid);
        });
    },

    /**
     * Применить эффект до определённого тика.
     * Сохраняет существующий эффект для восстановления.
     */
    applyUntil(player, effectId, untilTick, options) {
        if (!player) return;
        const eid = normalizeEffectId(effectId);
        const tick = nowTick();
        const endTick = Math.max(tick, Math.floor(untilTick));
        const duration = endTick - tick;
        if (duration <= 0) return;

        const st = _getOrCreateState(player.id, eid);

        if (!st.active) {
            // Сохранить текущий эффект если есть
            const existing = tryOr(() => player.getEffect(eid), undefined);
            if (existing && tryOr(() => existing.isValid, true)) {
                _updateRestoreCandidate(st, {
                    amplifier: tryOr(() => existing.amplifier, 0),
                    durationTicks: tryOr(() => existing.duration, 0),
                    capturedTick: tick,
                });
            }

            st.active = true;
            st.scriptStartTick = tick;
            st.scriptEndTick = endTick;
        } else {
            st.scriptEndTick = Math.max(st.scriptEndTick, endTick);
        }

        st.suppressNextAddEvent = true;
        _addEffect(
            player,
            eid,
            st.scriptEndTick - tick,
            options?.amplifier ?? 0,
            options?.showParticles ?? true
        );
    },

    /**
     * Снять боевой эффект и восстановить сохранённый.
     */
    end(player, effectId) {
        if (!player) return;
        const eid = normalizeEffectId(effectId);
        const stMap = _perPlayer.get(player.id);
        if (!stMap) return;

        const st = stMap.get(eid);
        if (!st || !st.active) return;

        const tick = nowTick();

        _removeEffect(player, eid);

        st.active = false;
        st.scriptStartTick = 0;
        st.scriptEndTick = 0;
        st.suppressNextAddEvent = false;

        // Восстановить оригинал
        const snap = st.restoreCandidate;
        st.restoreCandidate = null;

        if (snap) {
            const elapsed = Math.max(0, tick - snap.capturedTick);
            const remaining = Math.max(0, Math.floor(snap.durationTicks - elapsed));
            if (remaining > 0) {
                _addEffect(player, eid, remaining, snap.amplifier, true);
            }
        }
    },

    /**
     * Тик-обновление — снимаем истёкшие эффекты.
     */
    tickPlayer(player) {
        if (!player) return;
        const pid = player.id;
        const pm = _perPlayer.get(pid);
        if (!pm) return;

        const tick = nowTick();

        for (const [eid, st] of pm.entries()) {
            if (!st.active) continue;
            if (tick >= st.scriptEndTick) {
                EffectRegistry.end(player, eid);
            }
        }
    },
};
