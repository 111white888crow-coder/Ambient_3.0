// ═══════════════════════════════════════════════════════════
// itemTagRules.js — Определение оружия и стиля из инвентаря
// ═══════════════════════════════════════════════════════════

import { HandType, HandStyle, WeaponHandTag } from "./utils/constants.js";
import { getItemId, getMainhandItem, getOffhandItem } from "./utils/equipment.js";
import { WeaponRegistry } from "./weaponRegistry.js";
import { tryOr } from "./utils/safe.js";

function isShieldStack(itemStack) {
    if (!itemStack) return false;
    if (itemStack.typeId === "minecraft:shield") return true;

    const tags = tryOr(() => itemStack.getTags(), []);
    if (tags && tags.includes("sag:is_shield")) return true;

    return false;
}

/**
 * Определить, какое оружие в руках у игрока, стиль, и можно ли атаковать.
 * @returns {{ weapon, handType, handStyle, isAttackAllowed, denyReason, ... }}
 */
export function resolveWeaponForPlayer(player) {
    const mainItem = getMainhandItem(player);
    const offItem = getOffhandItem(player);

    const mainItemId = getItemId(mainItem);
    const offItemId = getItemId(offItem);

    const mainWeapon = WeaponRegistry.get(mainItemId);
    const offWeapon = WeaponRegistry.get(offItemId);

    const hasShieldMain = isShieldStack(mainItem);
    const hasShieldOff = isShieldStack(offItem);

    const weapon = mainWeapon ?? offWeapon;

    if (!weapon) {
        return {
            weapon: undefined,
            handType: HandType.NONE,
            handStyle: HandStyle.NONE,
            mainItemId,
            offItemId,
            mainWeapon,
            offWeapon,
            hasShieldMain,
            hasShieldOff,
            isAttackAllowed: false,
            denyReason: "no_weapon",
        };
    }

    const canUseBothStyle = mainWeapon && offWeapon && shareWeaponTypeTag(mainWeapon, offWeapon);

    let handType = HandType.NONE;
    let handStyle = HandStyle.NONE;

    const hasWeaponMain = !!mainWeapon;
    const hasWeaponOff = !!offWeapon;

    if (canUseBothStyle) {
        handType = HandType.BOTH;
        handStyle = HandStyle.BOTH;
    } else if (hasWeaponMain) {
        handType = HandType.RIGHT;
        handStyle = hasShieldOff ? HandStyle.SHIELD_RIGHT : HandStyle.RIGHT;
    } else if (hasWeaponOff) {
        handType = HandType.LEFT;
        handStyle = hasShieldMain ? HandStyle.SHIELD_LEFT : HandStyle.LEFT;
    }

    if (handType === HandType.BOTH && !canUseBothStyle) {
        handType = HandType.RIGHT;
        handStyle = hasShieldOff ? HandStyle.SHIELD_RIGHT : HandStyle.RIGHT;
    }

    // Проверка WeaponHandTag
    const handTag = weapon.tag;
    let isAttackAllowed = true;
    let denyReason = undefined;

    if (handTag === WeaponHandTag.MAIN_HAND) {
        if (handType !== HandType.RIGHT) {
            isAttackAllowed = false;
            denyReason = "main_hand_required";
        }
    } else if (handTag === WeaponHandTag.ONLY_ONE_HAND) {
        const mainOccupied = !!mainItemId;
        const offOccupied = !!offItemId;

        if (hasWeaponMain && hasWeaponOff) {
            isAttackAllowed = false;
            denyReason = "only_one_hand_violation_both";
        } else if (handType === HandType.RIGHT) {
            if (offOccupied && !hasShieldOff) {
                isAttackAllowed = false;
                denyReason = "only_one_hand_violation_offhand_not_empty";
            }
        } else if (handType === HandType.LEFT) {
            if (mainOccupied && !hasShieldMain) {
                isAttackAllowed = false;
                denyReason = "only_one_hand_violation_mainhand_not_empty";
            }
        } else {
            isAttackAllowed = false;
            denyReason = "only_one_hand_missing";
        }
    } else if (handTag === WeaponHandTag.ANY_HAND
        || handTag === WeaponHandTag.LONGSWORD
        || handTag === WeaponHandTag.DOUBLE_HAND) {
        // sag:any_hand, sag:longsword, double_hand — все работают как "любая рука"
        if (handType === HandType.NONE) {
            isAttackAllowed = false;
            denyReason = "any_hand_missing";
        }
    } else {
        // Неизвестный тег — по умолчанию разрешаем если оружие в руке
        if (handType === HandType.NONE) {
            isAttackAllowed = false;
            denyReason = "unknown_tag_no_weapon_in_hand";
        }
    }

    return {
        weapon,
        mainItemStack: mainItem,
        offItemStack: offItem,
        handType,
        handStyle,
        mainItemId,
        offItemId,
        mainWeapon,
        offWeapon,
        hasShieldMain,
        hasShieldOff,
        isAttackAllowed,
        denyReason,
    };
}

function shareWeaponTypeTag(a, b) {
    const aType = a?.weaponType;
    const bType = b?.weaponType;
    if (typeof aType === "string" && typeof bType === "string") {
        return aType === bType;
    }
    return false;
}

/**
 * Получить анимацию для конкретного стиля руки.
 * Fallback: shield → обычная однорукая, both → правая.
 */
export function getAnimationForStyle(attack, handStyle) {
    if (!attack?.animations) {
        return attack?.fullName;
    }

    let anim = attack.animations[handStyle];

    if (!anim) {
        if (handStyle === HandStyle.SHIELD_RIGHT) {
            anim = attack.animations[HandStyle.RIGHT];
        } else if (handStyle === HandStyle.SHIELD_LEFT) {
            anim = attack.animations[HandStyle.LEFT];
        } else if (handStyle === HandStyle.BOTH) {
            anim = attack.animations[HandStyle.RIGHT];
        }
    }
    return anim;
}

/**
 * Получить анимацию блока для стиля.
 */
export function getBlockAnimationForStyle(weapon, handStyle, isMoving = false) {
    const blocking = weapon?.blocking;
    if (!blocking?.enabled) return undefined;

    const anims = isMoving ? blocking.blockMoveAnims : blocking.blockAnims;
    if (!anims) return undefined;

    let anim = anims[handStyle];

    if (!anim) {
        if (handStyle === HandStyle.SHIELD_RIGHT) {
            anim = anims[HandStyle.RIGHT];
        } else if (handStyle === HandStyle.SHIELD_LEFT) {
            anim = anims[HandStyle.LEFT];
        }
    }
    return anim;
}

/**
 * Получить reset-анимацию для стиля.
 */
export function getResetAnimationForStyle(weapon, handStyle) {
    const reset = weapon?.reset;
    if (!reset) return undefined;

    let resetDef = reset[handStyle];

    if (!resetDef) {
        if (handStyle === HandStyle.SHIELD_RIGHT) {
            resetDef = reset[HandStyle.RIGHT];
        } else if (handStyle === HandStyle.SHIELD_LEFT) {
            resetDef = reset[HandStyle.LEFT];
        } else if (handStyle === HandStyle.BOTH) {
            resetDef = reset[HandStyle.RIGHT];
        }
    }
    return resetDef?.fullName;
}
