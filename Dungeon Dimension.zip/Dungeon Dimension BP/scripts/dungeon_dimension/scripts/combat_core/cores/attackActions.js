// ═══════════════════════════════════════════════════════════
// attackActions.js — Реализации типов атак
// Sweep (slash), Thrust, Area, Circular (aoe_spin)
// ═══════════════════════════════════════════════════════════

import { system, EntityDamageCause, EquipmentSlot } from "@minecraft/server";
import { tryOr } from "./utils/safe.js";
import { TargetingSystem } from "./utils/targetingSystem.js";
import { isInFrontSector, getAngleToTarget, distanceHorizontal, distance3D } from "./utils/damageMath.js";
import { EnchantManager } from "./utils/enchantManager.js";
import { EffectManager } from "./utils/effectManager.js";
import { DUAL_WIELD_CONFIG } from "./utils/constants.js";

// ── Трекер кастомного урона (чтобы damageSystem не отменял наш урон) ──
const _customDamageInFlight = new Set();
export const CustomDamageTracker = Object.freeze({
    isCustomDamage(playerId) { return _customDamageInFlight.has(playerId); }
});

const IMPACT_PARTICLE_DIRECT = "sag:aknock_impact_1";
const IMPACT_PARTICLE_SPLASH = "sag:aknock_impact_small";
const MAX_ATTACK_DISTANCE = 5.0;

// ── Knockback конфигурация по типу атаки ──
const KNOCKBACK_CONFIG = {
    slash_right: { horizontal: 0.45, vertical: 0.15, type: "sweep_right" },
    slash_left: { horizontal: 0.45, vertical: 0.15, type: "sweep_left" },
    thrust: { horizontal: 0.7, vertical: 0.05, type: "push_back" },
    fall_thrust: { horizontal: 0.3, vertical: -0.2, type: "slam_down" },
    slash_sector: { horizontal: 0.4, vertical: 0.1, type: "push_back" },
    aoe_spin: { horizontal: 0.55, vertical: 0.2, type: "radial" },
};
const DEFAULT_KNOCKBACK = { horizontal: 0.35, vertical: 0.1, type: "push_back" };

const ATTACK_CONFIGS = {
    thrust: { radius: 3.0, angle: 45, height: 2.0, sweepMultiplier: 0.8 },
    slash_right: { radius: 3.5, angle: 120, height: 2.0, sweepMultiplier: 1.0 },
    slash_left: { radius: 3.5, angle: 120, height: 2.0, sweepMultiplier: 1.0 },
    slash_sector: { radius: 3.0, angle: 120, height: 2.0, sweepMultiplier: 1.0 },
    fall_thrust: { forward: 3.0, side: 1.6, height: 3.0, sweepMultiplier: 1.0 },
    aoe_spin: { radius: 3.0, angle: 360, height: 2.0, sweepMultiplier: 1.0, rotations: 2 }
};

// ── Reach bonus от скорости движения ──
function getReachBonus(player) {
    const vel = tryOr(() => player.getVelocity(), { x: 0, y: 0, z: 0 });
    const h = Math.sqrt((vel.x ?? 0) ** 2 + (vel.z ?? 0) ** 2);

    let bonus = 0.5;
    if (h > 0.06) bonus += 0.3;
    if (h > 0.18) bonus += 0.5;
    return bonus; // макс +1.3
}

function clampRadius(radius) {
    return Math.min(radius, MAX_ATTACK_DISTANCE);
}

// ── Партиклы удара ──
function spawnImpactParticle(player, target, particleId) {
    if (!player?.isValid || !target?.isValid) return;

    try {
        const dim = player.dimension;
        const { height, width } = TargetingSystem.getCollisionBox(target);
        const targetLoc = target.location;
        const head = player.getHeadLocation();

        const center = {
            x: targetLoc.x,
            y: targetLoc.y + (height * 0.6),
            z: targetLoc.z
        };

        const toPlayerX = head.x - center.x;
        const toPlayerY = head.y - center.y;
        const toPlayerZ = head.z - center.z;
        const len = Math.sqrt(toPlayerX * toPlayerX + toPlayerY * toPlayerY + toPlayerZ * toPlayerZ);

        let pos = center;
        if (len > 0.001) {
            const offset = Math.max(0.4, width * 0.6);
            pos = {
                x: center.x + (toPlayerX / len) * offset,
                y: center.y + (toPlayerY / len) * offset,
                z: center.z + (toPlayerZ / len) * offset
            };
        }

        dim.spawnParticle(particleId, pos);
    } catch { }
}

// ═══════════════════════════════════════════════════════════
// Направленный Knockback по типу атаки
// ═══════════════════════════════════════════════════════════

/**
 * Применить направленный knockback в зависимости от типа атаки.
 * - slash_right → отбросить влево от вьюпоинта атакующего
 * - slash_left → отбросить вправо
 * - thrust → отбросить назад (от атакующего)
 * - aoe_spin → радиально от центра
 * - fall_thrust → вниз + назад
 */
function applyDirectionalKnockback(player, entity, attackKind, customKB) {
    try {
        if (!entity?.isValid || !player?.isValid) return;

        const cfg = customKB ?? KNOCKBACK_CONFIG[attackKind] ?? DEFAULT_KNOCKBACK;
        const hForce = cfg.horizontal ?? DEFAULT_KNOCKBACK.horizontal;
        const vForce = cfg.vertical ?? DEFAULT_KNOCKBACK.vertical;
        const kbType = cfg.type ?? "push_back";

        const playerLoc = player.location;
        const entityLoc = entity.location;

        let kbX = 0;
        let kbZ = 0;

        switch (kbType) {
            case "sweep_right": {
                // Slash right → отбрасывает ВЛЕВО от атакующего (перпендикулярно взгляду)
                const viewDir = player.getViewDirection();
                // Перпендикуляр влево: (-z, x)
                const perpX = -viewDir.z;
                const perpZ = viewDir.x;
                const mag = Math.sqrt(perpX * perpX + perpZ * perpZ);
                if (mag > 0.001) {
                    kbX = (perpX / mag) * hForce;
                    kbZ = (perpZ / mag) * hForce;
                }
                break;
            }
            case "sweep_left": {
                // Slash left → отбрасывает ВПРАВО
                const viewDir = player.getViewDirection();
                // Перпендикуляр вправо: (z, -x)
                const perpX = viewDir.z;
                const perpZ = -viewDir.x;
                const mag = Math.sqrt(perpX * perpX + perpZ * perpZ);
                if (mag > 0.001) {
                    kbX = (perpX / mag) * hForce;
                    kbZ = (perpZ / mag) * hForce;
                }
                break;
            }
            case "push_back": {
                // Thrust / sector → отталкивает от атакующего
                const dx = entityLoc.x - playerLoc.x;
                const dz = entityLoc.z - playerLoc.z;
                const mag = Math.sqrt(dx * dx + dz * dz);
                if (mag > 0.001) {
                    kbX = (dx / mag) * hForce;
                    kbZ = (dz / mag) * hForce;
                } else {
                    // Совпадающая позиция → толкнуть по взгляду
                    const viewDir = player.getViewDirection();
                    kbX = viewDir.x * hForce;
                    kbZ = viewDir.z * hForce;
                }
                break;
            }
            case "radial": {
                // AOE Spin → от центра атакующего
                const dx = entityLoc.x - playerLoc.x;
                const dz = entityLoc.z - playerLoc.z;
                const mag = Math.sqrt(dx * dx + dz * dz);
                if (mag > 0.001) {
                    kbX = (dx / mag) * hForce;
                    kbZ = (dz / mag) * hForce;
                } else {
                    kbX = hForce;
                    kbZ = 0;
                }
                break;
            }
            case "slam_down": {
                // Fall Thrust → назад + вниз
                const dx = entityLoc.x - playerLoc.x;
                const dz = entityLoc.z - playerLoc.z;
                const mag = Math.sqrt(dx * dx + dz * dz);
                if (mag > 0.001) {
                    kbX = (dx / mag) * hForce;
                    kbZ = (dz / mag) * hForce;
                }
                break;
            }
            default: {
                const dx = entityLoc.x - playerLoc.x;
                const dz = entityLoc.z - playerLoc.z;
                const mag = Math.sqrt(dx * dx + dz * dz);
                if (mag > 0.001) {
                    kbX = (dx / mag) * hForce;
                    kbZ = (dz / mag) * hForce;
                }
            }
        }

        // applyKnockback: (directionX, directionZ, horizontalStrength, verticalStrength)
        entity.applyKnockback(kbX, kbZ, hForce, Math.max(0, vForce));

        // Для slam_down — дополнительно прижать к земле
        if (kbType === "slam_down" && vForce < 0) {
            const currentVel = tryOr(() => entity.getVelocity(), { x: 0, y: 0, z: 0 });
            tryOr(() => entity.applyKnockback(
                kbX, kbZ, hForce * 0.5, 0
            ), undefined);
        }
    } catch { }
}

// ── Нанести урон одной цели ──
function dealDamage(player, entity, damage, isCrit = false, forceHit = false, impactParticleId = IMPACT_PARTICLE_SPLASH, extraWeapon = undefined, attackKind = undefined) {
    if (!TargetingSystem.canAttack(player, entity)) return false;

    if (!forceHit) {
        if (!TargetingSystem.hasLineOfSight(player, entity)) return false;
    }

    let finalDamage = damage;

    // Зачарования основной руки
    const mainEnchantBonus = EnchantManager.getDamageBonusForSlot(player, entity, EquipmentSlot.Mainhand);
    finalDamage += mainEnchantBonus;

    // Dual wield — бонус от оффхенда
    if (extraWeapon) {
        const offBase = Number(extraWeapon.damage ?? 0);
        const offMult = DUAL_WIELD_CONFIG.OFFHAND_DAMAGE_MULTIPLIER ?? 1.0;
        const offEnchantBonus = EnchantManager.getDamageBonusForSlot(player, entity, EquipmentSlot.Offhand);
        finalDamage += (offBase * offMult) + offEnchantBonus;
    }

    // Эффекты (strength/weakness)
    const effectBonus = EffectManager.getDamageBonus(player);
    finalDamage += effectBonus;

    // Штраф при уклонении
    if (player.hasTag("sag:evading")) {
        finalDamage = finalDamage * 0.5;
    }

    finalDamage = Math.floor(finalDamage);
    if (finalDamage <= 0) return false;

    try {
        // Пометить что наш кастомный урон — чтобы damageSystem не отменил его
        _customDamageInFlight.add(player.id);
        try {
            entity.applyDamage(finalDamage, {
                cause: EntityDamageCause.entityAttack,
                damagingEntity: player
            });
        } finally {
            _customDamageInFlight.delete(player.id);
        }

        spawnImpactParticle(player, entity, impactParticleId);

        // ★ Направленный Knockback ★
        if (attackKind) {
            applyDirectionalKnockback(player, entity, attackKind);
        }

        if (isCrit) {
            tryOr(() => {
                player.dimension.playSound("random.orb", entity.location, {
                    volume: 0.5,
                    pitch: 0.8 + (Math.random() * 0.4)
                });
                player.dimension.spawnParticle("minecraft:critical_hit_emitter", entity.location);
            }, undefined);
        }

        return true;
    } catch {
        return false;
    }
}

function playSweepEffect(player, multiple = false) {
    const loc = player.location;
    tryOr(() => player.dimension.playSound("entity.player.attack.sweep", loc, {
        volume: 0.8,
        pitch: 0.9 + Math.random() * 0.2
    }), undefined);
}

// ═══════════════════════════════════════════════════════════
// ПУБЛИЧНЫЙ API
// ═══════════════════════════════════════════════════════════

export const AttackActions = Object.freeze({

    /**
     * Sweep (slash_left / slash_right) — горизонтальный удар.
     * Primary target получает полный урон, secondary — уменьшенный.
     */
    performSweepAttack(player, weapon, st, primaryTarget, tick, extraWeapon = undefined) {
        const attackKind = st.currentAttack?.attackKind ?? "slash_right";
        const config = ATTACK_CONFIGS[attackKind] || ATTACK_CONFIGS.slash_right;

        const hitbox = st.currentAttack?.hitbox;
        const radiusBase = hitbox?.radius ?? config.radius;
        const radius = clampRadius(radiusBase + getReachBonus(player));
        const halfAngle = (hitbox?.arcDeg ?? config.angle) / 2;
        const height = hitbox?.height ?? config.height;
        const sweepMult = st.currentAttack?.secondaryDamageMultiplier ?? config.sweepMultiplier;

        const baseDamage = Math.max(0, Number(weapon.damage ?? 0));
        const dmgMult = Number(st.currentAttack?.damageMultiplier ?? 1);

        if (!st.hitMemo) st.hitMemo = new Map();
        const hitMemo = st.hitMemo;
        const hitEntities = [];

        let aimedEntity = primaryTarget;
        if (!aimedEntity) {
            aimedEntity = TargetingSystem.getCrosshairTarget(player, radius);
        }

        const nearbyEntities = TargetingSystem.getEntitiesInRadius(player, radius);
        const playerY = player.location.y;

        for (const entity of nearbyEntities) {
            if (!TargetingSystem.canAttack(player, entity)) continue;
            if (hitMemo.has(entity.id)) continue;

            const isPrimary = aimedEntity && entity.id === aimedEntity.id;

            if (!isPrimary) {
                const entityY = entity.location.y;
                const vertDist = Math.abs(entityY - playerY);
                if (vertDist > height) continue;
                if (!isInFrontSector(player, entity, halfAngle)) continue;
            }

            const damage = isPrimary
                ? Math.floor(baseDamage * dmgMult)
                : Math.floor(baseDamage * dmgMult * sweepMult);

            const particleId = isPrimary ? IMPACT_PARTICLE_DIRECT : IMPACT_PARTICLE_SPLASH;

            if (dealDamage(player, entity, damage, false, isPrimary, particleId, extraWeapon, attackKind)) {
                hitMemo.set(entity.id, tick);
                hitEntities.push(entity);
            }
        }

        if (hitEntities.length > 0) {
            playSweepEffect(player, hitEntities.length > 1);
        }

        return hitEntities;
    },

    /**
     * Thrust — укол вперёд (forward box).
     */
    performThrustAttack(player, weapon, st, primaryTarget, tick, extraWeapon = undefined) {
        const hitbox = st.currentAttack?.hitbox;
        const forwardBase = hitbox?.forward ?? 3.0;
        const forward = clampRadius(forwardBase + getReachBonus(player));
        const side = hitbox?.side ?? 1.0;
        const height = hitbox?.height ?? 2.0;

        const baseDamage = Math.max(0, Number(weapon.damage ?? 0));
        const dmgMult = Number(st.currentAttack?.damageMultiplier ?? 1);

        if (!st.hitMemo) st.hitMemo = new Map();
        const hitMemo = st.hitMemo;
        const hitEntities = [];

        const playerLoc = player.location;
        const rotation = player.getRotation();
        const yawRad = rotation.y * (Math.PI / 180);

        const nearbyEntities = TargetingSystem.getEntitiesInRadius(player, forward + 1);

        for (const entity of nearbyEntities) {
            if (!TargetingSystem.canAttack(player, entity)) continue;
            if (hitMemo.has(entity.id)) continue;

            const isPrimary = primaryTarget && entity.id === primaryTarget.id;

            if (!isPrimary) {
                const entityLoc = entity.location;
                const dx = entityLoc.x - playerLoc.x;
                const dy = entityLoc.y - playerLoc.y;
                const dz = entityLoc.z - playerLoc.z;

                const cos = Math.cos(yawRad);
                const sin = Math.sin(yawRad);

                const localX = dx * cos + dz * sin;
                const localZ = dx * (-sin) + dz * cos;

                if (localZ < 0 || localZ > forward) continue;
                if (Math.abs(localX) > side / 2) continue;
                if (dy < -0.5 || dy > height) continue;
            }

            const particleId = isPrimary ? IMPACT_PARTICLE_DIRECT : IMPACT_PARTICLE_SPLASH;
            const damage = Math.floor(baseDamage * dmgMult);
            if (dealDamage(player, entity, damage, false, isPrimary, particleId, extraWeapon, "thrust")) {
                hitMemo.set(entity.id, tick);
                hitEntities.push(entity);
            }
        }

        if (hitEntities.length > 0) {
            tryOr(() => player.dimension.playSound("entity.player.attack.strong", player.location, {
                volume: 0.8,
                pitch: 0.9 + Math.random() * 0.2
            }), undefined);
        }

        return hitEntities;
    },

    /**
     * Area Attack (fall_thrust, slash_sector) — удар по области.
     */
    performAreaAttack(player, weapon, st, primaryTarget, tick, extraWeapon = undefined) {
        const attackKind = st.currentAttack?.attackKind ?? "slash_sector";
        const hitbox = st.currentAttack?.hitbox;

        const isBoxMode = attackKind === "fall_thrust" || (hitbox?.forward !== undefined && hitbox?.side !== undefined);

        let radius, height;
        let boxForward, boxSide;

        if (isBoxMode) {
            boxForward = hitbox?.forward ?? 3.0;
            boxSide = hitbox?.side ?? 1.6;
            height = hitbox?.height ?? 3.0;
            radius = boxForward + 1.0;
        } else {
            radius = hitbox?.radius ?? 3.0;
            height = hitbox?.height ?? 2.0;
        }

        const searchRadius = clampRadius((radius ?? 3.0) + Math.min(getReachBonus(player), 0.5));

        const baseDamage = Math.max(0, Number(weapon.damage ?? 0));
        const dmgMult = Number(st.currentAttack?.damageMultiplier ?? 1);

        if (!st.hitMemo) st.hitMemo = new Map();
        const hitMemo = st.hitMemo;
        const hitEntities = [];

        const playerLoc = player.location;
        const nearbyEntities = TargetingSystem.getEntitiesInRadius(player, searchRadius + 1);

        let cos, sin;
        if (isBoxMode) {
            const rotation = player.getRotation();
            const yawRad = rotation.y * (Math.PI / 180);
            cos = Math.cos(yawRad);
            sin = Math.sin(yawRad);
        }

        for (const entity of nearbyEntities) {
            if (!TargetingSystem.canAttack(player, entity)) continue;
            if (hitMemo.has(entity.id)) continue;

            const isPrimary = primaryTarget && entity.id === primaryTarget.id;

            if (!isPrimary) {
                const entityLoc = entity.location;

                if (isBoxMode) {
                    const dx = entityLoc.x - playerLoc.x;
                    const dy = entityLoc.y - playerLoc.y;
                    const dz = entityLoc.z - playerLoc.z;

                    const localX = dx * cos + dz * sin;
                    const localZ = dx * (-sin) + dz * cos;

                    if (localZ < -0.8 || localZ > boxForward) continue;
                    if (Math.abs(localX) > boxSide / 2) continue;

                    const vertDist = playerLoc.y - entityLoc.y;
                    if (vertDist < -1 || vertDist > height) continue;
                } else {
                    const vertDist = Math.abs(entityLoc.y - playerLoc.y);
                    if (vertDist > height) continue;

                    const horizDist = distanceHorizontal(playerLoc, entityLoc);
                    if (horizDist > searchRadius) continue;
                }
            }

            const particleId = isPrimary ? IMPACT_PARTICLE_DIRECT : IMPACT_PARTICLE_SPLASH;
            const damage = Math.floor(baseDamage * dmgMult);
            if (dealDamage(player, entity, damage, false, isPrimary, particleId, extraWeapon, attackKind)) {
                hitMemo.set(entity.id, tick);
                hitEntities.push(entity);
            }
        }

        if (hitEntities.length > 0) {
            tryOr(() => {
                player.dimension.playSound("entity.player.attack.strong", player.location, {
                    volume: 1.0,
                    pitch: 0.8
                });
            }, undefined);
        }

        return hitEntities;
    },

    /**
     * Circular Attack (aoe_spin) — вращение 360°.
     * Моб может получить удар раз за оборот.
     */
    performCircularAttack(player, weapon, st, tick, extraWeapon = undefined) {
        const hitbox = st.currentAttack?.hitbox;
        const radius = clampRadius((hitbox?.radius ?? 3.0) + Math.min(getReachBonus(player), 0.5));
        const height = hitbox?.height ?? 2.0;
        const rotations = hitbox?.rotations ?? 2;

        const baseDamage = Math.max(0, Number(weapon.damage ?? 0));
        const dmgMult = Number(st.currentAttack?.damageMultiplier ?? 1);

        const startTick = Number(st.damageStartTick ?? tick);
        const endTick = Number(st.damageEndTick ?? tick);
        const duration = Math.max(1, endTick - startTick);
        const elapsed = tick - startTick;

        if (elapsed < 0 || elapsed > duration) return [];

        const ratio = elapsed / duration;
        const totalRotation = ratio * Math.PI * 2 * rotations;
        let currentAngle = totalRotation % (Math.PI * 2);

        const rotationIndex = Math.min(Math.max(0, Math.floor(rotations) - 1), Math.floor(ratio * rotations));
        const sectorWidth = Math.PI / 3;

        if (!st.hitMemo) st.hitMemo = new Map();
        const hitMemo = st.hitMemo;
        const hitEntities = [];

        const playerLoc = player.location;
        const nearbyEntities = TargetingSystem.getEntitiesInRadius(player, radius);

        for (const entity of nearbyEntities) {
            if (!TargetingSystem.canAttack(player, entity)) continue;

            const lastHitRotation = hitMemo.get(entity.id);
            if (lastHitRotation !== undefined && lastHitRotation >= rotationIndex) continue;

            const entityLoc = entity.location;
            const vertDist = Math.abs(entityLoc.y - playerLoc.y);
            if (vertDist > height) continue;

            const angleToEntity = getAngleToTarget(player, entity);

            let diff = Math.abs(angleToEntity - currentAngle);
            if (diff > Math.PI) {
                diff = (Math.PI * 2) - diff;
            }

            if (diff > sectorWidth) continue;

            const damage = Math.floor(baseDamage * dmgMult);
            if (dealDamage(player, entity, damage, false, false, IMPACT_PARTICLE_SPLASH, extraWeapon, "aoe_spin")) {
                hitMemo.set(entity.id, rotationIndex);
                hitEntities.push(entity);

                tryOr(() => {
                    player.dimension.playSound("entity.player.attack.sweep", entity.location, {
                        volume: 0.6,
                        pitch: 0.9 + Math.random() * 0.2
                    });
                }, undefined);
            }
        }

        return hitEntities;
    },

    /**
     * Универсальный диспетчер — определяет тип атаки и вызывает нужный метод.
     */
    executeAttack(player, weapon, st, primaryTarget, tick, extraWeapon = undefined) {
        const attackKind = st.currentAttack?.attackKind;

        switch (attackKind) {
            case "thrust":
                return this.performThrustAttack(player, weapon, st, primaryTarget, tick, extraWeapon);

            case "slash_left":
            case "slash_right":
                return this.performSweepAttack(player, weapon, st, primaryTarget, tick, extraWeapon);

            case "fall_thrust":
            case "slash_sector":
                return this.performAreaAttack(player, weapon, st, primaryTarget, tick, extraWeapon);

            case "aoe_spin":
                return this.performCircularAttack(player, weapon, st, tick, extraWeapon);

            default:
                return this.performSweepAttack(player, weapon, st, primaryTarget, tick, extraWeapon);
        }
    }
});
