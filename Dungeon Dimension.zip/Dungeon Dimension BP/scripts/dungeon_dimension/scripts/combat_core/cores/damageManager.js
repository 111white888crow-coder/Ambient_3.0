// ═══════════════════════════════════════════════════════════
// damageManager.js — Arm/Disarm механизм нанесения урона
// Слушает entityHitEntity/Block → взводит damage
// Каждый тик вызывает HitboxDamage если armed
// ═══════════════════════════════════════════════════════════

import { world, system } from "@minecraft/server";
import { resolveWeaponForPlayer } from "./itemTagRules.js";
import { AnimationController } from "./animationController.js";
import { HitboxDamage } from "./hitboxDamage.js";
import { tryOr } from "./utils/safe.js";

const _tickLocks = new WeakMap();
const _pendingHit = new WeakMap();

let _initialized = false;

/**
 * Взвести механизм урона для текущей атаки.
 * Если игрок движется → начать урон немедленно.
 */
function _armForState(player, st, uid, primaryTargetId) {
    st.primaryTargetId = primaryTargetId;

    if (st._damageArmRun) {
        try { system.clearRun(st._damageArmRun); } catch { }
        st._damageArmRun = null;
    }

    const tick = system.currentTick;
    const startTick = Number(st.damageStartTick ?? tick);
    const endTick = Number(st.damageEndTick ?? tick + 10);

    const vel = tryOr(() => player.getVelocity(), { x: 0, y: 0, z: 0 });
    const hSpeed = Math.sqrt((vel.x ?? 0) ** 2 + (vel.z ?? 0) ** 2);

    // Если двигается — начать урон сразу (реактивность)
    const effectiveStartTick = (hSpeed > 0.1)
        ? tick
        : Math.min(startTick, tick + 1);
    const delay = Math.max(0, effectiveStartTick - tick);

    const doArm = () => {
        if (!player.isValid) return;

        const st2 = AnimationController.getState(player);
        if (!st2 || !st2.isAttacking) return;
        if (Number(st2.attackUid ?? 0) !== uid) return;

        st2.hitMemo = new Map();
        st2.damageArmed = true;
        st2.damageArmedUntilTick = Number(st2.damageEndTick ?? system.currentTick + 10);

        if (system.currentTick > st2.damageArmedUntilTick) {
            st2.damageArmed = false;
            st2.damageArmedUntilTick = 0;
            st2.primaryTargetId = null;
        }
    };

    if (delay <= 0) {
        doArm();
    } else {
        st._damageArmRun = system.runTimeout(doArm, delay);
    }
}

export const DamageManager = Object.freeze({

    init() {
        if (_initialized) return;
        _initialized = true;

        // ── ЛКМ попал в сущность ──
        world.afterEvents.entityHitEntity.subscribe((ev) => {
            const player = ev.damagingEntity;
            if (!player || player.typeId !== "minecraft:player") return;
            this.processAttack(player, ev.hitEntity ?? null);
        });

        // ── ЛКМ попал в блок ──
        world.afterEvents.entityHitBlock.subscribe((ev) => {
            const player = ev.damagingEntity;
            if (!player || player.typeId !== "minecraft:player") return;
            this.processAttack(player, null);
        });
    },

    /**
     * Обработка удара — взвести damage если идёт атака.
     */
    processAttack(player, target) {
        const tick = system.currentTick;
        const last = _tickLocks.get(player);
        if (last === tick) return;
        _tickLocks.set(player, tick);

        const resolved = resolveWeaponForPlayer(player);
        const weapon = resolved.weapon;
        if (!weapon) return;

        const st = AnimationController.getState(player);

        if (!st || !st.isAttacking) {
            // Буферизовать удар (pending) — применится при следующей атаке
            _pendingHit.set(player, {
                tick,
                primaryTargetId: target ? target.id : null
            });
            return;
        }

        const uid = Number(st.attackUid ?? 0);
        if (!uid) {
            _pendingHit.set(player, {
                tick,
                primaryTargetId: target ? target.id : null
            });
            return;
        }

        if (st.damageRequestedUid === uid) return;
        st.damageRequestedUid = uid;

        _armForState(player, st, uid, target ? target.id : null);
    },

    /**
     * Тик — проверить pending hits, вызвать HitboxDamage.
     */
    tickPlayer(player, weapon, st, tick) {
        // Применить буферизованный удар
        if (st && st.isAttacking && !st.damageArmed) {
            const pending = _pendingHit.get(player);
            if (pending) {
                const age = tick - Number(pending.tick ?? tick);
                if (age >= 0 && age <= 6) {
                    const uid = Number(st.attackUid ?? 0);
                    if (uid && st.damageRequestedUid !== uid) {
                        st.damageRequestedUid = uid;
                        _armForState(player, st, uid, pending.primaryTargetId ?? null);
                    }
                    _pendingHit.delete(player);
                } else if (age > 10) {
                    _pendingHit.delete(player);
                }
            }
        }

        if (!st || !st.damageArmed) return;

        if (!st.isAttacking || tick > Number(st.damageArmedUntilTick ?? 0)) {
            st.damageArmed = false;
            st.damageArmedUntilTick = 0;
            st.primaryTargetId = null;
            return;
        }

        HitboxDamage.tickPlayer(player, weapon, st, tick);

        if (tick >= Number(st.damageEndTick ?? 0)) {
            st.damageArmed = false;
            st.damageArmedUntilTick = 0;
            st.primaryTargetId = null;
        }
    },

    /** Полный сброс */
    reset(player) {
        const st = AnimationController.getState(player);
        if (!st) return;

        if (st._damageArmRun) {
            try { system.clearRun(st._damageArmRun); } catch { }
            st._damageArmRun = null;
        }

        st.damageArmed = false;
        st.damageArmedUntilTick = 0;
        st.damageRequestedUid = 0;
        st.primaryTargetId = null;
        st.hitMemo = new Map();

        _pendingHit.delete(player);
        _tickLocks.delete(player);
    }
});
