// ═══════════════════════════════════════════════════════════
// weaponRegistry.js — Реестр оружий (Map по itemId)
// ═══════════════════════════════════════════════════════════

const _weaponsById = new Map();

export const WeaponRegistry = Object.freeze({

    /** Зарегистрировать оружие по его id (= itemId) */
    register(weaponDef) {
        if (!weaponDef?.id || typeof weaponDef.id !== "string") {
            throw new Error("WeaponRegistry.register: weaponDef.id is required");
        }
        _weaponsById.set(weaponDef.id, weaponDef);
    },

    /** Найти оружие по itemId */
    get(itemId) {
        if (!itemId) return undefined;
        return _weaponsById.get(itemId);
    },

    /** Существует ли оружие с данным id */
    has(itemId) {
        if (!itemId) return false;
        return _weaponsById.has(itemId);
    },

    /** Список всех zарегистрированных оружий */
    list() {
        return Array.from(_weaponsById.values());
    },

    /** Список всех id */
    listIds() {
        return Array.from(_weaponsById.keys());
    },

    /** Удалить оружие из реестра */
    unregister(itemId) {
        return _weaponsById.delete(itemId);
    },

    /** Очистить весь реестр */
    clear() {
        _weaponsById.clear();
    }
});
