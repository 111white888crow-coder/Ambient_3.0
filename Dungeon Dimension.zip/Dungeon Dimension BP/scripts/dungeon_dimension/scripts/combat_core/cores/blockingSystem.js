// ═══════════════════════════════════════════════════════════
// blockingSystem.js — Блок, Парирование, Guard Break
// itemUse → block, itemStopUse → endBlock
// Parry window → контратака
// ═══════════════════════════════════════════════════════════

import { world, system, EquipmentSlot } from "@minecraft/server";
import { BLOCKING_CONFIG, POSTURE_CONFIG, PLAYER_TAGS, HandType } from "./utils/constants.js";
import { resolveWeaponForPlayer } from "./itemTagRules.js";
import { EffectRegistry } from "./effectRegistry.js";
import { PostureManager } from "./postureManager.js";
import { nowTick, secondsToTicks } from "./utils/time.js";
import { tryRun, tryOr } from "./utils/safe.js";
import { AnimationController } from "./animationController.js";
import { getItemId } from "./utils/equipment.js";

const blockStates = new Map();
const lastBlockEndTimes = new Map();

const MIN_BLOCK_DURATION = 4;          // мин длительность блока (тиков)
const POST_BLOCK_PARRY_WINDOW = 20;    // тиков парирующего окна после блока
const EVADING_TAG = "sag:evading";

export function initBlockingSystem() {
    world.beforeEvents.itemUse.subscribe(onItemUse);
    world.afterEvents.itemStopUse.subscribe(onItemStopUse);
    world.beforeEvents.entityHurt.subscribe(onEntityHurt);

    world.afterEvents.playerLeave.subscribe((ev) => {
        const pid = ev?.playerId;
        if (!pid) return;
        blockStates.delete(pid);
        lastBlockEndTimes.delete(pid);
    });

    console.log("[BlockingSystem] Initialized");
}

// ═══ Начало блока (ПКМ / item use) ═══
function onItemUse(event) {
    const { source: player, itemStack } = event;
    if (player.typeId !== "minecraft:player") return;

    system.run(() => {
        if (player.hasTag(EVADING_TAG)) return;

        const tickNow = nowTick();
        const existingState = blockStates.get(player.id);

        // Обновить время последнего use если уже блокирует тем же предметом
        if (existingState?.isBlocking) {
            const currentItemId = getItemId(itemStack);
            if (currentItemId === existingState.blockingItemId) {
                existingState.lastItemUseTick = tickNow;
                EffectRegistry.applyUntil(player, "slowness", tickNow + 40, {
                    amplifier: BLOCKING_CONFIG.EFFECT_AMPLIFIER,
                    showParticles: false
                });
                return;
            } else {
                endBlock(player);
            }
        }

        const resolution = resolveWeaponForPlayer(player);
        if (!resolution.weapon?.blocking?.enabled) return;
        if (resolution.handType === HandType.LEFT) return;

        if (!PostureManager.canBlock(player)) return;

        startBlock(player, resolution, itemStack, player.selectedSlotIndex);

        EffectRegistry.applyUntil(player, "slowness", tickNow + 40, {
            amplifier: BLOCKING_CONFIG.EFFECT_AMPLIFIER,
            showParticles: false
        });
    });
}

// ═══ Конец блока (отпустил ПКМ) ═══
function onItemStopUse(event) {
    const { source: player } = event;
    if (player?.typeId !== "minecraft:player") return;

    const state = blockStates.get(player.id);
    if (!state?.isBlocking) return;

    const tickNow = nowTick();
    const duration = tickNow - state.blockStartTick;

    // Минимальная длительность
    if (duration < MIN_BLOCK_DURATION) {
        const remaining = MIN_BLOCK_DURATION - duration;
        system.runTimeout(() => {
            if (!player.isValid) return;
            const currentState = blockStates.get(player.id);
            if (currentState && currentState.blockStartTick === state.blockStartTick) {
                endBlock(player);
            }
        }, remaining);
        return;
    }

    endBlock(player);
}

// ═══ Перехват урона при блоке ═══
function onEntityHurt(event) {
    const { hurtEntity, damageSource } = event;
    if (hurtEntity.typeId !== "minecraft:player") return;

    const state = blockStates.get(hurtEntity.id);
    if (!state?.isBlocking) return;

    // При уклонении — сбросить блок
    if (hurtEntity.hasTag(EVADING_TAG)) {
        system.run(() => endBlock(hurtEntity));
        return;
    }

    const resolution = resolveWeaponForPlayer(hurtEntity);
    const blocking = resolution.weapon?.blocking;
    if (!blocking?.enabled) return;

    const attacker = damageSource.damagingEntity;

    // Проверить — удар спереди?
    if (attacker && !isAttackFromFront(hurtEntity, attacker, blocking.blockAngle ?? BLOCKING_CONFIG.DEFAULT_ANGLE)) {
        return;
    }

    // ★ PARRY — в parry window ★
    if (state.inParryWindow && attacker) {
        event.cancel = true;
        system.run(() => triggerParry(hurtEntity, attacker));
        return;
    }

    // ★ BLOCK — потратить стойкость ★
    const postureCost = Number(blocking.postureCost ?? POSTURE_CONFIG.COST_SWORD ?? 4);

    if (state.postureRemaining >= postureCost) {
        event.cancel = true;

        system.run(() => {
            PostureManager.consume(hurtEntity, postureCost);
            const currentState = blockStates.get(hurtEntity.id);
            if (currentState) {
                currentState.postureRemaining = PostureManager.getState(hurtEntity).value;
            }
            damageEquipment(hurtEntity, 1);
            playBlockEffect(hurtEntity, attacker);
        });
    } else if (state.postureRemaining > 0) {
        // ★ GUARD BREAK ★
        system.run(() => {
            PostureManager.consume(hurtEntity, PostureManager.getState(hurtEntity).value);
            const currentState = blockStates.get(hurtEntity.id);
            if (currentState) currentState.postureRemaining = 0;
            breakBlock(hurtEntity);
        });
    }
}

// ── Wear durability ──
function damageEquipment(player, amount) {
    try {
        const eq = player.getComponent("minecraft:equippable");
        if (!eq) return;
        const item = eq.getEquipment(EquipmentSlot.Mainhand);
        if (!item) return;
        const durability = item.getComponent("minecraft:durability");
        if (!durability) return;

        if (durability.damage + amount >= durability.maxDurability) {
            player.playSound("random.break");
            eq.setEquipment(EquipmentSlot.Mainhand, undefined);
        } else {
            durability.damage += amount;
            eq.setEquipment(EquipmentSlot.Mainhand, item);
        }
    } catch (e) { }
}

// ── Start block ──
function startBlock(player, resolution, itemStack, slotIndex) {
    const tick = nowTick();
    const pst = PostureManager.getState(player);
    const postureMax = Number(pst.max ?? POSTURE_CONFIG.BASE ?? 20);
    const postureRemaining = Number(pst.value ?? postureMax);

    const state = {
        isBlocking: true,
        blockStartTick: tick,
        inParryWindow: true,
        lastParryTriggerTick: 0,
        handStyle: resolution.handStyle,
        postureRemaining: postureRemaining,
        postureMax: postureMax,
        blockingItemId: getItemId(itemStack),
        selectedSlot: slotIndex,
        lastItemUseTick: tick,
    };

    blockStates.set(player.id, state);

    tryRun(() => player.addTag(PLAYER_TAGS.BLOCKING));
    AnimationController.setBlocking(player, true);

    // Parry window timer
    system.runTimeout(() => {
        const currentState = blockStates.get(player.id);
        if (currentState && currentState.blockStartTick === tick) {
            currentState.inParryWindow = false;
        }
    }, BLOCKING_CONFIG.PARRY_WINDOW_TICKS);
}

// ── End block ──
function endBlock(player) {
    const state = blockStates.get(player.id);
    if (!state?.isBlocking) return;

    state.isBlocking = false;
    EffectRegistry.end(player, "slowness");

    blockStates.delete(player.id);
    tryRun(() => player.removeTag(PLAYER_TAGS.BLOCKING));

    lastBlockEndTimes.set(player.id, nowTick());
    AnimationController.setBlocking(player, false);
}

// ── Trigger parry ──
function triggerParry(player, attacker) {
    endBlock(player);

    tryRun(() => player.addTag(PLAYER_TAGS.PARRY_WINDOW));
    playParryEffect(player, attacker);

    // Замедлить врага (не игрока)
    if (attacker && attacker.typeId !== "minecraft:player") {
        tryRun(() => {
            attacker.addEffect("slowness", secondsToTicks(1.5), { amplifier: 4, showParticles: false });
        });
    }

    // Снять parry window через 0.8 сек
    system.runTimeout(() => {
        tryRun(() => player.removeTag(PLAYER_TAGS.PARRY_WINDOW));
    }, secondsToTicks(0.8));
}

// ── Guard break ──
function breakBlock(player) {
    endBlock(player);
    tryRun(() => {
        player.playSound("random.break");
        EffectRegistry.applyUntil(player, "slowness", nowTick() + secondsToTicks(1.5), {
            amplifier: 4,
            showParticles: false
        });
    });
}

// ── Angle check: удар спереди? ──
function isAttackFromFront(player, attacker, blockAngleDeg) {
    const playerLoc = player.location;
    const attackerLoc = attacker.location;
    const dx = attackerLoc.x - playerLoc.x;
    const dz = attackerLoc.z - playerLoc.z;
    const viewDir = player.getViewDirection();
    const dot = viewDir.x * dx + viewDir.z * dz;
    const magA = Math.sqrt(viewDir.x * viewDir.x + viewDir.z * viewDir.z);
    const magB = Math.sqrt(dx * dx + dz * dz);
    if (magA < 0.001 || magB < 0.001) return true;
    const cosAngle = dot / (magA * magB);
    const angle = Math.acos(Math.max(-1, Math.min(1, cosAngle))) * (180 / Math.PI);
    return angle <= blockAngleDeg / 2;
}

// ── Effects ──
function playBlockEffect(player, attacker) {
    tryRun(() => {
        player.dimension.playSound("random.anvil_land", player.location, {
            pitch: 1.5 + Math.random() * 0.2,
            volume: 1.0
        });

        let particleLoc = player.location;
        if (attacker?.location) {
            particleLoc = {
                x: (player.location.x + attacker.location.x) / 2,
                y: player.location.y + 1.2,
                z: (player.location.z + attacker.location.z) / 2,
            };
        } else {
            particleLoc = { ...player.location, y: player.location.y + 1.5 };
        }
        player.dimension.spawnParticle("sag:knockback_roar2_particle", particleLoc);
    });
}

function playParryEffect(player, attacker) {
    tryRun(() => {
        player.dimension.playSound("random.anvil_land", player.location, { pitch: 2.0, volume: 0.8 });
        const particleLoc = {
            x: (player.location.x + attacker.location.x) / 2,
            y: player.location.y + 1,
            z: (player.location.z + attacker.location.z) / 2,
        };
        player.dimension.spawnParticle("sag:knockback_roar2_particle", particleLoc);
    });
}

// ═══ Public API ═══

export function isPlayerBlocking(player) {
    const state = blockStates.get(player.id);
    return state?.isBlocking ?? false;
}

export function isInParryWindow(player) {
    const state = blockStates.get(player.id);
    return state?.inParryWindow ?? false;
}

export function canPerformParryCounter(player) {
    if (player.hasTag(PLAYER_TAGS.PARRY_WINDOW)) return true;
    const lastEnd = lastBlockEndTimes.get(player.id);
    if (lastEnd !== undefined) {
        const timeSinceBlock = nowTick() - lastEnd;
        if (timeSinceBlock >= 0 && timeSinceBlock <= POST_BLOCK_PARRY_WINDOW) {
            return true;
        }
    }
    return false;
}

export function getBlockState(player) {
    return blockStates.get(player.id);
}

export function resetBlockState(player) {
    EffectRegistry.end(player, "slowness");
    endBlock(player);
    tryRun(() => player.removeTag(PLAYER_TAGS.PARRY_WINDOW));
}

/** Тик — проверить валидность блока */
export function tickBlockingSystem(player) {
    const state = blockStates.get(player.id);
    if (!state?.isBlocking) return;
    const tickNow = nowTick();

    // Уклонение отменяет блок
    if (player.hasTag(EVADING_TAG)) {
        endBlock(player);
        return;
    }

    // Слот сменён → отменить блок
    if (player.selectedSlotIndex !== state.selectedSlot) {
        endBlock(player);
        return;
    }

    // Предмет сменён → отменить блок
    const inventory = tryOr(() => player.getComponent("minecraft:equippable"), undefined);
    const currentItem = inventory?.getEquipment(EquipmentSlot.Mainhand);
    if (getItemId(currentItem) !== state.blockingItemId) {
        endBlock(player);
        return;
    }

    // Обновить slowness
    EffectRegistry.applyUntil(player, "slowness", tickNow + 40, {
        amplifier: BLOCKING_CONFIG.EFFECT_AMPLIFIER,
        showParticles: false
    });
}
