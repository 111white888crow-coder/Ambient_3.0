// ═══════════════════════════════════════════════════════════
// damageSystem.js — Перехват entityHurt
// Clash detection, interrupt, cancel vanilla damage
// ═══════════════════════════════════════════════════════════

import { world, system, EntityDamageCause, EquipmentSlot } from "@minecraft/server";
import { resolveWeaponForPlayer } from "./itemTagRules.js";
import { AnimationController } from "./animationController.js";
import { tryOr } from "./utils/safe.js";
import { CustomDamageTracker } from "./attackActions.js";

let _initialized = false;

/** Повредить durability оружия */
function _damageDurability(player, amount) {
    try {
        const eq = player.getComponent("minecraft:equippable");
        if (!eq) return;

        const item = eq.getEquipment(EquipmentSlot.Mainhand);
        if (!item) return;

        const durability = item.getComponent("minecraft:durability");
        if (!durability) return;

        if (durability.damage + amount >= durability.maxDurability) {
            player.playSound("random.break");
            eq.setEquipment(EquipmentSlot.Mainhand, undefined);
        } else {
            durability.damage += amount;
            eq.setEquipment(EquipmentSlot.Mainhand, item);
        }
    } catch (e) { }
}

/** Проверить — открыто ли damage window */
function _isDamageWindowOpen(st) {
    if (!st?.isAttacking) return false;
    const tick = system.currentTick;
    return tick >= Number(st.damageStartTick ?? 0)
        && tick <= Number(st.damageEndTick ?? 0);
}

/** Сбросить damage state */
function _disarmState(st) {
    if (!st) return;
    st.isAttacking = false;
    st.damageArmed = false;
    st.damageArmedUntilTick = 0;
    st.primaryTargetId = null;
    st.damageStartTick = 0;
    st.damageEndTick = 0;
    st.hitMemo = new Map();
    st.damageRequestedUid = 0;
    // NOTE: НЕ сбрасываем attackUid — сломает uid matching в damageManager.doArm()
}

/** Можно ли прервать атаку (в damage window, но ещё не нанёс урон) */
function _canInterrupt(st) {
    if (!st?.isAttacking) return false;
    if (!_isDamageWindowOpen(st)) return false;
    if (st.hitMemo && st.hitMemo.size > 0) return false;
    return true;
}

export const DamageSystem = Object.freeze({

    bind() {
        if (_initialized) return;
        _initialized = true;

        world.beforeEvents.entityHurt.subscribe((ev) => {
            const victim = ev.hurtEntity;
            const attacker = ev.damageSource.damagingEntity;
            const cause = ev.damageSource.cause;

            if (!victim || !attacker) return;

            // Работаем только с entity attack
            if (cause !== EntityDamageCause.entityAttack) {
                return;
            }

            const isCustomDmg = attacker.typeId === "minecraft:player"
                && CustomDamageTracker.isCustomDamage(attacker.id);

            // ═══ PvP CLASH: оба игрока в damage window → stagger обоих ═══
            // ВАЖНО: проверяем для ЛЮБОГО entityAttack (и ванильного, и кастомного)
            if (attacker.typeId === "minecraft:player" && victim.typeId === "minecraft:player") {
                const playerAttacker = attacker;
                const playerVictim = victim;

                const attState = AnimationController.getState(playerAttacker);
                const vicState = AnimationController.getState(playerVictim);

                if (attState?.isAttacking && vicState?.isAttacking) {
                    const attRes = tryOr(() => resolveWeaponForPlayer(playerAttacker), { weapon: undefined });
                    const vicRes = tryOr(() => resolveWeaponForPlayer(playerVictim), { weapon: undefined });

                    if (attRes.weapon && vicRes.weapon) {
                        const attDmgOpen = _isDamageWindowOpen(attState);
                        const vicDmgOpen = _isDamageWindowOpen(vicState);

                        if (attDmgOpen && vicDmgOpen && _canInterrupt(attState) && _canInterrupt(vicState)) {
                            // ★ CLASH — оба stagger ★
                            ev.cancel = true;

                            _disarmState(attState);
                            _disarmState(vicState);

                            // Позиции для частиц
                            const attLoc = { ...playerAttacker.location };
                            const vicLoc = { ...playerVictim.location };
                            const midLoc = {
                                x: (attLoc.x + vicLoc.x) / 2,
                                y: (attLoc.y + vicLoc.y) / 2 + 1.2,
                                z: (attLoc.z + vicLoc.z) / 2,
                            };

                            system.run(() => {
                                if (!tryOr(() => playerAttacker.isValid, false)) return;
                                if (!tryOr(() => playerVictim.isValid, false)) return;

                                AnimationController.stopAttack(playerAttacker, attRes.weapon, attRes.handStyle, midLoc);
                                AnimationController.stopAttack(playerVictim, vicRes.weapon, vicRes.handStyle, midLoc);

                                _damageDurability(playerAttacker, 1);
                                _damageDurability(playerVictim, 1);
                            });

                            return;
                        }
                    }
                }
            }

            // Пропустить наш кастомный урон — не отменять (clash уже проверен выше)
            if (isCustomDmg) return;

            // ═══ INTERRUPT: жертва в damage window → stagger ═══
            if (victim.typeId === "minecraft:player") {
                const playerVictim = victim;
                const vicState = AnimationController.getState(playerVictim);

                if (_canInterrupt(vicState)) {
                    const vicRes = tryOr(() => resolveWeaponForPlayer(playerVictim), { weapon: undefined });

                    if (vicRes.weapon) {
                        _disarmState(vicState);

                        const attackerLoc = tryOr(() => ({ ...attacker.location }), null);
                        const victimLoc = { ...playerVictim.location };
                        const interruptLoc = attackerLoc ? {
                            x: (attackerLoc.x + victimLoc.x) / 2,
                            y: Math.max(attackerLoc.y, victimLoc.y) + 1.2,
                            z: (attackerLoc.z + victimLoc.z) / 2,
                        } : { ...victimLoc, y: victimLoc.y + 1.2 };

                        system.run(() => {
                            if (!tryOr(() => playerVictim.isValid, false)) return;
                            AnimationController.stopAttack(playerVictim, vicRes.weapon, vicRes.handStyle, interruptLoc);
                        });
                    }
                }
            }

            // ═══ CANCEL VANILLA DAMAGE: атакующий с оружием ═══
            if (attacker.typeId === "minecraft:player") {
                const resolved = tryOr(() => resolveWeaponForPlayer(attacker), { weapon: undefined });
                if (resolved.weapon) {
                    ev.cancel = true;
                }
            }
        });
    },

    shouldCancelVanillaDamage(player) {
        const resolved = tryOr(() => resolveWeaponForPlayer(player), { weapon: undefined });
        return !!resolved.weapon;
    }
});
