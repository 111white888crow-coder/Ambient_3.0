// ═══════════════════════════════════════════════════════════
// hitboxDamage.js — Тик-урон в damage window
// Вызывает AttackActions каждый тик пока damage armed
// ═══════════════════════════════════════════════════════════

import { AttackActions } from "./attackActions.js";
import { resolveWeaponForPlayer } from "./itemTagRules.js";
import { tryOr } from "./utils/safe.js";
import { HandType } from "./utils/constants.js";

export const HitboxDamage = Object.freeze({

    /** Сброс hitMemo при начале атаки */
    onAttackStart(st) {
        st.hitMemo = new Map();
    },

    /**
     * Тик — нанести урон если в damage window.
     * Вызывается из DamageManager каждый тик при damageArmed.
     */
    tickPlayer(player, weapon, st, tick) {
        if (!st?.damageArmed) return;

        const atk = st.currentAttack;
        if (!atk) return;

        const startTick = Number(st.damageStartTick ?? 0);
        const endTick = Number(st.damageEndTick ?? 0);

        if (tick < startTick || tick > endTick) return;

        // Найти primary target по сохранённому id
        let primaryTarget = null;
        if (st.primaryTargetId) {
            try {
                const candidates = player.dimension.getEntities({
                    location: player.location,
                    maxDistance: 10
                });
                for (const e of candidates) {
                    if (e.id === st.primaryTargetId) {
                        primaryTarget = e;
                        break;
                    }
                }
            } catch { }
        }

        const attackKind = atk.attackKind ?? "slash_right";

        if (attackKind === "aoe_spin") {
            AttackActions.performCircularAttack(player, weapon, st, tick);
        } else {
            // Dual wield — добавляем урон оффхенда
            const resolved = resolveWeaponForPlayer(player);
            let extraWeapon = undefined;

            if (resolved.handType === HandType.BOTH && atk.allowDualWield) {
                extraWeapon = resolved.offWeapon;
            }

            AttackActions.executeAttack(player, weapon, st, primaryTarget, tick, extraWeapon);
        }

        st.hitMemo = st.hitMemo ?? new Map();
    },

    /** Проверка — можно ли ударить данную сущность (ещё не в hitMemo) */
    canHitEntity(st, entityId) {
        if (!st?.hitMemo) return true;
        return !st.hitMemo.has(entityId);
    },

    /** Зарегистрировать удар */
    registerHit(st, entityId, tick) {
        if (!st.hitMemo) st.hitMemo = new Map();
        st.hitMemo.set(entityId, tick);
    },

    /** Очистить hitMemo */
    clearHitMemo(st) {
        if (st) {
            st.hitMemo = new Map();
        }
    }
});
