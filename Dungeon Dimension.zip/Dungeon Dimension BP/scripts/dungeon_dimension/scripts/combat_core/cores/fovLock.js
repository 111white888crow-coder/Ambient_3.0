// ═══════════════════════════════════════════════════════════
// fovLock.js — Фиксация FOV камеры во время замаха
// Предотвращает «дёрганье» при быстрых атаках
// ═══════════════════════════════════════════════════════════

import { tryOr } from "./utils/safe.js";
import { nowTick } from "./utils/time.js";
import { FOV_LOCK_DEGREES } from "./utils/constants.js";

const _untilTick = new Map();
const _isLocked = new Set();
const RELEASE_DELAY_TICKS = 3;

function _setFov(player, fovDeg) {
    tryOr(() => player.camera?.setFov?.({ fov: fovDeg }), undefined);
}

function _clearFov(player) {
    tryOr(() => player.camera?.setFov?.(), undefined);
}

export const FovLock = Object.freeze({

    /** Зафиксировать FOV до определённого тика */
    applyUntil(player, untilTick) {
        if (!player) return;
        const pid = player.id;
        const t = nowTick();

        const end = Math.max(t, Math.floor(untilTick) + RELEASE_DELAY_TICKS);
        _untilTick.set(pid, end);

        if (!_isLocked.has(pid)) {
            _isLocked.add(pid);
            _setFov(player, FOV_LOCK_DEGREES);
        } else {
            _setFov(player, FOV_LOCK_DEGREES);
        }
    },

    /** Снять фиксацию */
    clear(player) {
        if (!player) return;
        const pid = player.id;
        if (!_isLocked.has(pid)) return;

        _isLocked.delete(pid);
        _untilTick.delete(pid);
        _clearFov(player);
    },

    /** Тик-обновление */
    tickPlayer(player) {
        if (!player) return;
        const pid = player.id;
        if (!_isLocked.has(pid)) return;

        const end = _untilTick.get(pid) ?? 0;
        const t = nowTick();

        if (t >= end) {
            FovLock.clear(player);
            return;
        }

        _setFov(player, FOV_LOCK_DEGREES);
    },

    /** Активна ли фиксация */
    isLocked(player) {
        if (!player) return false;
        return _isLocked.has(player.id);
    }
});
