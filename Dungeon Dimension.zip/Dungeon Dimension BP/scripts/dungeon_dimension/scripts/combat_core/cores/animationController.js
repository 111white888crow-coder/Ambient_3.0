// ═══════════════════════════════════════════════════════════
// animationController.js — Стейт атак, анимации, комбо
// Центральный модуль управления боевыми анимациями
// ═══════════════════════════════════════════════════════════

import { world, system } from "@minecraft/server";

// ── Clash/Stagger конфиг ──
const STAGGER_DURATION_TICKS = 15;
const STAGGER_SLOWNESS_AMPLIFIER = 3;
const STAGGER_SLOWNESS_DURATION = 25;
const LONGSWORD_HEAD_ANIM_CONTROLLER = "controller.sag.combat_head";
const LONGSWORD_HEAD_LOOK_ANIMATION = "animation.longsword.head_camera";
const LONGSWORD_HEAD_CLEAR_ANIMATION = "animation.h.r2";
const LONGSWORD_ANIMATION_PREFIX = "animation.longsword.";

import {
    COMBAT_ANIM_CONTROLLER,
    COMBAT_MODE_HOLD_TICKS,
    HandType,
    HandStyle,
    MOVE_CANCEL_THRESHOLD,
    PLAYER_PROP_COMBAT_MODE,
    PLAYER_PROP_IS_ATTACKING,
    PLAYER_PROP_IS_BLOCKING,
    PRECOMBO_LOCK_EFFECT_ID,
    PRECOMBO_LOCK_AMPLIFIER,
    PRECOMBO_LOCK_SHOW_PARTICLES,
    PLAYER_TAGS,
} from "./utils/constants.js";
import { secondsToTicks, nowTick } from "./utils/time.js";
import { clamp, horizontalMag } from "./utils/math.js";
import { tryOr } from "./utils/safe.js";
import { EffectRegistry } from "./effectRegistry.js";
import { FovLock } from "./fovLock.js";
import { HitboxDamage } from "./hitboxDamage.js";
import { getAnimationForStyle, getResetAnimationForStyle } from "./itemTagRules.js";

import StaminaManager from "../../managers/StaminaManager.js";

// ── Per-player state ──
const _state = new Map();
const _queuedInputs = new Map();
const _combatModeUntilTick = new Map();

function clearHeadOverlayTimeout(st) {
    if (!st?.headOverlayClearRun) return;
    try { system.clearRun(st.headOverlayClearRun); } catch { }
    st.headOverlayClearRun = null;
}

function isLongswordAnimation(animationName) {
    return typeof animationName === "string" && animationName.startsWith(LONGSWORD_ANIMATION_PREFIX);
}

function setPlayerBoolProp(player, propId, value) {
    tryOr(() => player.setProperty(propId, value), undefined);
}

export const AnimationController = Object.freeze({

    // ══════════════════════════════
    // STATE ACCESS
    // ══════════════════════════════

    getState(player) {
        return _state.get(player.id);
    },

    getOrCreateState(playerId) {
        let st = _state.get(playerId);
        if (!st) {
            st = {
                playerId,
                weaponId: undefined,
                handType: HandType.NONE,
                handStyle: HandStyle.NONE,
                isAttacking: false,
                comboIndex: 0,
                attackStartTick: 0,
                attackEndTick: 0,
                damageStartTick: 0,
                damageEndTick: 0,
                comboOpenTick: 0,
                comboCloseTick: 0,
                lastActionTick: 0,
                fxTriggered: false,
                resetPlayed: false,
                currentAttack: null,
                isSpecial: false,
                finisherLocked: false,
                hitMemo: new Map(),
                attackUid: 0,
                damageArmed: false,
                damageArmedUntilTick: 0,
                damageRequestedUid: 0,
                primaryTargetId: null,
                _damageArmRun: null,
                nextAttackAllowedTick: 0,
                headOverlayClearRun: null,
            };
            _state.set(playerId, st);
        }
        return st;
    },

    clearState(playerId) {
        _state.delete(playerId);
        _queuedInputs.delete(playerId);
    },

    // ══════════════════════════════
    // BLOCKING
    // ══════════════════════════════

    setBlocking(player, isBlocking) {
        setPlayerBoolProp(player, PLAYER_PROP_IS_BLOCKING, isBlocking);
        if (isBlocking) {
            _combatModeUntilTick.set(player.id, nowTick() + COMBAT_MODE_HOLD_TICKS);
        }
    },

    // ══════════════════════════════
    // COMBAT MODE
    // ══════════════════════════════

    tickCombatMode(player) {
        const pid = player.id;
        const tick = nowTick();
        const st = _state.get(pid);
        const isAttacking = !!st?.isAttacking;

        if (isAttacking) {
            _combatModeUntilTick.set(pid, tick + COMBAT_MODE_HOLD_TICKS);
        }

        const until = _combatModeUntilTick.get(pid) ?? 0;
        const active = until > tick;

        setPlayerBoolProp(player, PLAYER_PROP_COMBAT_MODE, active);
        setPlayerBoolProp(player, PLAYER_PROP_IS_ATTACKING, isAttacking);

        if (!active && !isAttacking) {
            _combatModeUntilTick.delete(pid);
        }
    },

    /** Сброс при убирании оружия */
    tickNoWeapon(player) {
        EffectRegistry.end(player, PRECOMBO_LOCK_EFFECT_ID);
        FovLock.clear(player);
        AnimationController.clearLongswordHeadOverlay(player);

        const pid = player.id;
        const st = _state.get(pid);
        if (st?.isAttacking) {
            setPlayerBoolProp(player, PLAYER_PROP_IS_ATTACKING, false);
        }

        setPlayerBoolProp(player, PLAYER_PROP_IS_BLOCKING, false);
        setPlayerBoolProp(player, PLAYER_PROP_COMBAT_MODE, false);
        _combatModeUntilTick.delete(pid);

        _state.delete(pid);
        _queuedInputs.delete(pid);
    },

    // ══════════════════════════════
    // INPUT EVENTS
    // ══════════════════════════════

    bindInputEvents() {
        try {
            // Подписка на свинг (ЛКМ) — буферизация ввода
            world.afterEvents.playerSwingStart?.subscribe((ev) => {
                const player = ev.player;
                if (!player) return;
                const pid = player.id;
                const tick = nowTick();

                const q = _queuedInputs.get(pid) ?? [];
                q.push(tick);
                while (q.length > 5) q.shift(); // макс 5 в буфере
                _queuedInputs.set(pid, q);
            });

            // Очистка при выходе
            world.afterEvents.playerLeave.subscribe((ev) => {
                const pid = ev?.playerId;
                if (!pid) return;
                _state.delete(pid);
                _queuedInputs.delete(pid);
                _combatModeUntilTick.delete(pid);
            });

        } catch (e) {
            console.error("[AnimationController] Error binding inputs:", e);
        }
    },

    // ══════════════════════════════
    // MAIN TICK
    // ══════════════════════════════

    /**
     * Главный тик — проверяет конец атаки, combo window, input buffer.
     * @param {boolean} parryCounter — true если игрок в parry window
     */
    tickPlayer(player, weapon, handType, handStyle, isAttackAllowed, denyReason, parryCounter = false) {
        const pid = player.id;
        const tick = nowTick();
        const st = AnimationController.getOrCreateState(pid);

        // Обновить оружие/стиль
        if (st.weaponId !== weapon.id) {
            st.weaponId = weapon.id;
            st.comboIndex = 0;
            st.resetPlayed = false;
            st.finisherLocked = false;
        }
        st.handType = handType;
        st.handStyle = handStyle;

        // ── Проверка конца текущей атаки ──
        if (st.isAttacking) {
            if (tick >= st.attackEndTick) {
                // Атака закончена
                AnimationController.applyPostAttackEffect(player, st.currentAttack);

                const attackResetTime = st.currentAttack?.resetTime;

                st.isAttacking = false;
                st.currentAttack = null;
                setPlayerBoolProp(player, PLAYER_PROP_IS_ATTACKING, false);
                st.damageArmed = false;
                st.damageArmedUntilTick = 0;
                st.primaryTargetId = null;
                HitboxDamage.clearHitMemo(st);

                if (attackResetTime !== undefined && attackResetTime > 0) {
                    st.nextAttackAllowedTick = tick + attackResetTime;
                }

                st.finisherLocked = false;
                st.comboIndex = 0;
                st.isSpecial = false;
            } else {
                // Cancel to reset — если двигается после comboOpen
                const vel = tryOr(() => player.getVelocity(), undefined);
                const speed = horizontalMag(vel);
                if (tick >= st.comboOpenTick && speed > MOVE_CANCEL_THRESHOLD) {
                    AnimationController.cancelToReset(player, weapon, handStyle);
                }
            }
        }

        // ── Обработка input buffer ──
        const q = _queuedInputs.get(pid) ?? [];
        while (q.length > 0 && q[0] < tick - 10) q.shift(); // удалить устаревшие

        if (q.length > 0) {
            if (isAttackAllowed) {
                if (tick < st.nextAttackAllowedTick && !parryCounter) {
                    // На кулдауне — игнорируем ввод
                    q.shift();
                }
                else if (!st.isAttacking) {
                    // Не атакует — начать атаку
                    q.shift();
                    AnimationController.selectAndStartInitialAttack(player, weapon, st, parryCounter);
                }
                else if (tick >= st.comboOpenTick && tick <= st.comboCloseTick) {
                    // В combo window — продолжить цепочку

                    if (st.currentAttack?.isParry && st.currentAttack?.nextParry) {
                        // Parry chain
                        q.shift();
                        const nextParryName = st.currentAttack.nextParry;
                        const nextParryAtk = weapon.specialAttacks?.[nextParryName]
                            || weapon.attacks.find(a => a.shortName === nextParryName);
                        if (nextParryAtk) {
                            AnimationController.startSpecialAttack(player, weapon, st, nextParryAtk);
                        }
                    }
                    else if (!st.finisherLocked) {
                        // Обычное продолжение комбо
                        q.shift();
                        const nextIdx = (st.comboIndex + 1) % weapon.attacks.length;
                        if (nextIdx < weapon.combo.maxChain) {
                            AnimationController.startAttack(player, weapon, st, nextIdx);
                        }
                    }
                }
            }
        }
        _queuedInputs.set(pid, q);
    },

    // ══════════════════════════════
    // ATTACK START
    // ══════════════════════════════

    /** Начать обычную комбо-атаку по индексу */
    startAttack(player, weapon, st, idx) {
        const atk = weapon.attacks[idx];
        if (!atk) return;

        // Стамина
        StaminaManager.consumeStamina(player, 50, 'attack');

        const tick = nowTick();
        st.attackUid = (st.attackUid ?? 0) + 1;

        // Сброс damage state
        st.damageArmed = false;
        st.damageArmedUntilTick = 0;
        st.damageRequestedUid = 0;
        st.primaryTargetId = null;
        if (st._damageArmRun) {
            try { system.clearRun(st._damageArmRun); } catch { }
            st._damageArmRun = null;
        }
        st.hitMemo = new Map();

        // Установить таймлайн атаки
        st.currentAttack = atk;
        st.isSpecial = false;
        st.finisherLocked = idx >= weapon.combo.finisherIndex;
        st.isAttacking = true;
        st.comboIndex = idx;
        st.attackStartTick = tick;
        st.attackEndTick = tick + secondsToTicks(atk.duration);
        st.damageStartTick = tick + secondsToTicks(atk.damageStart);
        st.damageEndTick = tick + secondsToTicks(atk.damageEnd);
        const comboOpenTick = tick + secondsToTicks(atk.comboOpen);
        st.comboOpenTick = comboOpenTick;
        st.comboCloseTick = st.attackEndTick;

        // Pre-combo lock: slowness 255 до comboOpen
        if (st.comboOpenTick > tick) {
            EffectRegistry.applyUntil(player, PRECOMBO_LOCK_EFFECT_ID, st.comboOpenTick, {
                amplifier: PRECOMBO_LOCK_AMPLIFIER,
                showParticles: PRECOMBO_LOCK_SHOW_PARTICLES,
            });
            FovLock.applyUntil(player, st.comboOpenTick);
        }

        st.lastActionTick = tick;
        st.fxTriggered = false;
        st.resetPlayed = false;

        // Combat mode
        _combatModeUntilTick.set(player.id, tick + COMBAT_MODE_HOLD_TICKS);
        setPlayerBoolProp(player, PLAYER_PROP_COMBAT_MODE, true);
        setPlayerBoolProp(player, PLAYER_PROP_IS_ATTACKING, true);

        // Воспроизвести анимацию
        const animName = getAnimationForStyle(atk, st.handStyle) ?? atk.fullName;
        AnimationController.play(player, animName, { headOverlayDuration: atk.duration });
    },

    /**
     * Выбрать стартовую атаку.
     * Приоритет: parry > jump+sprint > fall > jump > sprint > обычная.
     */
    selectAndStartInitialAttack(player, weapon, st, parryCounter = false) {
        const vel = tryOr(() => player.getVelocity(), undefined);
        const vy = vel ? Number(vel.y ?? 0) : 0;
        const hSpeed = horizontalMag(vel);
        const isOnGround = tryOr(() => player.isOnGround, false);
        const airborne = !isOnGround && Math.abs(vy) > 0.01;
        const isSprinting = tryOr(() => player.isSprinting, false);

        // Parry counter
        if (parryCounter && weapon.specialAttacks?.parry) {
            AnimationController.startSpecialAttack(player, weapon, st, weapon.specialAttacks.parry);
            tryOr(() => player.removeTag(PLAYER_TAGS.PARRY_WINDOW), undefined);
            return;
        }
        // Jump + Sprint → jump sprint attack
        if (airborne && isSprinting && vy < -0.05 && weapon.specialAttacks?.jumpSprintAttack) {
            AnimationController.startSpecialAttack(player, weapon, st, weapon.specialAttacks.jumpSprintAttack);
            return;
        }
        // Falling → fall thrust
        if (airborne && vy < -0.05 && weapon.specialAttacks?.fallThrust) {
            AnimationController.startSpecialAttack(player, weapon, st, weapon.specialAttacks.fallThrust);
            return;
        }
        // Airborne → jump attack
        if (airborne && weapon.specialAttacks?.jumpAttack) {
            AnimationController.startSpecialAttack(player, weapon, st, weapon.specialAttacks.jumpAttack);
            return;
        }
        // Jump slash fallback
        if (airborne && weapon.specialAttacks?.jumpSlash) {
            AnimationController.startSpecialAttack(player, weapon, st, weapon.specialAttacks.jumpSlash);
            return;
        }
        // Sprint → sprint attack
        if (isOnGround && isSprinting && hSpeed > 0.1 && weapon.specialAttacks?.sprintAttack) {
            AnimationController.startSpecialAttack(player, weapon, st, weapon.specialAttacks.sprintAttack);
            return;
        }
        // По умолчанию — первая атака комбо
        AnimationController.startAttack(player, weapon, st, 0);
    },

    /** Начать специальную атаку */
    startSpecialAttack(player, weapon, st, atk) {
        // Стамина (100 для специалок)
        StaminaManager.consumeStamina(player, 100, 'attack');

        const tick = nowTick();
        st.attackUid = (st.attackUid ?? 0) + 1;
        st.damageArmed = false;
        st.damageArmedUntilTick = 0;
        st.damageRequestedUid = 0;
        st.primaryTargetId = null;
        if (st._damageArmRun) {
            try { system.clearRun(st._damageArmRun); } catch { }
            st._damageArmRun = null;
        }
        st.hitMemo = new Map();
        st.currentAttack = atk;
        st.isSpecial = true;
        st.finisherLocked = !!atk.isFinisher;
        st.comboIndex = 0;
        st.attackStartTick = tick;
        st.attackEndTick = tick + secondsToTicks(atk.duration);
        st.damageStartTick = tick + secondsToTicks(atk.damageStart);
        st.damageEndTick = tick + secondsToTicks(atk.damageEnd);
        const comboOpenTime = atk.comboOpen ?? atk.duration;
        st.comboOpenTick = tick + secondsToTicks(comboOpenTime);
        st.comboCloseTick = st.attackEndTick;

        if (st.damageStartTick > tick) {
            EffectRegistry.applyUntil(player, PRECOMBO_LOCK_EFFECT_ID, st.comboOpenTick, {
                amplifier: PRECOMBO_LOCK_AMPLIFIER,
                showParticles: PRECOMBO_LOCK_SHOW_PARTICLES,
            });
            FovLock.applyUntil(player, st.comboOpenTick);
        }

        st.lastActionTick = tick;
        st.fxTriggered = false;
        st.resetPlayed = false;
        st.isAttacking = true;

        _combatModeUntilTick.set(player.id, tick + COMBAT_MODE_HOLD_TICKS);
        setPlayerBoolProp(player, PLAYER_PROP_COMBAT_MODE, true);
        setPlayerBoolProp(player, PLAYER_PROP_IS_ATTACKING, true);

        const animName = getAnimationForStyle(atk, st.handStyle) ?? atk.fullName;
        AnimationController.play(player, animName, { headOverlayDuration: atk.duration });
    },

    // ══════════════════════════════
    // CANCEL / STOP / RESET
    // ══════════════════════════════

    /** Cancel to reset — отменить атаку движением */
    cancelToReset(player, weapon, handStyle) {
        const st = AnimationController.getOrCreateState(player.id);
        AnimationController.applyPostAttackEffect(player, st.currentAttack);
        st.isAttacking = false;
        st.comboIndex = 0;
        st.attackStartTick = 0;
        st.attackEndTick = 0;
        st.damageStartTick = 0;
        st.damageEndTick = 0;
        st.comboOpenTick = 0;
        st.comboCloseTick = 0;
        st.lastActionTick = nowTick();
        st.fxTriggered = false;
        st.currentAttack = null;
        st.isSpecial = false;
        st.finisherLocked = false;
        st.hitMemo = new Map();
        st.damageArmed = false;
        st.damageArmedUntilTick = 0;
        st.damageRequestedUid = 0;
        st.primaryTargetId = null;
        if (st._damageArmRun) {
            try { system.clearRun(st._damageArmRun); } catch { }
            st._damageArmRun = null;
        }
        EffectRegistry.end(player, PRECOMBO_LOCK_EFFECT_ID);
        FovLock.clear(player);
        setPlayerBoolProp(player, PLAYER_PROP_IS_ATTACKING, false);
        AnimationController.playReset(player, weapon, handStyle);
    },

    /** Stop attack — прерывание (clash, interrupt). Stagger. */
    stopAttack(player, weapon, handStyle, interruptLoc) {
        if (!tryOr(() => player.isValid, false)) return;

        const st = AnimationController.getOrCreateState(player.id);

        st.isAttacking = false;
        st.comboIndex = 0;
        st.attackStartTick = 0;
        st.attackEndTick = 0;
        st.damageStartTick = 0;
        st.damageEndTick = 0;
        st.comboOpenTick = 0;
        st.comboCloseTick = 0;
        st.lastActionTick = nowTick();
        st.fxTriggered = false;
        st.resetPlayed = false;
        st.currentAttack = null;
        st.isSpecial = false;
        st.finisherLocked = false;
        st.hitMemo = new Map();
        st.damageArmed = false;
        st.damageArmedUntilTick = 0;
        st.damageRequestedUid = 0;
        st.primaryTargetId = null;
        if (st._damageArmRun) {
            try { system.clearRun(st._damageArmRun); } catch { }
            st._damageArmRun = null;
        }

        EffectRegistry.end(player, PRECOMBO_LOCK_EFFECT_ID);
        FovLock.clear(player);
        setPlayerBoolProp(player, PLAYER_PROP_IS_ATTACKING, false);

        // Reset-анимация
        AnimationController.playReset(player, weapon, handStyle);

        // Stagger
        const tick = nowTick();
        st.nextAttackAllowedTick = tick + STAGGER_DURATION_TICKS;

        EffectRegistry.applyUntil(player, "slowness", tick + STAGGER_SLOWNESS_DURATION, {
            amplifier: STAGGER_SLOWNESS_AMPLIFIER,
            showParticles: false,
        });

        // Эффекты clash/interrupt
        if (interruptLoc) {
            tryOr(() => {
                const dim = player.dimension;
                dim.playSound("random.anvil_land", interruptLoc, {
                    pitch: 1.8 + Math.random() * 0.4,
                    volume: 0.7,
                });
                dim.spawnParticle("sag:knockback_roar2_particle", interruptLoc);
            }, undefined);
        }
    },

    // ══════════════════════════════
    // ANIMATION PLAYBACK
    // ══════════════════════════════

    /** Воспроизвести reset-анимацию */
    playReset(player, weapon, handStyle) {
        const st = AnimationController.getOrCreateState(player.id);
        if (st.resetPlayed && st.weaponId === weapon.id) return;
        const resetAnim = getResetAnimationForStyle(weapon, handStyle);
        if (!resetAnim) return;
        st.resetPlayed = true;
        AnimationController.play(player, resetAnim, { headOverlayDuration: 0.5 });
    },

    /** Применить пост-атакующий эффект */
    applyPostAttackEffect(player, attack) {
        const effect = attack?.postAttackEffect;
        if (!effect?.effectId) return;
        tryOr(() => {
            player.addEffect(effect.effectId, secondsToTicks(effect.duration ?? 1), {
                amplifier: effect.amplifier ?? 0,
                showParticles: effect.showParticles ?? false,
            });
        }, undefined);
    },

    clearLongswordHeadOverlay(player) {
        const st = _state.get(player.id);
        if (st) {
            clearHeadOverlayTimeout(st);
        }

        if (!tryOr(() => player.isValid, false)) return;

        tryOr(() => player.playAnimation(LONGSWORD_HEAD_CLEAR_ANIMATION, {
            controller: LONGSWORD_HEAD_ANIM_CONTROLLER,
            blendInTime: 0,
            blendOutTime: 0.05
        }), undefined);
    },

    syncLongswordHeadOverlay(player, durationSeconds = 0) {
        const st = AnimationController.getOrCreateState(player.id);
        clearHeadOverlayTimeout(st);

        tryOr(() => player.playAnimation(LONGSWORD_HEAD_LOOK_ANIMATION, {
            controller: LONGSWORD_HEAD_ANIM_CONTROLLER,
            blendInTime: 0,
            blendOutTime: 0
        }), undefined);

        const durationTicks = Math.max(1, secondsToTicks(Math.max(Number(durationSeconds) || 0, 0.05)));
        st.headOverlayClearRun = system.runTimeout(() => {
            const activeState = _state.get(player.id);
            if (activeState) {
                activeState.headOverlayClearRun = null;
            }

            if (!tryOr(() => player.isValid, false)) return;
            AnimationController.clearLongswordHeadOverlay(player);
        }, durationTicks);
    },

    /** Воспроизвести анимацию через controller */
    play(player, animationName, options = {}) {
        tryOr(() => player.playAnimation(animationName, {
            controller: COMBAT_ANIM_CONTROLLER,
            blendInTime: 0,
            blendOutTime: 0
        }), undefined);

        if (isLongswordAnimation(animationName)) {
            AnimationController.syncLongswordHeadOverlay(player, options.headOverlayDuration);
            return;
        }

        AnimationController.clearLongswordHeadOverlay(player);
    },

    /** Получить текущее боевое окно игрока (для внешних систем) */
    getPlayerCombatWindow(player) {
        const st = _state.get(player.id);
        if (!st) return { isAttacking: false, damageOpen: false, comboIndex: 0, weaponId: undefined };
        const t = nowTick();
        const damageOpen = st.isAttacking && t >= st.damageStartTick && t <= st.damageEndTick;
        return { isAttacking: st.isAttacking, damageOpen, comboIndex: st.comboIndex, weaponId: st.weaponId };
    },
});
