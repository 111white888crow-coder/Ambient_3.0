// ═══════════════════════════════════════════════════════════
// combatSystem.js — Главный тик-лупер боевой системы
// Инициализация всех подсистем + per-player tick
// ═══════════════════════════════════════════════════════════

import { world, system } from "@minecraft/server";
import { resolveWeaponForPlayer } from "./itemTagRules.js";
import { AnimationController } from "./animationController.js";
import { DamageSystem } from "./damageSystem.js";
import { DamageManager } from "./damageManager.js";
import { EffectRegistry } from "./effectRegistry.js";
import { PostureManager } from "./postureManager.js";
import { FovLock } from "./fovLock.js";
import {
    initBlockingSystem,
    tickBlockingSystem,
    isPlayerBlocking,
    canPerformParryCounter,
    resetBlockState
} from "./blockingSystem.js";
import { tryOr } from "./utils/safe.js";

export const CombatSystem = {
    _initialized: false,

    /**
     * Инициализировать всю боевую систему.
     * Вызывается один раз при старте.
     */
    init() {
        if (CombatSystem._initialized) return;
        CombatSystem._initialized = true;

        // 1. Input events (playerSwingStart)
        AnimationController.bindInputEvents();

        // 2. Damage interception (entityHurt)
        DamageSystem.bind();

        // 3. Hit arming (entityHitEntity/Block)
        DamageManager.init();

        // 4. Effect management
        EffectRegistry.init();

        // 5. Blocking system (itemUse/itemStopUse)
        initBlockingSystem();

        // 6. Main tick loop
        system.runInterval(() => {
            try {
                const currentTick = system.currentTick;

                for (const player of world.getAllPlayers()) {
                    if (!player || !tryOr(() => player.isValid, false)) continue;

                    try {
                        CombatSystem._tickPlayer(player, currentTick);
                    } catch { }
                }
            } catch { }
        }, 1);

        console.log("[CombatSystem] Initialized — all subsystems active");
    },

    /**
     * Per-player tick — ядро.
     * Обрабатывает: resolve → blocking → posture → animation → damage → fov → effects → combatMode
     */
    _tickPlayer(player, currentTick) {
        const resolved = resolveWeaponForPlayer(player);

        // Нет оружия — сброс
        if (!resolved.weapon) {
            AnimationController.tickNoWeapon(player);
            EffectRegistry.tickPlayer(player);
            AnimationController.tickCombatMode(player);
            return;
        }

        // 1. Блокирование
        tickBlockingSystem(player);
        const blocking = isPlayerBlocking(player);

        // 2. Стойкость (не регенить во время атаки/блока)
        PostureManager.tickPlayer(player, blocking || CombatSystem.isPlayerAttacking(player));

        // 3. Parry counter check
        const parryCounter = canPerformParryCounter(player);

        // 4. Animation controller tick (combo, input buffer, attack lifecycle)
        AnimationController.tickPlayer(
            player,
            resolved.weapon,
            resolved.handType,
            resolved.handStyle,
            resolved.isAttackAllowed && !blocking,
            resolved.denyReason,
            parryCounter
        );

        // 5. Damage manager tick (arm/disarm, hitbox damage)
        const st = AnimationController.getState(player);
        DamageManager.tickPlayer(player, resolved.weapon, st, currentTick);

        // 6. FOV lock
        FovLock.tickPlayer(player);

        // 7. Effect registry (expire timers)
        EffectRegistry.tickPlayer(player);

        // 8. Combat mode (entity properties)
        AnimationController.tickCombatMode(player);
    },

    // ══════════════════════════════
    // PUBLIC API
    // ══════════════════════════════

    /** Полный сброс игрока */
    resetPlayer(player) {
        DamageManager.reset(player);
        AnimationController.clearState(player.id);
        FovLock.clear(player);
        resetBlockState(player);
    },

    /** Получить combat state игрока */
    getPlayerState(player) {
        return AnimationController.getState(player);
    },

    /** Атакует ли игрок сейчас */
    isPlayerAttacking(player) {
        const st = AnimationController.getState(player);
        return !!st?.isAttacking;
    },

    /** Открыто ли damage window */
    isDamageWindowOpen(player) {
        const st = AnimationController.getState(player);
        if (!st?.isAttacking) return false;

        const tick = system.currentTick;
        return tick >= Number(st.damageStartTick ?? 0) &&
            tick <= Number(st.damageEndTick ?? 0);
    },

    /** Блокирует ли игрок */
    isPlayerBlocking(player) {
        return isPlayerBlocking(player);
    },

    /** Может ли выполнить parry counter */
    canPlayerParryCounter(player) {
        return canPerformParryCounter(player);
    }
};
