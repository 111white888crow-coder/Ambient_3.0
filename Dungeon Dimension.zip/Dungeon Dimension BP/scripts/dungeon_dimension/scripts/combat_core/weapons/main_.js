// scripts/combat_core/weapons/main_.js
// ⚠ DEPRECATED — используй combat_core/index.js
// Файл оставлен для совместимости
