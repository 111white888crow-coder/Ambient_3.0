// ═══════════════════════════════════════════════════════════
// longsword.js — Конфигурация оружия Longsword (все материалы)
// Wooden → Stone → Iron → Golden → Diamond → Netherite
// ═══════════════════════════════════════════════════════════

import { HandStyle } from "../cores/utils/constants.js";

// ── Helper: создать атаку с animations map ──
function createAttack(base, animations) {
    return {
        ...base,
        animations: animations
    };
}

// ── Стандартные animations для longsword по HandStyle ──
function lsAnims(name) {
    return {
        [HandStyle.RIGHT]: `animation.longsword.${name}`,
        [HandStyle.LEFT]: `animation.longsword.${name}.left`,
        [HandStyle.BOTH]: `animation.longsword.${name}.style`,
        [HandStyle.SHIELD_RIGHT]: `animation.longsword.shield.right.${name}`,
        [HandStyle.SHIELD_LEFT]: `animation.longsword.shield.left.${name}`,
    };
}

// ═══ Базовый шаблон longsword (все варианты наследуют) ═══
function createLongswordConfig(id, damage, criticalMultiplier = 1.2) {
    return {
        id,
        tag: "sag:any_hand",
        weaponType: "weaponType:is_longsword",

        damage,
        criticalMultiplier,

        // ── Комбо ──
        combo: {
            windowTime: 18,       // тиков на следующий удар
            maxChain: 4,          // макс ударов
            resetTime: 30,        // КД после финишера
            finisherIndex: 3,     // индекс финишера
        },

        // ── Блокирование ──
        blocking: {
            enabled: true,
            blockAnims: {
                [HandStyle.RIGHT]: "animation.longsword.block",
                [HandStyle.LEFT]: "animation.longsword.block.left",
                [HandStyle.BOTH]: "animation.longsword.block.style",
                [HandStyle.SHIELD_RIGHT]: "animation.longsword.shield.right.block",
                [HandStyle.SHIELD_LEFT]: "animation.longsword.shield.left.block",
            },
            blockMoveAnims: {
                [HandStyle.RIGHT]: "animation.longsword.block_move",
                [HandStyle.LEFT]: "animation.longsword.block_move.left",
                [HandStyle.BOTH]: "animation.longsword.block_move.style",
                [HandStyle.SHIELD_RIGHT]: "animation.longsword.shield.right.block_move",
                [HandStyle.SHIELD_LEFT]: "animation.longsword.shield.left.block_move",
            },
            postureCost: 4,
            blockAngle: 90,
        },

        // ── Reset анимации ──
        reset: {
            [HandStyle.RIGHT]: {
                shortName: "ls_reset",
                fullName: "animation.longsword.reset",
                duration: 0.5,
            },
            [HandStyle.LEFT]: {
                shortName: "ls_reset_left",
                fullName: "animation.longsword.reset.left",
                duration: 0.5,
            },
            [HandStyle.BOTH]: {
                shortName: "ls_reset_style",
                fullName: "animation.longsword.reset.style",
                duration: 0.5,
            },
            [HandStyle.SHIELD_RIGHT]: {
                shortName: "ls_reset",
                fullName: "animation.longsword.reset",
                duration: 0.5,
            },
            [HandStyle.SHIELD_LEFT]: {
                shortName: "ls_reset_left",
                fullName: "animation.longsword.reset.left",
                duration: 0.5,
            },
        },

        // ══════════════════════════════════════
        // КОМБО АТАКИ (4 удара)
        // ══════════════════════════════════════
        attacks: [
            // Атака 0: Горизонтальный sweep справа
            createAttack({
                shortName: "ls_attack0",
                duration: 2.1,
                damageStart: 0.2,
                damageEnd: 0.6,
                comboOpen: 0.7,
                attackKind: "slash_right",
                damageMultiplier: 1.0,
                secondaryDamageMultiplier: 1.0,
                hitbox: {
                    radius: 3.5,
                    arcDeg: 120,
                    height: 2.0,
                },
                splashSound: "entity.player.attack.sweep",
                splashParticle: "sag:sweep_particle",
                allowDualWield: true,
            }, lsAnims("attack_start")),

            // Атака 1: Горизонтальный sweep слева
            createAttack({
                shortName: "ls_attack1",
                duration: 2.2,
                damageStart: 0.4,
                damageEnd: 0.7,
                comboOpen: 0.8,
                attackKind: "slash_left",
                damageMultiplier: 1.0,
                secondaryDamageMultiplier: 1.0,
                hitbox: {
                    radius: 3.5,
                    arcDeg: 120,
                    height: 2.0,
                },
                splashSound: "entity.player.attack.sweep",
                splashParticle: "sag:sweep_particle",
                allowDualWield: true,
            }, lsAnims("attack1")),

            // Атака 2: Укол вперёд (thrust)
            createAttack({
                shortName: "ls_attack2",
                duration: 2.5,
                damageStart: 0.6,
                damageEnd: 1.0,
                comboOpen: 1.1,
                attackKind: "thrust",
                damageMultiplier: 1.0,
                secondaryDamageMultiplier: 1.0,
                hitbox: {
                    forward: 3.5,
                    side: 1.2,
                    height: 2.0,
                },
                splashSound: "entity.player.attack.sweep",
                splashParticle: "sag:sweep_particle",
                allowDualWield: true,
            }, lsAnims("attack2")),

            // Атака 3: AOE Spin (финишер)
            createAttack({
                shortName: "ls_attack3",
                duration: 1.4,
                damageStart: 0.4,
                damageEnd: 0.7,
                comboOpen: 0.7,
                attackKind: "aoe_spin",
                damageMultiplier: 1.0,
                secondaryDamageMultiplier: 1.0,
                hitbox: {
                    radius: 3.0,
                    arcDeg: 360,
                    height: 2.0,
                    rotations: 1,
                },
                splashSound: "entity.player.attack.sweep",
                splashParticle: "sag:sweep_particle",
                allowDualWield: true,
            }, lsAnims("attack3")),
        ],

        // ══════════════════════════════════════
        // СПЕЦИАЛЬНЫЕ АТАКИ
        // ══════════════════════════════════════
        specialAttacks: {
            // Sprint attack — укол на бегу
            sprintAttack: createAttack({
                shortName: "ls_sprint_attack",
                duration: 2.2,
                damageStart: 0.3,
                damageEnd: 0.9,
                comboOpen: 1.0,
                attackKind: "thrust",
                damageMultiplier: 1.2,
                postAttackEffect: {
                    effectId: "slowness",
                    amplifier: 1,
                    duration: 0.5,
                },
                hitbox: {
                    forward: 3.5,
                    side: 1.5,
                    height: 2.0,
                },
                splashSound: "entity.player.attack.sweep",
                splashParticle: "sag:sweep_particle",
            }, lsAnims("sprint_attack")),

            // Jump attack — удар в прыжке
            jumpAttack: createAttack({
                shortName: "ls_jump_attack",
                duration: 2.1,
                damageStart: 0.3,
                damageEnd: 0.9,
                comboOpen: 1.0,
                attackKind: "fall_thrust",
                damageMultiplier: 1.5,
                postAttackEffect: {
                    effectId: "slowness",
                    amplifier: 1,
                    duration: 0.5,
                },
                hitbox: {
                    forward: 3.0,
                    side: 1.6,
                    height: 3.5,
                },
                splashSound: "entity.player.attack.sweep",
                splashParticle: "sag:sweep_particle",
                allowDualWield: true,
            }, lsAnims("jump_attack")),

            // Jump + Sprint attack
            jumpSprintAttack: createAttack({
                shortName: "ls_jump_sprint_attack",
                duration: 1.9,
                damageStart: 0.3,
                damageEnd: 0.9,
                comboOpen: 1.0,
                attackKind: "fall_thrust",
                damageMultiplier: 1.5,
                postAttackEffect: {
                    effectId: "slowness",
                    amplifier: 2,
                    duration: 0.6,
                },
                hitbox: {
                    forward: 3.0,
                    side: 1.6,
                    height: 4.0,
                },
                splashSound: "entity.player.attack.strong",
                splashParticle: "sag:sweep_particle",
            }, lsAnims("jump_sprint_attack")),

            // Парирование — контратака 1
            parry: createAttack({
                shortName: "ls_parry",
                duration: 3.0,
                damageStart: 0.1,
                damageEnd: 0.8,
                comboOpen: 0.9,
                attackKind: "slash_right",
                damageMultiplier: 1.4,
                postAttackEffect: {
                    effectId: "slowness",
                    amplifier: 1,
                    duration: 0.4,
                },
                hitbox: {
                    radius: 3.5,
                    arcDeg: 100,
                    height: 2.0,
                },
                splashSound: "entity.player.attack.sweep",
                splashParticle: "sag:sweep_particle",
                isParry: true,
                nextParry: "parry2",
            }, lsAnims("parry")),

            // Парирование — контратака 2
            parry2: createAttack({
                shortName: "ls_parry2",
                duration: 3.0,
                damageStart: 0.1,
                damageEnd: 0.8,
                comboOpen: 0.9,
                attackKind: "slash_left",
                damageMultiplier: 1.4,
                postAttackEffect: {
                    effectId: "slowness",
                    amplifier: 1,
                    duration: 0.4,
                },
                hitbox: {
                    radius: 3.5,
                    arcDeg: 100,
                    height: 2.0,
                },
                splashSound: "entity.player.attack.sweep",
                splashParticle: "sag:sweep_particle",
                isParry: true,
            }, lsAnims("parry2")),

            // Lunge — выпад вперёд с импульсом
            lunge: createAttack({
                shortName: "ls_lunge",
                duration: 1.8,
                damageStart: 0.2,
                damageEnd: 0.6,
                comboOpen: 0.7,
                attackKind: "thrust",
                damageMultiplier: 1.6,
                impulse: {
                    forward: 0.8,
                    up: 0.1,
                },
                hitbox: {
                    forward: 4.5,
                    side: 1.0,
                    height: 2.0,
                },
                splashSound: "entity.player.attack.strong",
                splashParticle: "sag:sweep_particle",
            }, lsAnims("lunge")),
        },
    };
}

// ═══ Все варианты longsword ═══

export const WoodenLongsword = createLongswordConfig("sag:wooden_longsword", 4);
export const StoneLongsword = createLongswordConfig("sag:stone_longsword", 5);
export const CopperLongsword = createLongswordConfig("sag:copper_longsword", 4.5);
export const IronLongsword = createLongswordConfig("sag:iron_longsword", 6);
export const GoldenLongsword = createLongswordConfig("sag:golden_longsword", 4, 1.3);
export const DiamondLongsword = createLongswordConfig("sag:diamond_longsword", 7);
export const NetheriteLongsword = createLongswordConfig("sag:netherite_longsword", 8);
export const ExcaliburLongsword = createLongswordConfig("sag:excalibur_longsword", 10, 1.4);