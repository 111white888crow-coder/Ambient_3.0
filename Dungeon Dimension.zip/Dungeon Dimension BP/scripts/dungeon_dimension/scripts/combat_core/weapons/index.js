// ═══════════════════════════════════════════════════════════
// weapons/index.js — Регистрация всех оружий
// ═══════════════════════════════════════════════════════════

import { WeaponRegistry } from "../cores/weaponRegistry.js";
import {
    WoodenLongsword,
    StoneLongsword,
    CopperLongsword,
    IronLongsword,
    GoldenLongsword,
    DiamondLongsword,
    NetheriteLongsword,
    ExcaliburLongsword,
} from "./longsword.js";

/**
 * Зарегистрировать все оружия в WeaponRegistry.
 * Вызывается при инициализации боевой системы.
 */
export function registerWeapons() {
    // ── Longswords ──
    WeaponRegistry.register(WoodenLongsword);
    WeaponRegistry.register(StoneLongsword);
    WeaponRegistry.register(CopperLongsword);
    WeaponRegistry.register(IronLongsword);
    WeaponRegistry.register(GoldenLongsword);
    WeaponRegistry.register(DiamondLongsword);
    WeaponRegistry.register(NetheriteLongsword);
    WeaponRegistry.register(ExcaliburLongsword);

    console.log(`[WeaponRegistry] Registered ${WeaponRegistry.listIds().length} weapons:`,
        WeaponRegistry.listIds().join(", "));
}
