// ═══════════════════════════════════════════════════════════
// combat_core/index.js — Единая точка входа боевой системы
// ═══════════════════════════════════════════════════════════

import { registerWeapons } from "./weapons/index.js";
import { CombatSystem } from "./cores/combatSystem.js";

// Загрузить proxy system (self-initializing)
import "./cores/proxySystem.js";

// 1. Зарегистрировать все оружия
registerWeapons();

// 2. Инициализировать боевую систему
CombatSystem.init();

console.log("[CombatCore] ══════════════════════════════════════");
console.log("[CombatCore] ✦ Combat System fully initialized ✦");
console.log("[CombatCore] ══════════════════════════════════════");

// Экспорт для внешних модулей
export { CombatSystem };
export { WeaponRegistry } from "./cores/weaponRegistry.js";
export { AnimationController } from "./cores/animationController.js";
