//scripts/combat_core/managers/main_.js
// ⚠ DEPRECATED — управление встроено в AnimationController
