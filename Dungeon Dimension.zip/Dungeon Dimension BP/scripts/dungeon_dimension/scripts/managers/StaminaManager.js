import { world, system } from '@minecraft/server';

class StaminaManager {
  constructor() {
    this.maxStamina = 1000;
    this.baseRegenDelay = 20;

    this.playerData = new Map();

    this.BASE_COSTS = {
      SLIDE_START: 10,

      SLIDE_DRAIN_RATE: 10,
      ROLL_USE: 150,
      ATTACK_LIGHT: 50,
      ATTACK_HEAVY: 100
    };

    this.REDUCTION_RATES = {
      SLIDE_DRAIN_RATE: 0.5
    };

    this.MIN_COSTS = {
      SLIDE_START: 10,
      SLIDE_DRAIN_RATE: 5
    };

    this.initializeSystem();
  }

  getRegenPerTick(playerLevel) {
    if (playerLevel >= 40) return 25;
    if (playerLevel >= 30) return 12.5;
    if (playerLevel >= 20) return 8.3;
    if (playerLevel >= 10) return 6.25;
    return 5;
  }

  initializeSystem() {
    world.afterEvents.entityDie.subscribe((event) => {
      if (event.deadEntity.typeId === 'minecraft:player') {
        const player = event.deadEntity;
        this.stopStaminaRegeneration(player);
      }
    });

    world.afterEvents.playerSpawn.subscribe((event) => {
      if (!event.initialSpawn) {
        this.resetPlayerStamina(event.player);
      }
    });

    world.afterEvents.playerLeave.subscribe((event) => {
      this.clearPlayerStaminaState(event.playerName);
    });

    system.runInterval(() => {
      for (const player of world.getAllPlayers()) {
        if (!player.isValid) continue;
        this.tickPlayer(player);
      }
    }, 1);
  }

  tickPlayer(player) {
    const data = this.getPlayerData(player.name);
    const { state } = data;
    let { stamina } = data;

    this.checkSleepStatus(player, state);

    if (state.isDraining && stamina > 0) {
      const costType = state.moveType.toUpperCase() + '_DRAIN_RATE';

      const adjustedDrainRate = this.getAdjustedCost(player, state.drainRate, costType);

      stamina -= adjustedDrainRate;
      if (stamina <= 0) {
        stamina = 0;
        this.stopContinuousDrain(player);
      }
      this.setStamina(player, stamina);
    }

    else if (!state.isDraining && stamina < this.maxStamina) {
      const timeSinceMove = system.currentTick - (state.lastMoveEnd || 0);

      if (timeSinceMove >= this.baseRegenDelay) {

        let amount = this.getRegenPerTick(player.level || 0);

        if (state.isSleeping) amount *= 2;

        try {
          if (player.getProperty("sag:is_blocking")) {
            amount /= 5;
          }
        } catch (e) { }

        stamina = Math.min(this.maxStamina, stamina + amount);
        this.setStamina(player, stamina);
      }
    }

    const displayVal = Math.round(stamina);
    player.onScreenDisplay.setTitle(`stamina:${displayVal}`);
  }

  checkSleepStatus(player, state) {
    try {
      state.isSleeping = player.isSleeping;
    } catch {
      state.isSleeping = false;
    }
  }

  getAdjustedCost(player, baseCost, costType) {
    const level = player.level || 0;
    const reductionRate = this.REDUCTION_RATES[costType] || 0;
    const minCost = this.MIN_COSTS[costType] ?? 0;
    const totalReduction = level * reductionRate;
    return Math.max(minCost, baseCost - totalReduction);
  }

  getPlayerData(playerName) {
    if (!this.playerData.has(playerName)) {
      this.playerData.set(playerName, {
        stamina: this.maxStamina,
        state: {
          isDraining: false, drainRate: 0, moveType: null, lastMoveEnd: 0,
          isSleeping: false
        }
      });
    }
    return this.playerData.get(playerName);
  }

  getStamina(player) {
    return this.getPlayerData(player.name).stamina;
  }

  setStamina(player, value) {

    const clamped = Math.max(0, Math.min(this.maxStamina, value));
    this.getPlayerData(player.name).stamina = clamped;

    try {
      player.setDynamicProperty('parkour_stamina', clamped);
    } catch (e) { }
  }

  initializePlayerStamina(player) {
    let stamina = this.maxStamina;
    try {
      const saved = player.getDynamicProperty('parkour_stamina');
      if (saved !== undefined) stamina = saved;
    } catch (e) { }
    this.getPlayerData(player.name).stamina = stamina;
  }

  hasEnoughStamina(player, requiredStamina, costType = null) {
    const adjustedCost = costType ? this.getAdjustedCost(player, requiredStamina, costType) : requiredStamina;
    return this.getStamina(player) >= adjustedCost;
  }

  consumeStamina(player, amount, moveType = 'instant') {
    const costType = moveType.toUpperCase();
    const adjusted = this.getAdjustedCost(player, amount, costType);
    const cur = this.getStamina(player);

    if (cur < adjusted) return false;

    this.setStamina(player, cur - adjusted);

    if (moveType === 'instant' || moveType === 'slide_start' || moveType === 'roll_use' || moveType === 'attack') {
      this.getPlayerData(player.name).state.lastMoveEnd = system.currentTick;
    }
    return true;
  }

  startContinuousDrain(player, drainRate, moveType) {
    if (this.getStamina(player) <= 0) return false;
    const state = this.getPlayerData(player.name).state;
    state.isDraining = true;
    state.drainRate = drainRate;
    state.moveType = moveType;
    return true;
  }

  stopContinuousDrain(player) {
    const state = this.getPlayerData(player.name).state;
    state.lastMoveEnd = system.currentTick;
    state.isDraining = false;
    state.drainRate = 0;
    state.moveType = null;
  }

  clearPlayerStaminaState(playerName) {
    this.playerData.delete(playerName);
  }

  resetPlayerStamina(player) {
    this.setStamina(player, this.maxStamina);
  }

  stopStaminaRegeneration(player) {
    const state = this.getPlayerData(player.name).state;
    state.isDraining = false;
    state.drainRate = 0;
    state.moveType = null;
    state.lastMoveEnd = system.currentTick + 999999;
  }

  get STAMINA_COSTS() {
    return { ...this.BASE_COSTS };
  }
}

export default new StaminaManager();
