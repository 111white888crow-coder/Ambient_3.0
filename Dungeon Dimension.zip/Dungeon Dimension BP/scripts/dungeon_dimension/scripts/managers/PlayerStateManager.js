import { world, system } from '@minecraft/server';

class PlayerStateManager {
  constructor() {
    this.states = new Map();
    world.afterEvents.playerSpawn.subscribe((e) => {
      const name = e.player.name;
      if (!this.states.has(name)) this.initializePlayer(name);
    });
    world.afterEvents.playerLeave.subscribe((e) => this.clearPlayerStates(e.playerName));
  }

  getState(playerName) {
    if (!this.states.has(playerName)) this.initializePlayer(playerName);
    return this.states.get(playerName);
  }

  initializePlayer(playerName) {
    const initial = {
      slide: {

        wasSprintingFirst: false,
        lastSprintTime: 0,

        isSliding: false,
        startTime: 0,
        slideInfo: null,
        currentAnimation: null,

        lastSprintLocation: null,
        sprintDistance: 0,
        sprintEndTime: null
      }
    };
    this.states.set(playerName, initial);
  }

  setSlideState(playerName, slideInfo) {
    const s = this.getState(playerName);
    s.slide.isSliding = true;
    s.slide.startTime = system.currentTick;
    s.slide.slideInfo = slideInfo;
    s.slide.currentAnimation = slideInfo.currentAnimation ?? null;
  }

  clearSlideState(playerName, currentTick) {
    const s = this.getState(playerName);
    s.slide.isSliding = false;
    s.slide.slideInfo = null;
  }

  clearPlayerStates(playerName) {
    this.states.delete(playerName);
  }
}

export default new PlayerStateManager();
