import { system } from '@minecraft/server';
import { getCachedBlock, clearBlockCache } from './blockCache.js';

class BlockScanner {
  constructor() {
    this.scanCache = new Map();
    this.comprehensiveCache = new Map();
    this.lastComprehensiveScan = new Map();
    this.FORWARD_DISTANCE = 0.1;
    this.CACHE_LIFETIME = 1;
  }

  getPlayerScan(player, currentTick) {
    const cacheKey = player.name;

    if (this.lastComprehensiveScan.get(cacheKey) === currentTick) {
      return this.comprehensiveCache.get(cacheKey);
    }

    const comprehensiveScan = this.scan(player, {
      checkGround: true,
      checkObstacles: true,
      checkCeiling: true,
      checkWalls: true,
      checkGap: true,
      usePlayerForward: true
    });

    comprehensiveScan.heightAboveGround = comprehensiveScan.ground.distance;
    comprehensiveScan.wallSide = comprehensiveScan.walls.left ? "left" : comprehensiveScan.walls.right ? "right" : null;
    comprehensiveScan.canCrawl = this.checkBlockGap(player, false);
    comprehensiveScan.vaultCheck = this.checkVaultBlock(player);
    comprehensiveScan.isOnGround = comprehensiveScan.heightAboveGround;
    comprehensiveScan.hasWall = comprehensiveScan.wallSide !== null;
    comprehensiveScan.canSlide = comprehensiveScan.blockGap.exists && !comprehensiveScan.hasObstacle;

    this.comprehensiveCache.set(cacheKey, comprehensiveScan);
    this.lastComprehensiveScan.set(cacheKey, currentTick);

    return comprehensiveScan;
  }

  scan(player, options = {}) {
    const currentTick = system.currentTick;
    const { location, dimension } = player;
    const { x, y, z } = location;

    const opts = {
      checkGround: true,
      checkObstacles: true,
      checkCeiling: false,
      checkWalls: false,
      checkGap: false,
      usePlayerForward: false,
      ...options
    };

    const cacheKey = `${player.name}:${Math.floor(x)},${Math.floor(y)},${Math.floor(z)}:${JSON.stringify(opts)}`;
    const cached = this.scanCache.get(cacheKey);
    if (cached && currentTick - cached.timestamp < this.CACHE_LIFETIME) {
      return cached.result;
    }

    const result = {
      ground: { block: undefined, distance: Infinity },
      isInLiquid: false,
      hasObstacle: false,
      walls: { left: null, right: null },
      ceiling: { block: null, distance: Infinity, hasBlock: false },
      blockGap: { exists: false, rollExists: false },
      movementDirection: { x: 0, z: 0, hasInput: false }
    };

    const currentBlock = getCachedBlock(dimension, {
      x: Math.floor(x),
      y: Math.floor(y),
      z: Math.floor(z)
    });
    result.isInLiquid = currentBlock?.isLiquid || false;

    const offsets = [-0.29, 0, 0.29];

    let yawRad, vectorMoveRot = { x: 0, z: 0 }, hasInput = false;
    if (opts.checkObstacles || opts.checkWalls || opts.checkGap || opts.usePlayerForward) {
      const { y: yaw } = player.getRotation();
      yawRad = (yaw + 90) * Math.PI / 180;

      const inputVector = player.inputInfo?.getMovementVector() || { x: 0, y: 1 };
      const bodyRot = player.getRotation();
      const rad = bodyRot.y * (Math.PI / 180);
      const cosA = Math.cos(rad);
      const sinA = Math.sin(rad);

      vectorMoveRot = {
        x: inputVector.x * cosA - inputVector.y * sinA,
        z: inputVector.x * sinA + inputVector.y * cosA
      };

      hasInput = inputVector.x !== 0 || inputVector.y !== 0;
      result.movementDirection = { x: vectorMoveRot.x, z: vectorMoveRot.z, hasInput };
    }

    if (opts.checkGround) {
      for (const dx of offsets) {
        for (const dz of offsets) {
          const checkPos = { x: x + dx, y, z: z + dz };
          const downRay = dimension.getBlockFromRay(
            checkPos, { x: 0, y: -1, z: 0 },
            { maxDistance: 2, includePassableBlocks: false, includeLiquidBlocks: false }
          );

          if (downRay?.block && !downRay.block.isAir && !downRay.block.isLiquid) {
            const distance = y - (downRay.block.location.y + downRay.faceLocation.y);
            if (distance >= 0 && distance < result.ground.distance) {
              result.ground.distance = distance;
              result.ground.block = downRay.block;
            }
          }
        }
      }
    }

    if (opts.checkObstacles) {
      const yLevels = [0.1, 0.2, 0.3, 0.4, 0.5];
      let rayDirectionX, rayDirectionZ;

      if (hasInput) {
        const magnitude = Math.sqrt(vectorMoveRot.x * vectorMoveRot.x + vectorMoveRot.z * vectorMoveRot.z);
        if (magnitude > 0) {
          rayDirectionX = vectorMoveRot.x / magnitude;
          rayDirectionZ = vectorMoveRot.z / magnitude;
        } else {
          rayDirectionX = Math.cos(yawRad);
          rayDirectionZ = Math.sin(yawRad);
        }
      } else {
        rayDirectionX = Math.cos(yawRad);
        rayDirectionZ = Math.sin(yawRad);
      }

      for (const dx of offsets) {
        for (const dz of offsets) {
          for (const yOffset of yLevels) {
            const obstaclePos = { x: x + dx, y: y + yOffset, z: z + dz };
            const obstacleRay = dimension.getBlockFromRay(
              obstaclePos, { x: rayDirectionX, y: 0, z: rayDirectionZ },
              { maxDistance: 1.0, includePassableBlocks: false, includeLiquidBlocks: false }
            );

            if (obstacleRay && !obstacleRay.block.isAir && !obstacleRay.block.isLiquid) {
              result.hasObstacle = true;
              result.obstacle = {
                block: obstacleRay.block,
                distance: obstacleRay.distance,
                detectedAt: yOffset,
                detectionMethod: hasInput ? 'movement_direction' : 'view_direction'
              };
              break;
            }
          }
          if (result.hasObstacle) break;
        }
        if (result.hasObstacle) break;
      }
    }

    if (opts.checkCeiling) {
      for (const dx of offsets) {
        for (const dz of offsets) {
          const ceilingPos = { x: x + dx, y: y + 1.8, z: z + dz };
          const upRay = dimension.getBlockFromRay(
            ceilingPos, { x: 0, y: 1, z: 0 },
            { maxDistance: 1, includePassableBlocks: false, includeLiquidBlocks: false }
          );

          if (upRay?.block && !upRay.block.isAir && !upRay.block.isLiquid) {
            const distance = (upRay.block.location.y + upRay.faceLocation.y) - (y + 1.8);
            if (distance >= 0 && distance < result.ceiling.distance) {
              result.ceiling.distance = distance;
              result.ceiling.block = upRay.block;
              result.ceiling.hasBlock = true;
            }
          }
        }
      }
    }

    if (opts.checkWalls) {
      const angles = [-40 * Math.PI / 180, -25 * Math.PI / 180, 0, 25 * Math.PI / 180, 40 * Math.PI / 180];
      const directions = [
        { side: "right", baseAngle: yawRad + Math.PI / 2 },
        { side: "left", baseAngle: yawRad - Math.PI / 2 }
      ];

      for (const { side, baseAngle } of directions) {
        for (const angleOffset of angles) {
          const rayAngle = baseAngle + angleOffset;
          const rayDirX = Math.cos(rayAngle);
          const rayDirZ = Math.sin(rayAngle);

          for (const heightOffset of offsets) {
            if (heightOffset < 0) continue;
            const rayStart = { x: location.x, y: location.y + heightOffset, z: location.z };
            const rayResult = dimension.getBlockFromRay(
              rayStart, { x: rayDirX, y: 0, z: rayDirZ },
              { maxDistance: 1, includePassableBlocks: false, includeLiquidBlocks: false }
            );

            if (rayResult?.block && !rayResult.block.isAir && !rayResult.block.isLiquid) {
              const hitDistance = Math.sqrt(
                Math.pow(rayResult.block.location.x + rayResult.faceLocation.x - location.x, 2) +
                Math.pow(rayResult.block.location.z + rayResult.faceLocation.z - location.z, 2)
              );

              if (hitDistance <= 0.4) {
                result.walls[side] = {
                  block: rayResult.block,
                  distance: hitDistance,
                  angle: (angleOffset * 180 / Math.PI).toFixed(1)
                };
                break;
              }
            }
          }
          if (result.walls[side]) break;
        }
      }
    }

    if (opts.checkGap) {
      let xOff = 0, zOff = 0;
      if (opts.usePlayerForward && hasInput) {
        xOff = vectorMoveRot.x * this.FORWARD_DISTANCE;
        zOff = vectorMoveRot.z * this.FORWARD_DISTANCE;
      }

      for (const dx of offsets) {
        for (const dz of offsets) {
          const loc = { x: location.x + xOff + dx, y: location.y, z: location.z + zOff + dz };
          const footB = getCachedBlock(dimension, { x: Math.floor(loc.x), y: Math.floor(loc.y), z: Math.floor(loc.z) });

          const ray = dimension.getBlockFromRay(
            { x: loc.x, y: loc.y + 0.1, z: loc.z }, { x: 0, y: 1, z: 0 },
            { maxDistance: 1, includePassableBlocks: false, includeLiquidBlocks: false }
          );

          const rollRay = dimension.getBlockFromRay(
            { x: loc.x, y: loc.y + 0.1, z: loc.z }, { x: 0, y: 1, z: 0 },
            { maxDistance: 2, includePassableBlocks: false, includeLiquidBlocks: false }
          );

          const footLevelClear = !footB || footB.isAir || footB.isLiquid || !footB.isSolid;

          if (footLevelClear && ray?.block && !ray.block.isAir && !ray.block.isLiquid) {
            result.blockGap.exists = true;
          }

          if (footLevelClear && rollRay?.block && !rollRay.block.isAir && !rollRay.block.isLiquid) {
            result.blockGap.rollExists = true;
          }
        }
      }
    }

    this.scanCache.set(cacheKey, { result, timestamp: currentTick });
    return result;
  }

  detectWall(player) {
    const result = this.scan(player, { checkGround: false, checkObstacles: false, checkWalls: true });
    return result.walls.left ? "left" : result.walls.right ? "right" : null;
  }

  checkBlockGap(player, useForwardOffset = false) {
    const result = this.scan(player, {
      checkGround: false,
      checkObstacles: false,
      checkGap: true,
      usePlayerForward: useForwardOffset
    });
    return result.blockGap.exists;
  }

  checkVaultBlock(player) {
    const { location, dimension } = player;
    const viewDir = player.getViewDirection();
    const { x, y, z } = location;
    const minVaultHeight = y + 1.0;
    const maxVaultHeight = y + 1.5;
    const scanLimit = y + 3;
    const heightAboveGround = this.getHeightAboveGround(player);

    let foundSolid = false, tooHigh = false, tooLow = true, isSpecialBlock = false;
    const rayOptions = { maxDistance: 1, includePassableBlocks: false, includeLiquidBlocks: false };

    for (let scanY = y; scanY <= scanLimit; scanY += 0.1) {
      const rayResult = dimension.getBlockFromRay(
        { x, y: scanY, z },
        { x: viewDir.x, y: 0, z: viewDir.z },
        rayOptions
      );

      if (rayResult?.block && !rayResult.block.isAir && !rayResult.block.isLiquid) {
        foundSolid = true;
        const blockType = rayResult.block.typeId;
        isSpecialBlock = blockType.includes('fence') || blockType.includes('wall') || blockType.includes('gate');

        if (scanY > maxVaultHeight) {
          tooHigh = true;
          break;
        } else if (isSpecialBlock || heightAboveGround >= 1.5) {
          tooLow = false;
        } else if (scanY < minVaultHeight) {
          tooLow = true;
        } else {
          tooLow = false;
        }
      }
    }

    return { valid: foundSolid && !tooLow && !tooHigh, tooHigh, tooLow, isSpecialBlock };
  }

  getHeightAboveGround(player) {
    const result = this.scan(player, { checkGround: true });
    return result.ground.distance;
  }

  clearCache() {
    this.scanCache.clear();
    this.comprehensiveCache.clear();
    this.lastComprehensiveScan.clear();
    clearBlockCache();
  }

  clearPlayerCache(playerName) {
    this.comprehensiveCache.delete(playerName);
    this.lastComprehensiveScan.delete(playerName);
  }

  getCacheStats() {
    return {
      cachedPlayers: this.comprehensiveCache.size,
      totalScans: this.lastComprehensiveScan.size,
      regularCacheSize: this.scanCache.size
    };
  }
}

const blockScanner = new BlockScanner();
export default blockScanner;
