const blockCache = new Map();
let cacheHits = 0;
let cacheMisses = 0;
const CACHE_MAX_SIZE = 1000;
const CACHE_TTL = 20;

function getCachedBlock(dimension, pos, currentTick) {
    const key = `${dimension.id}:${pos.x},${pos.y},${pos.z}`;

    const cachedEntry = blockCache.get(key);
    if (cachedEntry && currentTick - cachedEntry.timestamp < CACHE_TTL) {
        cacheHits++;
        return cachedEntry.block;
    }

    cacheMisses++;

    if (blockCache.size >= CACHE_MAX_SIZE) {

        const keysToDelete = Array.from(blockCache.keys()).slice(0, Math.floor(CACHE_MAX_SIZE * 0.2));
        keysToDelete.forEach(k => blockCache.delete(k));
    }

    const block = dimension.getBlock(pos);
    blockCache.set(key, { block, timestamp: currentTick });
    return block;
}

function clearBlockCache() {
    blockCache.clear();
    cacheHits = 0;
    cacheMisses = 0;
}

function getCacheStats() {
    return {
        size: blockCache.size,
        hits: cacheHits,
        misses: cacheMisses,
        hitRate: cacheHits / (cacheHits + cacheMisses || 1)
    };
}

export { getCachedBlock, clearBlockCache, getCacheStats };
