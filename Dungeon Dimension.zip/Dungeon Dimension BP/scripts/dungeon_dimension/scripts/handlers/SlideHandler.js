import { MolangVariableMap } from '@minecraft/server';
import { BLOCK_SOUND_MAPPING, SOUND_CONFIGS, DEFAULT_SOUND } from '../utils/Data.js';
import blockScanner from '../utils/BlockScanner.js';
import { getCachedBlock } from '../utils/blockCache.js';
import PlayerStateManager from '../managers/PlayerStateManager.js';
import StaminaManager from '../managers/StaminaManager.js';

class SlideHandler {
  constructor() {
    this.lastTick = new Map();
    this.effectTimers = new Map();
    this.SLIDE_MAX_TICKS = 14;
  }

  handleSlide(player, currentTick) {
    if (this.lastTick.get(player.name) === currentTick) return;
    this.lastTick.set(player.name, currentTick);

    const state = PlayerStateManager.getState(player.name);
    const slide = state?.slide;
    if (!slide) return;

    const scan = blockScanner.getPlayerScan(player, currentTick);
    const { ground, isInLiquid, hasObstacle, blockGap, movementDirection } = scan;

    this.updateSprintTracking(player, currentTick, slide);

    const hasSprintQualification =
      (slide.sprintDistance ?? 0) >= 1.5 &&
      (slide.sprintEndTime ? currentTick - slide.sprintEndTime <= 1 : player.isSprinting);

    const hasEnoughStamina = StaminaManager.hasEnoughStamina(
      player,
      StaminaManager.BASE_COSTS.SLIDE_START,
      'SLIDE_START'
    );

    if (
      hasSprintQualification &&
      player.isSneaking &&
      !slide.isSliding &&
      player.isOnGround &&
      !isInLiquid &&
      scan.ground.block &&
      !hasObstacle &&
      hasEnoughStamina
    ) {
      if (StaminaManager.consumeStamina(player, StaminaManager.BASE_COSTS.SLIDE_START, 'slide_start')) {

        try {
          player.playAnimation('animation.longsword.reset', { blendOutTime: 0.1 });
        } catch (e) { }

        const useAlternate = Math.random() < 0.2;
        const animStart = useAlternate ? 'animation.humanoid.slide.2.start' : 'animation.humanoid.slide.1.start';
        const initialYaw = useAlternate ? player.getRotation().y : null;

        player.playAnimation(animStart, { blendOutTime: 0.3 });

        player.addTag("sag:evading");

        PlayerStateManager.setSlideState(player.name, {
          startTime: currentTick,
          slideDuration: this.SLIDE_MAX_TICKS,
          currentKnockback: 0.85,
          lastUpdateTime: currentTick,
          currentAnimation: animStart,
          initialYaw
        });

        StaminaManager.startContinuousDrain(player, StaminaManager.BASE_COSTS.SLIDE_DRAIN_RATE, 'slide');
        slide.sprintDistance = 0;
      }
    }

    if (slide.isSliding) {
      const info = state.slide.slideInfo;
      if (!info) return;

      if (StaminaManager.getStamina(player) <= 0) {
        this.endSlide(player, currentTick);
        return;
      }

      if (isInLiquid || hasObstacle || !player.isSneaking || currentTick - info.startTime > this.SLIDE_MAX_TICKS) {
        this.endSlide(player, currentTick);
        return;
      }

      const dt = (currentTick - info.lastUpdateTime) / 20;
      info.currentKnockback *= Math.pow(0.35, dt);
      info.lastUpdateTime = currentTick;

      let yawRad;
      if (info.currentAnimation === 'animation.humanoid.slide.2.start' && info.initialYaw !== null) {
        yawRad = (info.initialYaw + 90) * Math.PI / 180;
      } else {
        yawRad = (player.getRotation().y + 90) * Math.PI / 180;
      }

      const elevation = ground.distance === Infinity || ground.distance > 0.1 ? -0.14 : 0.04;

      const impulse = {
        x: Math.cos(yawRad) * info.currentKnockback * 0.35,
        y: elevation * 0.2,
        z: Math.sin(yawRad) * info.currentKnockback * 0.35
      };
      player.applyImpulse(impulse);

      const blockBelow = getCachedBlock(player.dimension, {
        x: Math.floor(player.location.x),
        y: Math.floor(player.location.y) - 1,
        z: Math.floor(player.location.z)
      }, currentTick);
      const blockSound = BLOCK_SOUND_MAPPING[blockBelow?.typeId] || DEFAULT_SOUND.sound;
      const soundCfg = SOUND_CONFIGS[blockSound] || DEFAULT_SOUND;
      try {
        player.dimension.playSound(blockSound, player.location, {
          pitch: soundCfg.pitch,
          volume: soundCfg.volume
        });
      } catch {
        try {
          player.dimension.playSound(blockSound, player.location);
        } catch { }
      }

      if (blockGap.exists && !blockScanner.checkBlockGap(player, false) && !hasObstacle && movementDirection.hasInput) {
        const nx = player.location.x + movementDirection.x * 0.1;
        const nz = player.location.z + movementDirection.z * 0.1;
        const ny = player.location.y + 0.1;
        player.tryTeleport({ x: nx, y: ny, z: nz });
      }

      const v = player.getVelocity();
      const speed = Math.sqrt(v.x ** 2 + v.z ** 2);
      if (speed > 0.15) {
        const m = new MolangVariableMap();
        m.setFloat('variable.direction_x', Math.cos(yawRad));
        m.setFloat('variable.direction_y', 0);
        m.setFloat('variable.direction_z', Math.sin(yawRad));
        player.dimension.spawnParticle('sag:smoke', {
          x: player.location.x - v.x * 0.3,
          y: player.location.y,
          z: player.location.z - v.z * 0.3
        }, m);
      }
    }
  }

  updateSprintTracking(player, currentTick, slide) {
    if (player.isSprinting) {
      if (!slide.lastSprintLocation) {
        slide.lastSprintLocation = { ...player.location };
        slide.sprintDistance = slide.sprintDistance || 0;
        return;
      }
      const cur = player.location;
      const last = slide.lastSprintLocation;
      const dx = cur.x - last.x;
      const dz = cur.z - last.z;
      const d = Math.sqrt(dx * dx + dz * dz);
      if (d > 0.1) {
        slide.sprintDistance = (slide.sprintDistance || 0) + d;
        slide.lastSprintLocation = { ...cur };
      }
    } else {
      if (slide.lastSprintLocation) {
        slide.sprintEndTime = currentTick;
        slide.lastSprintLocation = null;
      }
      if (slide.sprintEndTime && currentTick - slide.sprintEndTime > 1) {
        slide.sprintDistance = 0;
      }
    }
  }

  endSlide(player, currentTick) {
    const state = PlayerStateManager.getState(player.name);
    if (!state) return;

    if (this.effectTimers.has(player.name)) {
      system.clearRun(this.effectTimers.get(player.name));
      this.effectTimers.delete(player.name);
    }

    StaminaManager.stopContinuousDrain(player);

    state.slide.isSliding = false;
    state.slide.sprintDistance = 0;

    const endAnim =
      state.slide.currentAnimation === 'animation.humanoid.slide.2.start'
        ? 'animation.humanoid.slide.2.end'
        : 'animation.humanoid.slide.1.end';

    player.removeTag("sag:evading");

    PlayerStateManager.clearSlideState(player.name, currentTick);
    player.playAnimation(endAnim, { blendOutTime: 0.3 });
  }
}

export default SlideHandler;
