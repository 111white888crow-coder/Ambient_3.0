import { world, system } from '@minecraft/server';
import PlayerStateManager from './managers/PlayerStateManager.js';
import StaminaManager from './managers/StaminaManager.js';
import SlideHandler from './handlers/SlideHandler.js';

const slideHandlers = new Map();

function isDisabled(player) {
  const gm = player.getGameMode?.();
  return gm === 'creative' || gm === 'spectator';
}

world.afterEvents.playerSpawn.subscribe((event) => {
  const player = event.player;
  if (isDisabled(player)) return;

  if (!slideHandlers.has(player.name)) {
    slideHandlers.set(player.name, new SlideHandler());
  }
  StaminaManager.initializePlayerStamina(player);
});

world.afterEvents.playerLeave.subscribe((event) => {
  slideHandlers.delete(event.playerName);
  StaminaManager.clearPlayerStaminaState(event.playerName);
});

system.runInterval(() => {
  const tick = system.currentTick;
  for (const player of world.getPlayers()) {
    if (isDisabled(player)) continue;

    PlayerStateManager.getState(player.name);

    let handler = slideHandlers.get(player.name);
    if (!handler) {
      handler = new SlideHandler();
      slideHandlers.set(player.name, handler);
      StaminaManager.initializePlayerStamina(player);
    }

    try {
      handler.handleSlide(player, tick);
    } catch (e) {
    }
  }
}, 1);
