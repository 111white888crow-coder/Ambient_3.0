const set = (ids, suffixes = []) => ({ ids: new Set(ids), suffixes });

export function matches(typeId, group) {
    if (!typeId || !group) return false;
    if (group.ids.has(typeId)) return true;
    return group.suffixes.some(suffix => typeId.endsWith(suffix));
}

export const NOT_FULL = set([
    "minecraft:hopper",
    "minecraft:cake",
    "minecraft:chorus_plant",
    "minecraft:chorus_flower",
    "minecraft:conduit",
    "minecraft:scaffolding",
    "minecraft:iron_bars",
    "minecraft:glass_pane"
], [
    "_fence", "_fence_gate", "_door", "_pane", "_bars",
    "_carpet", "_button", "_pressure_plate", "_torch", "_sign", "_banner", "_candle"
]);

export const PANES = set([], ["_pane", "_bars"]);

export const NO_WALL_CONNECT = set([
    "minecraft:barrier",
    "minecraft:pumpkin",
    "minecraft:carved_pumpkin",
    "minecraft:lit_pumpkin",
    "minecraft:melon_block",
    "minecraft:hopper",
    "minecraft:cake",
    "minecraft:chorus_plant",
    "minecraft:chorus_flower",
    "minecraft:conduit",
    "minecraft:scaffolding",
    "minecraft:cactus",
    "minecraft:torch",
    "minecraft:lever",
    "minecraft:ladder",
    "minecraft:chain",
    "minecraft:end_rod",
    "minecraft:lightning_rod",
    "minecraft:snow_layer",
    "minecraft:vine",
    "minecraft:web",
    "minecraft:tripwire",
    "minecraft:trip_wire",
    "minecraft:rail"
], [
    "_fence", "_leaves", "_shulker_box", "_trapdoor", "_door",
    "_sign", "_banner", "_candle", "_torch", "_head", "_skull",
    "_carpet", "_button", "_pressure_plate", "_bed", "_rail",
    "_chain", "_lightning_rod"
]);

export const WALL_COVER_FULL = set([
    "minecraft:campfire",
    "minecraft:soul_campfire",
    "minecraft:daylight_detector",
    "minecraft:daylight_detector_inverted",
    "minecraft:stonecutter_block",
    "minecraft:enchanting_table",
    "minecraft:lectern",
    "minecraft:composter",
    "minecraft:sculk_sensor",
    "minecraft:calibrated_sculk_sensor",
    "minecraft:sculk_shrieker"
], ["_carpet"]);

export const WALL_COVER_CENTRE = set([
    "minecraft:flower_pot",
    "minecraft:hopper",
    "minecraft:cake",
    "minecraft:candle",
    "minecraft:candle_cake",
    "minecraft:brewing_stand",
    "minecraft:anvil",
    "minecraft:chipped_anvil",
    "minecraft:damaged_anvil",
    "minecraft:chest",
    "minecraft:trapped_chest",
    "minecraft:ender_chest",
    "minecraft:copper_chest",
    "minecraft:decorated_pot",
    "minecraft:dragon_egg",
    "minecraft:heavy_core",
    "minecraft:sea_pickle",
    "minecraft:turtle_egg",
    "minecraft:sniffer_egg"
], ["_candle", "_candle_cake", "_copper_chest"]);

export const LANTERNS = set(["minecraft:lantern", "minecraft:soul_lantern"], ["_lantern"]);
export const CHAINS = set(["minecraft:chain", "minecraft:iron_chain"], ["_chain"]);
export const RODS = set(["minecraft:end_rod", "minecraft:lightning_rod"], ["_lightning_rod"]);
export const SKULLS = set(["minecraft:skull"], ["_skull", "_head"]);

export const LOGS = set([], ["_log", "_wood", "_hyphae", "_stem"]);
export const LEAVES = set(["minecraft:azalea_leaves_flowered"], ["_leaves"]);

export const STAIRS = set([], ["_stairs", "_stair"]);

export const WEIRDO_DIRECTION = ["east", "west", "south", "north"];
