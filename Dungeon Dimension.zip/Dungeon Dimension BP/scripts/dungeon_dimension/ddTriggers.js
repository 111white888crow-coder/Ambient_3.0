import { world, system, BlockPermutation } from "@minecraft/server";

globalThis.ddTriggersState ??= { inside: new Map() };

const NEIGHBOR_OFFSETS = [
    { dx: 1, dy: 0, dz: 0, dir: "east" }, { dx: -1, dy: 0, dz: 0, dir: "west" },
    { dx: 0, dy: 0, dz: 1, dir: "south" }, { dx: 0, dy: 0, dz: -1, dir: "north" },
    { dx: 0, dy: 1, dz: 0, dir: "up" }, { dx: 0, dy: -1, dz: 0, dir: "down" }
];

export const ddTriggers = {
    _tagBehaviours: new Map(),
    _activeEvents: {},
    _entityRange: 8,
    _ignoredEntities: new Set(),
    _maxEntitiesPerTick: 20,
    _currentEntityIndex: 0,
    registerBehaviourByTag(tag, callbacks) {
        if (!this._tagBehaviours.has(tag)) this._tagBehaviours.set(tag, []);
        this._addUnique(this._tagBehaviours.get(tag), callbacks);
    },
    _addUnique(list, callbacks) {
        if (!callbacks) return;
        const signature = signatureOf(callbacks);
        if (list.some(existing => signatureOf(existing) === signature)) return;
        list.push(callbacks);
    },
    notifyNeighbours(block, extra = {}) {
        if (!block) return;
        const dimension = block.dimension;
        const location = block.location;

        for (const off of NEIGHBOR_OFFSETS) {
            const neighbour = safeGetBlock(dimension, {
                x: location.x + off.dx,
                y: location.y + off.dy,
                z: location.z + off.dz
            });
            if (!neighbour) continue;

            const bhList = getBehavioursFor(neighbour);
            if (bhList.length === 0) continue;
            runBehaviours(bhList, "onAdjacentChange", {
                ...extra, changedBlock: block, block: neighbour, direction: off.dir, dimension
            });
        }
    },
    init(options = {}) {
        if (globalThis.__DD_TRIGGERS_INTERVAL !== undefined) {
            system.clearRun(globalThis.__DD_TRIGGERS_INTERVAL);
            globalThis.__DD_TRIGGERS_INTERVAL = undefined;
        }

        const tickInterval = options.tickInterval ?? 4;
        this._entityRange = options.entityRange ?? 8;
        this._maxEntitiesPerTick = options.maxEntitiesPerTick ?? 20;
        this._currentEntityIndex = 0;
        this._ignoredEntities = new Set(options.ignoredEntities || []);

        this._activeEvents = {
            onInside: true, onInteract: true,
            onAdjacentBreak: true, onPlace: true, onAdjacentPlace: true,
            ...(options.active_events || {})
        };

        registerEventSubscriptions(this._activeEvents);

        const processEntity = (ent, ctx) => {
            if (!this._activeEvents.onInside) return;

            const dim = ctx.dim;
            const loc = ent.location;
            const entId = ent.id;

            const blockLoc = { x: Math.floor(loc.x), y: Math.floor(loc.y + 0.1), z: Math.floor(loc.z) };
            const insideBlock = safeGetBlock(dim, blockLoc);

            let currPosKey = null;
            if (insideBlock && getBehavioursFor(insideBlock).length > 0) currPosKey = keyOf(dim, blockLoc);

            const prevPosKey = globalThis.ddTriggersState.inside.get(entId) || null;
            if (currPosKey === prevPosKey) return;

            if (prevPosKey) {
                const prevDim = world.getDimension(prevPosKey.split("|")[0]);
                const prevBlock = safeGetBlock(prevDim, parseLoc(prevPosKey));
                if (prevBlock) {
                    const bhList = getBehavioursFor(prevBlock);
                    if (bhList.length > 0) runBehaviours(bhList, "onPassingOut", { ...ctx, block: prevBlock, type: "body" });
                }
            }

            if (currPosKey && insideBlock) {
                runBehaviours(getBehavioursFor(insideBlock), "onPassingIn", { ...ctx, block: insideBlock, type: "body" });
            }

            if (currPosKey) globalThis.ddTriggersState.inside.set(entId, currPosKey);
            else globalThis.ddTriggersState.inside.delete(entId);
        };

        globalThis.__DD_TRIGGERS_INTERVAL = system.runInterval(() => {
            const processedIds = new Set();
            const players = world.getAllPlayers();

            for (const player of players) {
                if (this._ignoredEntities.has(player.typeId)) continue;
                processEntity(player, { player, dim: player.dimension, isPlayer: true });
                processedIds.add(player.id);
            }

            const remainingBudget = this._maxEntitiesPerTick - processedIds.size;

            if (remainingBudget > 0) {
                const candidates = [];
                const candidateIds = new Set();

                for (const player of players) {
                    const nearby = player.dimension.getEntities({ location: player.location, maxDistance: this._entityRange });

                    for (const ent of nearby) {
                        if (ent.typeId === "minecraft:player") continue;
                        if (this._ignoredEntities.has(ent.typeId)) continue;
                        if (processedIds.has(ent.id)) continue;
                        if (candidateIds.has(ent.id)) continue;

                        candidates.push({ entity: ent, player });
                        candidateIds.add(ent.id);
                    }
                }

                if (candidates.length > 0) {
                    const total = candidates.length;
                    let processedCount = 0;
                    let index = this._currentEntityIndex % total;

                    while (processedCount < remainingBudget && processedCount < total) {
                        const data = candidates[index];
                        processEntity(data.entity, {
                            entity: data.entity,
                            dim: data.entity.dimension,
                            isPlayer: false,
                            nearPlayer: data.player
                        });
                        processedIds.add(data.entity.id);

                        index = (index + 1) % total;
                        processedCount++;
                    }
                    this._currentEntityIndex = index;
                }
            }

            cleanupStates(processedIds);
        }, tickInterval);
    },
};

function signatureOf(callbacks) {
    return Object.keys(callbacks)
        .sort()
        .map(key => `${key}:${String(callbacks[key])}`)
        .join("|");
}

function safeGetBlock(dim, loc) { try { return dim.getBlock(loc) } catch { return null } }
function keyOf(dim, loc) { return `${dim.id}|${loc.x},${loc.y},${loc.z}` }
function parseLoc(key) { const parts = key.split("|")[1].split(","); return { x: +parts[0], y: +parts[1], z: +parts[2] } }

function cleanupStates(currentEntities) {
    for (const [entId, prevKey] of globalThis.ddTriggersState.inside) {
        if (currentEntities.has(entId)) continue;

        globalThis.ddTriggersState.inside.delete(entId);
        if (!prevKey) continue;

        try {
            const loc = parseLoc(prevKey);
            const dim = world.getDimension(prevKey.split("|")[0]);
            const block = safeGetBlock(dim, loc);
            const bhList = getBehavioursFor(block);

            if (bhList.length > 0) {
                runBehaviours(bhList, "onPassingOut", { entity: null, block, type: "body" });
            }
        } catch (err) {
            console.warn(`[ddTriggers] Cleanup error: ${err}`);
        }
    }
}

function getBehavioursFor(block) {
    if (!block) return [];
    const results = [];
    const params = extractParams(block);

    for (const [tag, bhListTag] of ddTriggers._tagBehaviours) {
        if (block.hasTag(tag)) bhListTag.forEach(tagBh => results.push([tagBh, params]));
    }
    return results;
}

function extractParams(block) {
    const params = {};
    for (const t of block.getTags()) {
        if (!t.startsWith("param__")) continue;
        const parts = t.split("__");
        if (parts.length >= 3) {
            const name = parts[1];
            const rawValue = parts.slice(2).join("__");
            params[name] = parseParamValue(rawValue);
        }
    }
    return params;
}

function parseParamValue(value) {
    const lower = value.toLowerCase();
    if (lower === "true") return true;
    if (lower === "false") return false;
    if (!isNaN(Number(value))) return Number(value);
    if (value.includes(",")) return value.split(",").map(v => v.trim()).map(parseParamValue);
    if (typeof value === "string" && value.includes("-")) return value.replace(/-/g, "/");
    return value;
}

function runBehaviours(bhs, cbName, e) { for (const [bh, params] of bhs) { bh?.[cbName]?.(e, params) } }

function behaviourFilterPasses(bh, itemOrStack, context = {}) {
    const { item_id, item_tag, allow_hand, handOnly, item_any, customFilter } = bh || {};

    if (handOnly) return !itemOrStack;
    if (item_any) return true;

    const hasFilters = item_id || item_tag || customFilter;
    if (!hasFilters) return true;
    if (!itemOrStack) return allow_hand ?? false;

    const ids = Array.isArray(item_id) ? item_id : item_id ? [item_id] : [];
    const tags = Array.isArray(item_tag) ? item_tag : item_tag ? [item_tag] : [];
    let typeId = null;

    if (typeof itemOrStack === "string") typeId = itemOrStack;
    else if (itemOrStack && typeof itemOrStack === "object") {
        if (typeof itemOrStack.typeId === "string") typeId = itemOrStack.typeId;
        else if (typeof itemOrStack.id === "string") typeId = itemOrStack.id;
    }

    if (ids.length > 0) {
        if (!typeId) return false;
        if (!ids.includes(typeId)) return false;
    }
    if (tags.length > 0) {
        const hasTagFn = itemOrStack && typeof itemOrStack.hasTag === "function" ? itemOrStack.hasTag.bind(itemOrStack) : null;
        if (!hasTagFn) return false;
        for (const tag of tags) { try { if (!hasTagFn(tag)) return false; } catch (e) { return false; } }
    }
    if (typeof customFilter === "function") {
        try {
            if (!customFilter(itemOrStack, context.block, context.face, context.player, context.faceLocation)) return false;
        } catch (e) { return false; }
    }
    return true;
}

function registerEventSubscriptions(activeEvents) {
    if (globalThis.__DD_TRIGGERS_SUBSCRIBED) return;
    globalThis.__DD_TRIGGERS_SUBSCRIBED = true;

    if (activeEvents.onInteract) {
        world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
            const { block, blockFace, faceLocation, player, isFirstEvent, itemStack } = event;
            if (!isFirstEvent || !block || !player) return;

            let isBlockItem = false;
            if (itemStack) {
                try { if (BlockPermutation.resolve(itemStack.typeId)) isBlockItem = true; } catch { }
                if (itemStack.hasTag?.("dd:is_block")) isBlockItem = true;
            }

            const bhList = getBehavioursFor(block).filter(([bh]) => typeof bh.onInteract === "function");
            if (bhList.length === 0) return;

            let shouldCancel = false;
            for (const [bh, params] of bhList) {
                if (!behaviourFilterPasses(bh, itemStack, { block, face: blockFace, player, faceLocation })) continue;
                if (isBlockItem && !player.isSneaking) shouldCancel = true;
                system.run(() => {
                    try {
                        bh.onInteract({ player, block, face: blockFace, faceLocation, face_location: faceLocation, itemStack }, params);
                    } catch (err) {
                        console.warn(`[ddTriggers] Error onInteract: ${err}`);
                    }
                });
            }
            if (shouldCancel) event.cancel = true;
        });
    }

    if (activeEvents.onAdjacentBreak) {
        world.afterEvents.playerBreakBlock.subscribe(ev => {
            const { block, player, dimension, brokenBlockPermutation } = ev;
            if (!block) return;
            for (const off of NEIGHBOR_OFFSETS) {
                const neighbor = safeGetBlock(dimension, { x: block.location.x + off.dx, y: block.location.y + off.dy, z: block.location.z + off.dz });
                if (!neighbor) continue;
                const bhList = getBehavioursFor(neighbor);
                if (bhList.length === 0) continue;
                const payload = { player, brokenBlock: block, brokenBlockPermutation, changedBlock: block, block: neighbor, direction: off.dir, dimension };
                runBehaviours(bhList, "onAdjacentBreak", payload);
                runBehaviours(bhList, "onAdjacentChange", payload);
            }
        });
    }

    if (activeEvents.onPlace) {
        world.afterEvents.playerPlaceBlock.subscribe(ev => {
            const { block, player, dimension } = ev;
            if (!block) return;
            const bhList = getBehavioursFor(block);
            if (bhList.length > 0) runBehaviours(bhList, "onPlace", { player, block, dimension });
        });
    }

    if (activeEvents.onAdjacentPlace) {
        world.afterEvents.playerPlaceBlock.subscribe(ev => {
            const { block, player, dimension } = ev;
            if (!block) return;
            for (const off of NEIGHBOR_OFFSETS) {
                const neighbor = safeGetBlock(dimension, { x: block.location.x + off.dx, y: block.location.y + off.dy, z: block.location.z + off.dz });
                if (!neighbor) continue;
                const bhList = getBehavioursFor(neighbor);
                if (bhList.length === 0) continue;
                const payload = { player, placedBlock: block, changedBlock: block, block: neighbor, direction: off.dir, dimension };
                runBehaviours(bhList, "onAdjacentPlace", payload);
                runBehaviours(bhList, "onAdjacentChange", payload);
            }
        });
    }
}

world.afterEvents.worldLoad.subscribe(() => {
    world.setDynamicProperty("dd:world_state", 1);
    if (world.getAllPlayers().length > 0) {
        system.runTimeout(() => world.setDynamicProperty("dd:world_state", 2), 1);
    }
});

world.afterEvents.playerJoin.subscribe(async () => {
    if (world.getDynamicProperty("dd:world_state") === 2) return;
    await system.waitTicks(120);
    world.setDynamicProperty("dd:world_state", 2);
});

world.afterEvents.worldLoad.subscribe(() => {
    ddTriggers.init({
        tickInterval: 1,
        entityRange: 30,
        maxEntitiesPerTick: 20,
        ignoredEntities: []
    });
});

export function ReduceDurability(player, item, amount, slot = "Mainhand") {
    if (!player || !item) return false;
    const durability = item.getComponent("minecraft:durability");
    if (!durability) return false;
    const currentDamage = durability.damage ?? 0;
    const newDamage = currentDamage + amount;
    const equip = player.getComponent("minecraft:equippable");
    if (newDamage >= durability.maxDurability) {
        equip.setEquipment(slot);
        player.playSound("random.break", player.location);
        return true;
    } else {
        durability.damage = newDamage;
        equip.setEquipment(slot, item);
        return false;
    }
}
