import { world, system, ItemStack } from "@minecraft/server";
import { stairFullFaces } from "../utils/blockChecks.js";
import { playBlockEntity, removeBlockEntity } from "../utils/blockEntity.js";
import { firstHit } from "../utils/projectileOnce.js";
const BLOCK_ID = "dd:big_bell";
const ENTITY_ID = "dd:big_bell_entity";
const RING_SOUND = "block.bell.hit";
const BREAK_SOUND = "dig.stone";
const WORLD_STATE = "dd:world_state";
const CARDINALS = ["north", "east", "south", "west"];
const WALL_DIRS = ["east", "north", "west", "south"];
const YAW_DIRS = ["south", "west", "north", "east"];
const FLAT_SIDES = ["north", "east", "south", "west"];
const OPPOSITE = { north: "south", south: "north", east: "west", west: "east", up: "down", down: "up" };
const OFFSET = { north: { x: 0, y: 0, z: -1 }, south: { x: 0, y: 0, z: 1 }, east: { x: 1, y: 0, z: 0 }, west: { x: -1, y: 0, z: 0 }, up: { x: 0, y: 1, z: 0 }, down: { x: 0, y: -1, z: 0 } };
const OFFSETS = Object.values(OFFSET);
const WIND_CHARGES = new Set(["minecraft:wind_charge_projectile", "minecraft:breeze_wind_charge_projectile"]);
const WIND_RADIUS = 1.5;
const NO_SUPPORT = [
	"leaves", "scaffold", "rail", "torch", "button", "lever", "wire", "carpet", "snow_layer",
	"sign", "lantern", "coral", "seagrass", "kelp", "vine", "campfire", "bell", "door",
	"head", "skull", "ladder", "anvil", "brewing", "statue", "hopper", "cauldron", "cake",
	"egg", "pickle", "bamboo", "sapling", "mushroom", "fungus", "roots", "sprouts", "amethyst",
	"bud", "dripstone", "crystal", "conduit", "chest", "shulker", "grindstone", "stonecutter",
	"enchanting", "portal", "detector", "lectern", "web", "tripwire", "plate", "comparator",
	"repeater", "bed", "banner", "frame", "lichen", "vein", "sensor", "bush", "dripleaf",
	"plant", "crop", "wheat", "potato", "carrot", "beetroot", "berry", "azalea",
	"pumpkin_stem", "melon_stem", "lily", "fern", "flower", "candle", "tallgrass",
	"short_grass", "rose", "orchid", "tulip", "bluet", "daisy", "allium", "cornflower",
	"peony", "lilac"
];
function cardinalFromYaw(yaw) {
	return YAW_DIRS[Math.round((((yaw % 360) + 360) % 360) / 90) % 4];
}
function swSturdyFace(block, face) {
	let states;
	try { states = block.permutation.getAllStates(); } catch { return undefined; }

	if ("dd:block_bit" in states) {
		if (states["dd:block_bit"] === true) return true;
		const isTop = states["minecraft:vertical_half"] === "top";
		if (face === "up") return isTop;
		if (face === "down") return !isTop;
		return false;
	}

	const stairFaces = stairFullFaces(block, states);
	if (stairFaces !== null) {
		const isTop = states["minecraft:vertical_half"] === "top" || states.upside_down_bit === true;
		if (face === "up") return isTop;
		if (face === "down") return !isTop;
		return stairFaces.includes(face);
	}

	return undefined;
}
function isSturdyFace(block, face) {
	const sw = swSturdyFace(block, face);
	if (sw !== undefined) return sw;
	const id = block.typeId;
	try { if (typeof block.isSolid === "boolean" && !block.isSolid) return false; } catch { }
	if (id.includes("slab")) {
		if (id.includes("double")) return true;
		try {
			const isTop = block.permutation.getState("minecraft:vertical_half") === "top";
			if (face === "up") return isTop;
			if (face === "down") return !isTop;
			return false;
		} catch { return false; }
	}
	if (id.includes("trapdoor")) {
		try {
			const isOpen = block.permutation.getState("open_bit") === true || block.permutation.getState("open") === true;
			const isTop = block.permutation.getState("upside_down_bit") === true || block.permutation.getState("minecraft:vertical_half") === "top";
			if (!isOpen) {
				if (face === "up") return isTop;
				if (face === "down") return !isTop;
				return false;
			}
			if (face === "up" || face === "down") return false;
			return face === FLAT_SIDES[block.permutation.getState("direction") ?? block.permutation.getState("minecraft:direction") ?? 0];
		} catch { return false; }
	}
	if (id.includes("fence") || id.endsWith("_wall") || id.includes("pane") || id.includes("bars") || id.includes("chain") || id.includes("rod")) return face === "down";
	if (NO_SUPPORT.some(w => id.includes(w))) return false;
	return true;
}
function canSupport(block, dir) {
	try {
		const n = block.offset(OFFSET[dir]);
		if (!n) return true;
		if (n.isAir || n.isLiquid) return false;
		return isSturdyFace(n, OPPOSITE[dir]);
	} catch { return true; }
}
const SWING_TICKS = 50;
const defaultRingDir = (block) => CARDINALS[block.permutation.getState("dd:direction") ?? 0];
function ringDirFromFace(block, face) {
	const f = String(face).toLowerCase();
	return (f === "up" || f === "down") ? defaultRingDir(block) : f;
}
function constrainRingDir(block, direction) {
	const perm = block.permutation;
	if (perm.getState("dd:attachment") !== "floor") return direction;
	const allowed = CARDINALS[perm.getState("dd:direction") ?? 0];
	return (CARDINALS.indexOf(direction) & 1) === (CARDINALS.indexOf(allowed) & 1) ? direction : allowed;
}
function ring(block, direction, sound = RING_SOUND) {
	const started = playBlockEntity(block, ENTITY_ID, SWING_TICKS, (entity) => {
		entity.setProperty("dd:ring_dir", constrainRingDir(block, direction));
		entity.setProperty("dd:phase", 1);
	});
	if (started && sound) block.dimension.playSound(sound, block.center());
}
function dropBell(block, sound = BREAK_SOUND) {
	const dim = block.dimension, center = block.center();
	block.setType("minecraft:air");
	dim.spawnItem(new ItemStack(BLOCK_ID, 1), center);
	if (sound) dim.playSound(sound, center);
}
function validate(block) {
	if (!block || block.typeId !== BLOCK_ID) return;
	const perm = block.permutation;
	const att = perm.getState("dd:attachment");
	const step = perm.getState("dd:direction") ?? 0;
	if (att === "floor") { if (!canSupport(block, "down")) dropBell(block); return; }
	if (att === "ceiling") { if (!canSupport(block, "up")) dropBell(block); return; }
	const side = WALL_DIRS[step];
	const near = canSupport(block, side);
	const far = canSupport(block, OPPOSITE[side]);
	if (!near && !far) { dropBell(block); return; }
	const nextAtt = (near && far) ? "double_wall" : "wall";
	const nextStep = near ? step : WALL_DIRS.indexOf(OPPOSITE[side]);
	if (nextAtt !== att || nextStep !== step) {
		block.setPermutation(perm.withState("dd:attachment", nextAtt).withState("dd:direction", nextStep < 0 ? step : nextStep));
	}
}
function validateNeighbors(dimension, loc) {
	for (const o of OFFSETS) {
		try {
			const n = dimension.getBlock({ x: loc.x + o.x, y: loc.y + o.y, z: loc.z + o.z });
			if (n?.typeId === BLOCK_ID) validate(n);
		} catch { }
	}
}
function windBurst(dimension, location) {
	const cx = Math.floor(location.x), cy = Math.floor(location.y), cz = Math.floor(location.z);
	for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) for (let dz = -1; dz <= 1; dz++) {
		try {
			const b = dimension.getBlock({ x: cx + dx, y: cy + dy, z: cz + dz });
			if (b?.typeId !== BLOCK_ID) continue;
			const c = b.center();
			const d2 = (c.x - location.x) ** 2 + (c.y - location.y) ** 2 + (c.z - location.z) ** 2;
			if (d2 > WIND_RADIUS ** 2) continue;
			ring(b, defaultRingDir(b));
		} catch { }
	}
}
system.beforeEvents.startup.subscribe((init) => {
	init.blockComponentRegistry.registerCustomComponent("dd:big_bell", {
		beforeOnPlayerPlace(e) {
			const { block, player, permutationToPlace } = e;
			const face = permutationToPlace.getState("minecraft:block_face");
			if (!canSupport(block, OPPOSITE[face])) { e.cancel = true; return; }
			let attachment = "floor", step = 0;
			if (face === "up" || face === "down") {
				if (face === "down") attachment = "ceiling";
				step = CARDINALS.indexOf(cardinalFromYaw(player?.getRotation().y ?? 0));
			} else if (OPPOSITE[face]) {
				attachment = canSupport(block, face) ? "double_wall" : "wall";
				step = WALL_DIRS.indexOf(OPPOSITE[face]);
			}
			e.permutationToPlace = permutationToPlace.withState("dd:attachment", attachment).withState("dd:direction", step < 0 ? 0 : step);
		},
		onBreak(e) {
			const { block, dimension } = e;
			const loc = { ...block.location };
			system.run(() => { removeBlockEntity(dimension, loc, ENTITY_ID); validateNeighbors(dimension, loc); });
		},
		onPlayerInteract(e, p) {
			ring(e.block, ringDirFromFace(e.block, e.face), p?.params?.ring_sound ?? RING_SOUND);
		},
		onRedstoneUpdate(e, p) {
			const { block, powerLevel } = e;
			if (world.getDynamicProperty(WORLD_STATE) === 1) return;
			const powered = block.permutation.getState("dd:powered") === true;
			const nowPowered = powerLevel >= 1;
			if (powered === nowPowered) return;
			block.setPermutation(block.permutation.withState("dd:powered", nowPowered));
			if (nowPowered) ring(block, defaultRingDir(block), p?.params?.ring_sound ?? RING_SOUND);
		}
	});
});
const onProjectileHit = (e) => {
	if (WIND_CHARGES.has(e.projectile?.typeId)) { windBurst(e.dimension, e.location); return; }
	const hit = e.getBlockHit?.();
	if (hit?.block?.typeId !== BLOCK_ID) return;
	if (!firstHit(e.projectile, BLOCK_ID)) return;
	ring(hit.block, ringDirFromFace(hit.block, hit.face));
};
world.afterEvents.projectileHitBlock.subscribe(onProjectileHit);
world.afterEvents.projectileHitEntity.subscribe(onProjectileHit);
const onNeighborChange = ({ block, dimension }) => {
	validateNeighbors(dimension, block.location);
	system.run(() => { if (block?.typeId === BLOCK_ID) validate(block); });
};
world.afterEvents.playerPlaceBlock.subscribe(onNeighborChange);
world.afterEvents.playerBreakBlock.subscribe(onNeighborChange);
world.afterEvents.blockExplode.subscribe(onNeighborChange);