/**
 * dd:dandelion — одуванчик: зацветает, теряет семена и отрастает заново.
 *
 * Одно состояние на все стадии, dd:dandelion_age, но поводы у переходов разные:
 *
 *   0 -> 1  рост. Жёлтый цветок становится белым шариком. Сам по себе, по
 *           случайному тику, или сразу от костной муки;
 *   1 -> 2  осыпание. Шарик разлетается, остаётся голый стебель. Сам по себе,
 *           по случайному тику, или сразу — если задели телом, а не кликом;
 *   2 -> 0  отрастание. Из стебля поднимается новый жёлтый цветок. Сам по себе
 *           или от костной муки.
 *
 * Круг замкнут нарочно: сбитый одуванчик не остаётся голым навсегда. Разделять
 * стадии на два состояния незачем — они идут строго подряд, и одно число
 * описывает их без остатка. Время проходит весь круг, а вот костная мука шарик
 * не сдувает: её дело торопить рост и отрастание. Пройти сквозь стебель или
 * нераспустившийся цветок тоже ничего не меняет.
 */
import { world, system } from "@minecraft/server";
import { ddTriggers } from "../ddTriggers.js";

const BLOCK_ID = "dd:dandelion";
const TAG = "dd:dandelion";
const AGE = "dd:dandelion_age";

const FRESH = 0;
const SEEDED = 1;
const SPENT = 2;

const BONE_MEAL = "minecraft:bone_meal";

/** Семена, разлетающиеся при сбивании. */
const SEED_PARTICLE = "dd:dandelion";

/** Ванильные частицы и звук удобрения — те же, что у любой подкормки. */
const GROW_PARTICLE = "minecraft:crop_growth_emitter";
const GROW_SOUND = "item.bone_meal.use";
const SEED_SOUND = "block.sweet_berry_bush.break";

const ageOf = (block) => block.permutation.getState(AGE) ?? FRESH;

function setAge(block, age) {
	try {
		if (ageOf(block) === age) return false;
		block.setPermutation(block.permutation.withState(AGE, age));
		return true;
	} catch { return false; }
}

/** Круг стадий: цветок, шарик, голый стебель и снова цветок. */
const NEXT_BY_AGE = { [FRESH]: SEEDED, [SEEDED]: SPENT, [SPENT]: FRESH };

/**
 * На какие стадии действует костная мука.
 *
 * Мука торопит рост и отрастание, но семена ею не сбить: распустившийся шарик
 * она не берёт. Само же время проходит весь круг, включая 1 -> 2 — шарик
 * осыпается и от того, что его никто не тронул.
 */
const BONE_MEAL_AGES = new Set([FRESH, SPENT]);

/**
 * Следующая стадия. Осыпание идёт через blowSeeds — с частицами и звуком,
 * потому что это то же самое событие, что и от прикосновения, только повод
 * другой.
 */
function advance(block) {
	const age = ageOf(block);
	const next = NEXT_BY_AGE[age];
	if (next === undefined) return false;
	if (age === SEEDED) return blowSeeds(block);
	return setAge(block, next);
}

/** Семена сбиты: шарик разлетается, на месте остаётся стебель. */
function blowSeeds(block) {
	if (ageOf(block) !== SEEDED) return false;
	if (!setAge(block, SPENT)) return false;

	const dimension = block.dimension;
	const center = block.center();
	try { dimension.spawnParticle(SEED_PARTICLE, center); } catch { /* чанк выгружен */ }
	try { dimension.playSound(SEED_SOUND, center, { volume: 0.4, pitch: 1.4 }); } catch { }
	return true;
}

/* ─── Рост сам по себе ───────────────────────────────────────────────────── */

/**
 * Одуванчик ходит по стадиям на случайном тике, как ванильные посевы, — значит
 * его ход подчиняется правилу randomTickSpeed и ускоряется вместе с миром.
 * Прежняя очередь minecraft:tick этого не умела: её сроки отмеряет сам блок, и
 * скорость мира на них никак не сказывается.
 *
 * Движок раздаёт каждой подсекции 16×16×16 по randomTickSpeed случайных клеток
 * за тик, то есть до нашей доходит очередь примерно раз в 4096/randomTickSpeed
 * тиков — при обычной тройке это около 68 секунд. Своя вероятность растягивает
 * шаг до прежних полутора-двух минут и при этом сохраняет пропорцию: ускорили
 * мир вдвое — вдвое быстрее зацветает.
 */
const GROW_CHANCE = 0.5;

system.beforeEvents.startup.subscribe((init) => {
	init.blockComponentRegistry.registerCustomComponent("dd:dandelion_config", {
		onRandomTick(e) {
			if (Math.random() >= GROW_CHANCE) return;
			try { advance(e.block); }
			catch (error) { console.warn(`[dandelion] случайный тик: ${error}`); }
		}
	});
});

/* ─── Костная мука ───────────────────────────────────────────────────────── */

world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
	const { block, player, itemStack } = event;
	if (block?.typeId !== BLOCK_ID || itemStack?.typeId !== BONE_MEAL) return;
	/* Мука торопит и рост, и отрастание, но шарик ею не сбить */
	const from = ageOf(block);
	if (!BONE_MEAL_AGES.has(from)) return;

	event.cancel = true;
	system.run(() => {
		try {
			/* Стадию проверяем и тут: нажатие приходит и дважды подряд, и второе
			   застало бы уже распустившийся шарик. Через advance оно бы его
			   сбило — с частицами семян и второй потраченной мукой. Мука только
			   переводит стадию, осыпание ей не доступно никогда. */
			if (block.typeId !== BLOCK_ID || ageOf(block) !== from) return;
			if (!setAge(block, NEXT_BY_AGE[from])) return;

			const center = block.center();
			try { block.dimension.spawnParticle(GROW_PARTICLE, center); } catch { }
			try { block.dimension.playSound(GROW_SOUND, center); } catch { }
			takeOne(player, itemStack);
		} catch (error) { console.warn(`[dandelion] костная мука: ${error}`); }
	});
});

function takeOne(player, itemStack) {
	let mode;
	try { mode = player.getGameMode(); } catch { return; }
	if (mode === "Creative") return;

	const container = player.getComponent("minecraft:inventory")?.container;
	if (!container) return;
	const slot = player.selectedSlotIndex;
	const held = container.getItem(slot);
	if (held?.typeId !== itemStack.typeId) return;

	if (held.amount > 1) {
		held.amount -= 1;
		container.setItem(slot, held);
	} else {
		container.setItem(slot, undefined);
	}
}

/* ─── Прикосновение ──────────────────────────────────────────────────────── */

/**
 * Прикосновений приходит много подряд: игрок стоит в клетке и ddTriggers зовёт
 * нас на каждом своём проходе. Шарик сбивается один раз, дальше состояние уже
 * не то, так что своего кулдауна не нужно — хватает проверки возраста.
 */
ddTriggers.registerBehaviourByTag(TAG, {
	onPassingIn(e) {
		const { block } = e;
		try { if (block?.typeId === BLOCK_ID) blowSeeds(block); }
		catch (error) { console.warn(`[dandelion] прикосновение: ${error}`); }
	}
});
