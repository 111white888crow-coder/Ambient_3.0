import { world, system, ItemStack, GameMode } from "@minecraft/server";
import { playBlockEntity, removeBlockEntity } from "../utils/blockEntity.js";
import { firstHit } from "../utils/projectileOnce.js";
const BLOCK_ID = "dd:glug_pot";
const ENTITY_ID = "dd:glug_pot_entity";
const BOTTLE_ID = "minecraft:glass_bottle";
const TOXIN_ID = "dd:toxin_bottle";
const MAX_LEVEL = 3;
const TAKE_SOUND = "cauldron.takepotion";
const FILL_SOUND = "cauldron.fillpotion";
const SPLASH_SOUND = "random.splash";
const POISON_TICKS = 20;
const FALL_COOLDOWN = 20;
const lastFall = new Map();
function fallReady(entity) {
	const now = system.currentTick;
	const last = lastFall.get(entity.id);
	if (last !== undefined && now - last < FALL_COOLDOWN) return false;
	for (const [id, tick] of lastFall) if (now - tick >= FALL_COOLDOWN) lastFall.delete(id);
	lastFall.set(entity.id, now);
	return true;
}
const levelOf = (block) => block.permutation.getState("dd:sludge_level") ?? 0;

const ANIM_TICKS = { glug: 7, take_away: 5, interact: 20, interact_up: 80 };

function play(block, anim, hitDir) {
	if (!anim) return;
	const ticks = ANIM_TICKS[anim] ?? 20;
	playBlockEntity(block, ENTITY_ID, ticks, (entity) => {
		entity.setProperty("dd:sludge_level", levelOf(block));
		if (hitDir) entity.setProperty("dd:hit_dir", hitDir);
		entity.setProperty("dd:anim", anim);
		entity.setProperty("dd:phase", 1);
		startFrames(entity, ticks);
	});
}
function setLevel(block, level, anim, sound) {
	const next = Math.max(0, Math.min(MAX_LEVEL, level));
	block.setPermutation(block.permutation.withState("dd:sludge_level", next));
	play(block, anim);
	if (sound) block.dimension.playSound(sound, block.center());
	return next;
}
function exchange(player, slot, item, result) {
	if (player.getGameMode() === GameMode.Creative) return;
	const container = player.getComponent("minecraft:inventory")?.container;
	if (!container) return;
	if (item.amount <= 1) { container.setItem(slot, result); return; }
	const rest = item.clone();
	rest.amount -= 1;
	container.setItem(slot, rest);
	const left = container.addItem(result);
	if (left) player.dimension.spawnItem(left, player.location);
}
function useBottle(block, player) {
	const container = player?.getComponent("minecraft:inventory")?.container;
	if (!container) return false;
	const slot = player.selectedSlotIndex;
	const item = container.getItem(slot);
	if (!item) return false;
	const level = levelOf(block);
	if (item.typeId === BOTTLE_ID) {
		if (level <= 0) return false;
		setLevel(block, level - 1, "take_away", TAKE_SOUND);
		exchange(player, slot, item, new ItemStack(TOXIN_ID, 1));
		return true;
	}
	if (item.typeId === TOXIN_ID) {
		if (level >= MAX_LEVEL) return false;
		setLevel(block, level + 1, "glug", FILL_SOUND);
		exchange(player, slot, item, new ItemStack(BOTTLE_ID, 1));
		return true;
	}
	return false;
}
const VERTICAL = new Set(["up", "down"]);
function nudge(block, face) {
	const side = String(face ?? "up").toLowerCase();
	if (VERTICAL.has(side)) play(block, "interact_up");
	else play(block, "interact", side);
}
function splash(block, entity) {
	setLevel(block, levelOf(block) - 1, "take_away", SPLASH_SOUND);
	try { entity.addEffect("poison", POISON_TICKS, { amplifier: 0 }); }
	catch { }
}

/* ─── Кадры текстуры ─────────────────────────────────────────────────────── */

const FRAMES = 4;
const FRAME_TICKS = 20;
const currentFrame = () => Math.floor(system.currentTick / FRAME_TICKS) % FRAMES;

function startFrames(entity, ticks) {
	entity.setProperty("dd:frame", currentFrame());
	for (let at = FRAME_TICKS - (system.currentTick % FRAME_TICKS); at < ticks; at += FRAME_TICKS) {
		system.runTimeout(() => {
			try { if (entity.isValid) entity.setProperty("dd:frame", currentFrame()); }
			catch { /* моб уже ушёл */ }
		}, at);
	}
}
system.beforeEvents.startup.subscribe((init) => {
	init.blockComponentRegistry.registerCustomComponent("dd:glug_pot_animation", {
		onBreak(e) {
			const { dimension } = e;
			const location = { ...e.block.location };
			system.run(() => removeBlockEntity(dimension, location, ENTITY_ID));
		},
		onPlayerInteract(e) {
			if (!useBottle(e.block, e.player)) nudge(e.block, e.face);
		},
		onEntityFallOn(e) {
			const { block, entity } = e;
			if (!entity || !fallReady(entity)) return;
			system.run(() => {
				try {
					if (!entity.isValid || block.typeId !== BLOCK_ID) return;
					if (levelOf(block) > 0) splash(block, entity);
					else nudge(block, "up");
				}
				catch (error) { console.warn(`[glug_pot] fall: ${error}`); }
			});
		},
		onTick(e) {
			const { block } = e;
			system.run(() => {
				try {
					if (block.typeId !== BLOCK_ID) return;
					const level = levelOf(block);
					if (level >= MAX_LEVEL) return;
					setLevel(block, level + 1, "glug", null);
				} catch (error) { console.warn(`[glug_pot] tick: ${error}`); }
			});
		}
	});
});

/* ─── Снаряды ────────────────────────────────────────────────────────────── */

/**
 * Стрела, снежок, яйцо — горшок качается от них ровно так же, как от руки, и в
 * ту же сторону: сторону берём с грани попадания, как у нажатия. Наполнить или
 * зачерпнуть снаряд, понятно, ничего не может, так что остаётся один толчок.
 *
 * Удар засчитывается один раз на снаряд: воткнувшаяся стрела иначе качала бы
 * горшок без конца, тем же порядком, что звонила в колокол.
 */
world.afterEvents.projectileHitBlock.subscribe((e) => {
	const hit = e.getBlockHit?.();
	if (hit?.block?.typeId !== BLOCK_ID) return;
	if (!firstHit(e.projectile, BLOCK_ID)) return;
	try { nudge(hit.block, hit.face); }
	catch (error) { console.warn(`[glug_pot] снаряд: ${error}`); }
});
