import { world, system, BlockVolume, MolangVariableMap } from "@minecraft/server";

import { playBlockEntity, removeBlockEntity } from "../../utils/blockEntity.js";
import { ringOut } from "../../utils/sustain.js";
import { VibrationManager } from "./VibrationManager.js";
import { VibrationEventListener } from "./VibrationEventListener.js";
import { openTuningForm } from "./TuningForkForm.js";
import {
	clampNote,
	clampOctave,
	clampTone,
	describeTuning,
	pitchOf,
	rangeOf,
	ringTicksOf,
	sameTuning,
	soundOf
} from "./notes.js";

/**
 * dd:tuning_fork — a block that is tuned to a note, a height and a timbre, and
 * passes its vibration on to every other fork tuned exactly the same way.
 *
 * The block itself is only a data holder: as soon as it is placed it hides its
 * own geometry (dd:has_entity) and an dd:tuning_fork_entity takes over the
 * rendering, because only an entity can animate the `folk_resonator` bone.
 *
 * Ringing it does four things at once:
 *   - plays its note and shows the note glyph above itself
 *   - shakes the entity's prongs
 *   - raises a redstone output for as long as it rings
 *   - sends a vibration to matching forks in range, which arrive in turn
 */

const BLOCK_ID = "dd:tuning_fork";
const ENTITY_ID = "dd:tuning_fork_entity";
const WORLD_STATE = "dd:world_state";

/** Longest chain one strike may set off, so a mile of forks cannot lock up a tick. */
const MAX_HOPS = 32;

/** Default tuning of a freshly placed fork: A, middle octave, harp — a real tuning fork's note. */
const DEFAULT_TUNING = { note: 3, octave: 1, tone: 0 };

/**
 * Last redstone level seen at a position, for rising-edge detection.
 *
 * The engine refuses a block that carries both minecraft:redstone_producer and
 * minecraft:redstone_consumer, and the fork needs the producer to put its own
 * signal out — so there is no onRedstoneUpdate to lean on and the incoming level
 * is polled every tick instead.
 */
const lastPower = new Map();

/**
 * Докуда дрожать каждой звенящей вилке: ключ клетки -> номер тика, на котором
 * пора замолчать.
 *
 * Раньше срок хранил TaskScheduler — в динамическом свойстве мира, под ключом с
 * координатами клетки. Поршень сдвигал вилку на клетку, и срок оставался лежать
 * на пустом месте: приходил, не находил там камертона и молча уходил. А уехавшая
 * вилка так и оставалась с `dd:ringing`, то есть навсегда звенящей — с вечными
 * 15 редстоуна наружу, глухая к рычагу (звенящую не бьют повторно) и без
 * сущности, потому что кости у неё уже спрятаны.
 *
 * Поэтому срок теперь живёт в памяти и проверяется тем же тиком блока, что и
 * редстоун: у вилки на новом месте срока нет, и она замолкает в тот же миг.
 * Перезагрузка мира память чистит — звеневшая до выхода вилка на входе замолчит,
 * и это правильнее, чем звенеть с прошлой сессии.
 */
const silence = new Map();

const NEIGHBOURS = [
	{ x: 1, y: 0, z: 0 }, { x: -1, y: 0, z: 0 },
	{ x: 0, y: 1, z: 0 }, { x: 0, y: -1, z: 0 },
	{ x: 0, y: 0, z: 1 }, { x: 0, y: 0, z: -1 }
];

const posKey = (dimensionId, loc) => `${dimensionId}|${loc.x},${loc.y},${loc.z}`;

/**
 * Камертоны в кубе вокруг точки.
 *
 * Раньше соседей искали по их сущностям — те висели при блоках всегда. Теперь
 * сущность живёт одну дрожь, и спрашивать надо о блоках. `getBlocks` с
 * `includeTypes` — нативный перебор области, он дешевле обхода скриптом, а
 * третий аргумент разрешает задевать выгруженные чанки вместо исключения.
 */
function forksAround(dimension, origin, radius) {
	const out = [];
	let found;
	try {
		const range = dimension.heightRange;
		found = dimension.getBlocks(new BlockVolume(
			{ x: Math.floor(origin.x) - radius, y: Math.max(Math.floor(origin.y) - radius, range.min), z: Math.floor(origin.z) - radius },
			{ x: Math.floor(origin.x) + radius, y: Math.min(Math.floor(origin.y) + radius, range.max - 1), z: Math.floor(origin.z) + radius }
		), { includeTypes: [BLOCK_ID] }, true);
	} catch {
		return out;
	}
	for (const location of found.getBlockLocationIterator()) out.push({ x: location.x, y: location.y, z: location.z });
	return out;
}
const anchorOf = (loc) => ({ x: loc.x + 0.5, y: loc.y, z: loc.z + 0.5 });

/* ─── The block's entity twin ────────────────────────────────────────────── */

/** Pushes the states the client needs for rendering onto the entity. */
function syncFork(block, entity) {
	try {
		const perm = block.permutation;
		const face = perm.getState("minecraft:block_face") ?? "up";
		if (entity.getProperty("dd:face") !== face) entity.setProperty("dd:face", face);

		const octave = clampOctave(perm.getState("dd:octave"));
		if (entity.getProperty("dd:octave") !== octave) entity.setProperty("dd:octave", octave);
	} catch { /* entity unloaded mid-update */ }
}

/* ─── Tuning ─────────────────────────────────────────────────────────────── */

function readTuning(block) {
	try {
		const perm = block.permutation;
		return {
			note: clampNote(perm.getState("dd:note")),
			octave: clampOctave(perm.getState("dd:octave")),
			tone: clampTone(perm.getState("dd:tone"))
		};
	} catch {
		return undefined;
	}
}

function writeTuning(block, tuning) {
	try {
		block.setPermutation(
			block.permutation
				.withState("dd:note", clampNote(tuning.note))
				.withState("dd:octave", clampOctave(tuning.octave))
				.withState("dd:tone", clampTone(tuning.tone))
		);
	} catch (error) {
		console.warn(`[tuning_fork] tuning: ${error}`);
		return;
	}

}

/* ─── Ringing ────────────────────────────────────────────────────────────── */

/** The note glyph that floats above a ringing fork, e.g. `#A`. */
function spawnNoteGlyph(block, note) {
	const molang = new MolangVariableMap();
	molang.setFloat("variable.note", clampNote(note));

	const center = block.center();
	try {
		block.dimension.spawnParticle("dd:tuning_fork_note", { x: center.x, y: block.location.y + 1.35, z: center.z }, molang);
	} catch { /* chunk unloaded */ }
}

/**
 * Rings one fork.
 *
 * @param {import("@minecraft/server").Block} block
 * @param {{visited: Set<string>, hops: number}} [wave]
 *   The strike this ring belongs to. `visited` is shared by every fork in the
 *   chain so the vibration spreads outwards as a wavefront and never comes back.
 */
function ring(block, wave) {
	const tuning = readTuning(block);
	if (!tuning) return;

	const dimension = block.dimension;
	const key = posKey(dimension.id, block.location);

	const strike = wave ?? { visited: new Set([key]), hops: 0 };
	strike.visited.add(key);

	try {
		if (block.permutation.getState("dd:ringing") !== true) {
			block.setPermutation(block.permutation.withState("dd:ringing", true));
		}
	} catch { /* block gone */ }

	holdRinging(key, ringTicksOf(tuning.octave));

	playBlockEntity(block, ENTITY_ID, ringTicksOf(tuning.octave), (entity) => {
		syncFork(block, entity);
		entity.setProperty("dd:phase", 1);
	});

	let waterlogged = false;
	try {
		waterlogged = block.isWaterlogged;
	} catch { /* block gone */ }

	if (!waterlogged) {
		ringOut(
			{ dimension, location: block.center() },
			soundOf(tuning.tone),
			pitchOf(tuning.note, tuning.octave),
			ringTicksOf(tuning.octave)
		);
	}
	spawnNoteGlyph(block, tuning.note);

	VibrationManager.add(block.location, "tuning_fork_ring", {
		dimension: dimension.id,
		note: tuning.note,
		octave: tuning.octave,
		tone: tuning.tone,
		hops: strike.hops
	});

	if (strike.hops < MAX_HOPS) relay(block, tuning, strike);
}

/**
 * Sends the vibration on to every identically tuned fork in range, nearest
 * first. Each one is claimed here rather than on arrival, so two forks never
 * schedule the same neighbour twice.
 */
function relay(block, tuning, strike) {
	const dimension = block.dimension;
	const center = block.center();
	const range = rangeOf(tuning.octave);

	const targets = [];

	for (const location of forksAround(dimension, center, range)) {
		if (strike.visited.has(posKey(dimension.id, location))) continue;

		let target;
		try {
			target = dimension.getBlock(location);
		} catch {
			continue;
		}
		if (target?.typeId !== BLOCK_ID) continue;

		const other = readTuning(target);
		if (!other || !sameTuning(other, tuning)) continue;

		const to = target.center();
		targets.push({
			block: target,
			distance: Math.hypot(to.x - center.x, to.y - center.y, to.z - center.z)
		});
	}

	targets.sort((a, b) => a.distance - b.distance);

	for (const target of targets) {
		const targetKey = posKey(dimension.id, target.block.location);
		if (strike.visited.has(targetKey)) continue;

		strike.visited.add(targetKey);

		const sent = VibrationEventListener.send(block, target.block, "dd:fork_resonate", {
			wave: strike,
			hops: strike.hops + 1
		});

		if (sent === 0) strike.visited.delete(targetKey);
	}
}

/**
 * Rings every fork within `radius` of `origin` that is tuned to exactly this
 * note, octave and timbre. Each one then resonates on its own, so a struck fork
 * still passes the vibration down its own chain.
 *
 * This is how an instrument reaches the world: a harp playing A1 rings the forks
 * set to A1 on the harp timbre and leaves the rest alone.
 *
 * @param {import("@minecraft/server").Dimension} dimension
 * @param {import("@minecraft/server").Vector3} origin
 * @param {{note: number, octave: number, tone: number}} tuning
 * @returns {number} how many forks were struck
 */
export function strikeMatchingForks(dimension, origin, tuning, radius) {
	let struck = 0;

	for (const location of forksAround(dimension, origin, radius)) {
		let block;
		try {
			block = dimension.getBlock(location);
		} catch {
			continue;
		}
		if (block?.typeId !== BLOCK_ID) continue;

		const fork = readTuning(block);
		if (!fork || !sameTuning(fork, tuning)) continue;

		try {
			if (block.permutation.getState("dd:ringing") === true) continue;
		} catch {
			continue;
		}

		ring(block);
		struck++;
	}

	return struck;
}

VibrationEventListener.register("dd:fork_resonate", ({ block, payload }) => {
	if (block?.typeId !== BLOCK_ID) return;
	ring(block, { visited: payload.wave.visited, hops: payload.hops });
});

/** Заводит срок дрожи и попутно выметает сроки, которые уже прошли. */
function holdRinging(key, ticks) {
	const now = system.currentTick;
	for (const [old, until] of silence) if (until <= now) silence.delete(old);
	silence.set(key, now + Math.max(1, ticks));
}

/**
 * Молчит ли вилка, когда пора.
 *
 * Срока нет вовсе — значит эта вилка тут не звенела: её либо привёз поршень уже
 * дрожащей, либо она такой пережила перезагрузку. И то и другое кончается
 * тишиной немедленно.
 */
function settleRinging(block) {
	try {
		if (block.permutation.getState("dd:ringing") !== true) return;
	} catch {
		return;
	}

	const key = posKey(block.dimension.id, block.location);
	const until = silence.get(key);
	if (until !== undefined && system.currentTick < until) return;

	silence.delete(key);
	try {
		block.setPermutation(block.permutation.withState("dd:ringing", false));
	} catch { /* block gone */ }
}

/**
 * True when a fork right next to this one is ringing.
 *
 * A ringing fork puts out 15 on every face, which would otherwise power the fork
 * beside it and make a row light up regardless of how each one is tuned. Forks
 * pass their vibration on by tuning, not by touching, so a neighbour's own
 * output is not treated as a strike.
 */
function poweredByRingingFork(block) {
	for (const offset of NEIGHBOURS) {
		let neighbour;
		try {
			neighbour = block.offset(offset);
		} catch {
			continue;
		}
		if (neighbour?.typeId !== BLOCK_ID) continue;

		try {
			if (neighbour.permutation.getState("dd:ringing") === true) return true;
		} catch { /* chunk edge */ }
	}
	return false;
}

/** Rings the fork when the redstone level under it goes from off to on. */
function pollRedstone(block) {
	if (world.getDynamicProperty(WORLD_STATE) === 1) return;

	try {
		if (block.permutation.getState("dd:ringing") === true) return;
	} catch {
		return;
	}

	let power;
	try {
		power = block.getRedstonePower() ?? 0;
	} catch {
		return;
	}

	const key = posKey(block.dimension.id, block.location);
	const previous = lastPower.get(key) ?? 0;
	lastPower.set(key, power);

	if (previous >= 1 || power < 1) return;
	if (poweredByRingingFork(block)) return;

	ring(block);
}

/* ─── Block component ────────────────────────────────────────────────────── */

system.beforeEvents.startup.subscribe((init) => {
	init.blockComponentRegistry.registerCustomComponent("dd:tuning_fork", {
		beforeOnPlayerPlace(e) {
			e.permutationToPlace = e.permutationToPlace
				.withState("dd:note", DEFAULT_TUNING.note)
				.withState("dd:octave", DEFAULT_TUNING.octave)
				.withState("dd:tone", DEFAULT_TUNING.tone)
				.withState("dd:ringing", false)
				.withState("dd:has_entity", false);
		},

		onPlace(e) {
			const { block } = e;
			VibrationEventListener.onPlace(block);
		},

		onTick(e) {
			settleRinging(e.block);
			pollRedstone(e.block);
		},

		onBreak(e) {
			const { block } = e;
			const location = { ...block.location };
			const dimension = block.dimension;

			lastPower.delete(posKey(dimension.id, location));
			silence.delete(posKey(dimension.id, location));

			system.run(() => removeBlockEntity(dimension, location, ENTITY_ID));
		},

		onPlayerInteract(e) {
			const { block, player } = e;
			if (!player) return;

			if (player.isSneaking) return;

			const tuning = readTuning(block);
			if (!tuning) return;

			const location = { ...block.location };
			const dimension = block.dimension;

			system.run(() => {
				openTuningForm(player, tuning, (next, preview) => {
					let target;
					try {
						target = dimension.getBlock(location);
					} catch {
						return;
					}
					if (target?.typeId !== BLOCK_ID) return;

					writeTuning(target, next);

					try {
						player.onScreenDisplay.setActionBar({
							rawtext: [
								{ translate: "tile.dd:tuning_fork.name" },
								{ text: ": §a" },
								describeTuning(next.note, next.octave, next.tone),
								{ text: `§r — §7${rangeOf(next.octave)} ` },
								{ translate: "button.dd:blocks_short.name" },
								{ text: "§r" }
							]
						});
					} catch { /* player left */ }

					if (preview) ring(target);
				});
			});
		}
	});
});

/* ─── Being struck ───────────────────────────────────────────────────────── */

world.afterEvents.entityHitBlock.subscribe((e) => {
	if (e.hitBlock?.typeId !== BLOCK_ID) return;
	system.run(() => ring(e.hitBlock));
});

world.afterEvents.projectileHitBlock.subscribe((e) => {
	const hit = e.getBlockHit?.();
	if (hit?.block?.typeId !== BLOCK_ID) return;
	system.run(() => ring(hit.block));
});

/* ─── Keeping block and entity together ──────────────────────────────────── */

world.afterEvents.blockExplode.subscribe((e) => {
	if (e.explodedBlockPermutation?.type?.id !== BLOCK_ID) return;

	const location = { ...e.block.location };
	lastPower.delete(posKey(e.dimension.id, location));

	removeBlockEntity(e.dimension, location, ENTITY_ID);
});

world.afterEvents.entityLoad.subscribe((e) => {
	const entity = e.entity;
	if (entity?.typeId !== ENTITY_ID) return;

	system.run(() => {
		let block;
		try {
			block = entity.dimension.getBlock({
				x: Math.floor(entity.location.x),
				y: Math.floor(entity.location.y),
				z: Math.floor(entity.location.z)
			});
		} catch {
			return;
		}

		try { entity.remove(); } catch { /* already gone */ }
	});
});
