import { ModalFormData } from "@minecraft/server-ui";

import { showWhenFree } from "../../utils/forms.js";

import {
	NOTE_KEYS,
	OCTAVE_KEYS,
	TONES,
	clampNote,
	clampOctave,
	clampTone,
	rangeOf
} from "./notes.js";

/**
 * The tuning dialog. Opened by right-clicking a fork; the three dropdowns are
 * the block's three tuning states, pre-selected to whatever it is set to now.
 *
 * The dialog is drawn by RP/ui/dd/tuning_fork_screen.json rather than by the
 * default server-form layout. That skin is picked purely off the title: the UI
 * hides the vanilla form and draws its own panel whenever the title starts with
 * TITLE_PREFIX, then strips the prefix and localises what is left. So the title
 * is a marker plus a .lang key, never free text, and any change here has to be
 * mirrored in the `$title_needs_to_contain` values on the resource-pack side.
 */

const TITLE_PREFIX = "dd:fork.";
const TITLE_KEY = "tuning_fork.title";

/** Label text lives in RP/texts/*.lang; these wrap a key as a RawMessage. */
const tr = (name) => ({ translate: `button.dd:${name}.name` });
const tr_key = (key) => ({ translate: key });

/** A translated label with a live number after it, without needing %s in .lang. */
const withRange = (name, blocks) => ({
	rawtext: [tr(name), { text: ` — ${blocks} ` }, tr("blocks_short")]
});

/**
 * @param {import("@minecraft/server").Player} player
 * @param {{note: number, octave: number, tone: number}} tuning current settings
 * @param {(tuning: {note: number, octave: number, tone: number}, preview: boolean) => void} onApply
 */
export async function openTuningForm(player, tuning, onApply) {
	const form = new ModalFormData()
		.title(TITLE_PREFIX + TITLE_KEY)
		.dropdown(tr("fork_note"), NOTE_KEYS.map(tr_key), { defaultValueIndex: clampNote(tuning.note) })
		.dropdown(withRange("fork_octave", rangeOf(tuning.octave)), OCTAVE_KEYS.map(tr_key), {
			defaultValueIndex: clampOctave(tuning.octave)
		})
		.dropdown(tr("fork_tone"), TONES.map((t) => tr_key(t.key)), { defaultValueIndex: clampTone(tuning.tone) })
		.toggle(tr("fork_preview"), { defaultValue: true })
		.submitButton(tr("fork_submit"));

	let response;
	try {
		response = await showWhenFree(form, player);
	} catch (error) {
		console.warn(`[tuning_fork] form: ${error}`);
		return;
	}

	if (!response || response.canceled) return;

	const [note, octave, tone, preview] = response.formValues;

	onApply(
		{ note: clampNote(note), octave: clampOctave(octave), tone: clampTone(tone) },
		preview === true
	);
}
