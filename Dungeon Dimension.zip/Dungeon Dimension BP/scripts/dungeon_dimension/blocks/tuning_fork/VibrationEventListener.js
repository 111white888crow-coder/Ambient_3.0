import { world, system, MolangVariableMap } from "@minecraft/server";
import { VibrationManager } from "./VibrationManager.js";
import { VIBRATION_SPEED } from "./notes.js";

/**
 * The listening half of the vibration system: occlusion, travel time and the
 * callback registry that turns "a vibration reached this block" into a script
 * call.
 *
 * A vibration is never instant. It leaves the source, flies at VIBRATION_SPEED
 * and only fires the callback when it actually arrives — which is what makes a
 * row of forks ring one after another instead of all at once.
 */

/** Positions with a vibration already in flight towards them, so they are not re-triggered mid-travel. */
const inFlight = {
	_keys: new Set(),
	_propertyKey: "dd:vibration_locks",

	init() {
		try {
			const raw = world.getDynamicProperty(this._propertyKey);
			this._keys = raw ? new Set(JSON.parse(raw)) : new Set();
		} catch {
			this._keys = new Set();
		}
	},

	_save() {
		world.setDynamicProperty(this._propertyKey, JSON.stringify([...this._keys]));
	},

	keyOf(dimensionId, loc) {
		return `${dimensionId}|${Math.floor(loc.x)},${Math.floor(loc.y)},${Math.floor(loc.z)}`;
	},

	add(dimensionId, loc) {
		const key = this.keyOf(dimensionId, loc);
		if (this._keys.has(key)) return;
		this._keys.add(key);
		this._save();
	},

	remove(dimensionId, loc) {
		const key = this.keyOf(dimensionId, loc);
		if (!this._keys.delete(key)) return;
		this._save();
	},

	has(dimensionId, loc) {
		return this._keys.has(this.keyOf(dimensionId, loc));
	}
};

inFlight.init();

/**
 * Blocks that swallow a vibration instead of passing it on. Accepts a Block or a
 * BlockPermutation, because playerBreakBlock only hands back the permutation.
 */
export function isSilentBlock(block) {
	if (!block) return false;

	const id = block.typeId ?? block.type?.id;
	if (!id) return false;
	if (id.includes("wool") || id.includes("carpet")) return true;

	try {
		if (block.hasTag?.("minecraft:wool")) return true;
	} catch { /* permutations without tag support */ }

	return false;
}

/**
 * Walks the voxels between two points (a 3D DDA) and reports whether any of
 * them muffles sound. Both endpoints are skipped: a fork sitting on a wool
 * block still works, it is only wool *in the way* that stops the signal.
 */
export function isPathBlocked(dimension, start, end) {
	let x = Math.floor(start.x);
	let y = Math.floor(start.y);
	let z = Math.floor(start.z);

	const endX = Math.floor(end.x);
	const endY = Math.floor(end.y);
	const endZ = Math.floor(end.z);

	const dx = end.x - start.x;
	const dy = end.y - start.y;
	const dz = end.z - start.z;

	const stepX = Math.sign(dx);
	const stepY = Math.sign(dy);
	const stepZ = Math.sign(dz);

	const tDeltaX = dx !== 0 ? Math.abs(1 / dx) : Infinity;
	const tDeltaY = dy !== 0 ? Math.abs(1 / dy) : Infinity;
	const tDeltaZ = dz !== 0 ? Math.abs(1 / dz) : Infinity;

	let tMaxX = stepX > 0 ? (Math.floor(start.x) + 1 - start.x) * tDeltaX : (start.x - Math.floor(start.x)) * tDeltaX;
	let tMaxY = stepY > 0 ? (Math.floor(start.y) + 1 - start.y) * tDeltaY : (start.y - Math.floor(start.y)) * tDeltaY;
	let tMaxZ = stepZ > 0 ? (Math.floor(start.z) + 1 - start.z) * tDeltaZ : (start.z - Math.floor(start.z)) * tDeltaZ;

	const MAX_STEPS = 128;

	for (let step = 0; step < MAX_STEPS; step++) {
		if (x === endX && y === endY && z === endZ) return false;

		if (tMaxX < tMaxY && tMaxX < tMaxZ) {
			x += stepX;
			tMaxX += tDeltaX;
		} else if (tMaxY < tMaxZ) {
			y += stepY;
			tMaxY += tDeltaY;
		} else {
			z += stepZ;
			tMaxZ += tDeltaZ;
		}

		if (x === endX && y === endY && z === endZ) return false;

		let block;
		try {
			block = dimension.getBlock({ x, y, z });
		} catch {
			return true;
		}
		if (isSilentBlock(block)) return true;
	}

	return false;
}

/** Nearest unblocked vibration to `center`, or null. */
export function findNearestVibration(dimension, center, radius) {
	const all = VibrationManager.getAll();
	if (all.length === 0) return null;

	let nearest = null;
	let minDistSq = radius * radius;

	for (const v of all) {
		if (v.dimension && v.dimension !== dimension.id) continue;

		const at = { x: v.vibration.x + 0.5, y: v.vibration.y + 0.5, z: v.vibration.z + 0.5 };
		const dx = at.x - center.x;
		const dy = at.y - center.y;
		const dz = at.z - center.z;
		const distSq = dx * dx + dy * dy + dz * dz;

		if (distSq > minDistSq) continue;
		if (isPathBlocked(dimension, center, at)) continue;

		nearest = v;
		minDistSq = distSq;
	}

	return nearest ? { vibration: nearest, distance: Math.sqrt(minDistSq) } : null;
}

/** Ticks a vibration needs to cross `distance` blocks. Never less than one. */
export function travelTicks(distance) {
	return Math.max(1, Math.floor(distance / VIBRATION_SPEED));
}

/** Draws the pulse flying from `from` to `to`, arriving after `ticks`. */
export function spawnSignal(dimension, from, to, ticks) {
	const dx = to.x - from.x;
	const dy = to.y - from.y;
	const dz = to.z - from.z;
	const distance = Math.hypot(dx, dy, dz) || 1;

	const molang = new MolangVariableMap();
	molang.setVector3("variable.dir", { x: dx / distance, y: dy / distance, z: dz / distance });
	molang.setFloat("variable.lifetime", ticks / 20);

	try {
		dimension.spawnParticle("dd:resonance_signal", from, molang);
	} catch { /* chunk unloaded */ }
}

export const VibrationEventListener = {
	_registry: new Map(),

	register(id, callback) {
		this._registry.set(id, callback);
	},

	/**
	 * Marks a freshly placed block as deaf for a couple of ticks, so it does not
	 * hear the placement that created it.
	 */
	onPlace(block) {
		const key = `dd:sensor_init|${inFlight.keyOf(block.dimension.id, block.location)}`;
		world.setDynamicProperty(key, true);
		system.runTimeout(() => world.setDynamicProperty(key, undefined), 3);
	},

	isDeaf(block) {
		return world.getDynamicProperty(`dd:sensor_init|${inFlight.keyOf(block.dimension.id, block.location)}`) === true;
	},

	playSound(block, sound, options) {
		if (block.isWaterlogged) return;
		try {
			block.dimension.playSound(sound, block.center(), options ?? { volume: 1, pitch: 1 });
		} catch { /* chunk unloaded */ }
	},

	/**
	 * Sends a vibration from `block` to `target`, firing `callbackId` there once
	 * it arrives. Returns the arrival delay in ticks, or 0 if nothing was sent.
	 */
	send(block, target, callbackId, payload = {}) {
		const dimension = block.dimension;
		const from = block.center();
		const to = target.center();

		if (inFlight.has(dimension.id, target.location)) return 0;
		if (isPathBlocked(dimension, from, to)) return 0;

		const distance = Math.hypot(to.x - from.x, to.y - from.y, to.z - from.z);
		const ticks = travelTicks(distance);

		inFlight.add(dimension.id, target.location);
		spawnSignal(dimension, from, to, ticks);

		const targetLocation = { ...target.location };

		system.runTimeout(() => {
			inFlight.remove(dimension.id, targetLocation);

			const callback = this._registry.get(callbackId);
			if (!callback) return;

			let arrived;
			try {
				arrived = dimension.getBlock(targetLocation);
			} catch {
				return;
			}
			if (!arrived) return;

			callback({ block: arrived, dimension, distance, payload });
		}, ticks);

		return ticks;
	},

	/**
	 * Sculk-sensor style listening: looks for the nearest world vibration within
	 * `radius` and fires `callbackId` on this block when it arrives.
	 */
	run(block, callbackId, options = {}) {
		const dimension = block.dimension;
		if (this.isDeaf(block)) return;
		if (inFlight.has(dimension.id, block.location)) return;

		const found = findNearestVibration(dimension, block.center(), options.radius ?? 8);
		if (!found) return;

		const { vibration, distance } = found;
		const ticks = travelTicks(distance);
		const source = {
			x: vibration.vibration.x + 0.5,
			y: vibration.vibration.y + 0.5,
			z: vibration.vibration.z + 0.5
		};

		inFlight.add(dimension.id, block.location);
		spawnSignal(dimension, source, block.center(), ticks);

		const location = { ...block.location };

		system.runTimeout(() => {
			inFlight.remove(dimension.id, location);

			const callback = this._registry.get(callbackId);
			if (!callback) return;

			let arrived;
			try {
				arrived = dimension.getBlock(location);
			} catch {
				return;
			}
			if (!arrived) return;

			callback({ block: arrived, dimension, vibrationData: vibration, distance, extras: options });
		}, ticks);
	}
};
