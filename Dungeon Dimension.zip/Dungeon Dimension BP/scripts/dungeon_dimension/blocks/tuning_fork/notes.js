/**
 * Musical model behind dd:tuning_fork.
 *
 * A fork is tuned by three numbers, all of them block states so the tuning
 * survives a chunk reload without any bookkeeping of our own:
 *
 *   dd:note   0..11  which semitone, F# .. F (see NOTE_NAMES)
 *   dd:octave 0..2   how high it sits, 0 is the lowest
 *   dd:tone   0..7   the timbre it rings with (тональность)
 *
 * The note index deliberately starts at F#, because that is what a vanilla note
 * block plays at pitch 0.5. Keeping the same origin means
 * `pitchOf(note, octave)` is the plain note-block formula and the fork stays in
 * tune with note blocks, bells and anything else built on that scale.
 */

/** Index -> glyph, in the order the note_symbols atlas is laid out (4x4, row-major). */
export const NOTE_NAMES = ["#F", "G", "#G", "A", "#A", "B", "C", "#C", "D", "#D", "E", "F"];

/**
 * Every string a player reads lives in RP/texts/*.lang, not here, so the pack
 * can be translated without touching script. These are the keys; the forms hand
 * them to Bedrock as `{ translate }` RawMessages, which every label, dropdown
 * item and submit button accepts.
 */
export const NOTE_KEYS = NOTE_NAMES.map((_, i) => `button.dd:note_${i}.name`);

export const OCTAVE_KEYS = [0, 1, 2].map((i) => `button.dd:octave_${i}.name`);

/**
 * Timbres a fork can be set to. `sound` is a vanilla note-block sound event, so
 * no sound_definitions.json entry is needed.
 */
export const TONES = [
	{ id: "harp", sound: "note.harp" },
	{ id: "bell", sound: "note.bell" },
	{ id: "chime", sound: "note.chime" },
	{ id: "flute", sound: "note.flute" },
	{ id: "guitar", sound: "note.guitar" },
	{ id: "xylophone", sound: "note.xylophone" },
	{ id: "bass", sound: "note.bass" },
	{ id: "pling", sound: "note.pling" }
].map((tone) => ({ ...tone, key: `button.dd:tone_${tone.id}.name` }));

export const NOTE_COUNT = NOTE_NAMES.length;
export const OCTAVE_COUNT = OCTAVE_KEYS.length;
export const TONE_COUNT = TONES.length;

/**
 * How far a fork's vibration carries, in blocks. Low notes travel: a long
 * wavelength loses less energy on the way, so octave 0 reaches three times as
 * far as octave 2.
 */
const RANGE_BY_OCTAVE = [24, 16, 9];

/** How long the fork keeps ringing (and keeps its redstone output up), in ticks. */
const RING_TICKS_BY_OCTAVE = [70, 45, 28];

/** Speed of the travelling vibration, in blocks per tick. Matches dd:resonance_signal. */
export const VIBRATION_SPEED = 1;

export const clampNote = (n) => Math.max(0, Math.min(NOTE_COUNT - 1, Math.floor(n ?? 0)));
export const clampOctave = (o) => Math.max(0, Math.min(OCTAVE_COUNT - 1, Math.floor(o ?? 1)));
export const clampTone = (t) => Math.max(0, Math.min(TONE_COUNT - 1, Math.floor(t ?? 0)));

/**
 * Playback pitch for a tuning. Same curve as a note block: step 0 is 0.5 and
 * every twelve steps double it.
 */
export function pitchOf(note, octave) {
	const step = clampOctave(octave) * NOTE_COUNT + clampNote(note);
	return Number(Math.pow(2, (step - 12) / 12).toFixed(4));
}

export function soundOf(tone) {
	return TONES[clampTone(tone)].sound;
}

export function rangeOf(octave) {
	return RANGE_BY_OCTAVE[clampOctave(octave)];
}

export function ringTicksOf(octave) {
	return RING_TICKS_BY_OCTAVE[clampOctave(octave)];
}

/**
 * Human-readable tuning, e.g. `#A·2 Колокольчик`, as a RawMessage so the timbre
 * name is translated rather than baked in. Action bars and chat both take one.
 */
export function describeTuning(note, octave, tone) {
	return {
		rawtext: [
			{ text: `${NOTE_NAMES[clampNote(note)]}·${clampOctave(octave)} ` },
			{ translate: TONES[clampTone(tone)].key }
		]
	};
}

/** Two forks resonate only when all three settings match exactly. */
export function sameTuning(a, b) {
	return a.note === b.note && a.octave === b.octave && a.tone === b.tone;
}
