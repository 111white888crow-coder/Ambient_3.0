import { world, system } from "@minecraft/server";
import { VibrationManager } from "./VibrationManager.js";
import { isSilentBlock } from "./VibrationEventListener.js";

/**
 * Feeds the VibrationManager from ordinary world events, so anything that
 * listens for vibrations (a fork, a sculk sensor, a future trap) gets one
 * consistent stream of noise instead of subscribing to a dozen events itself.
 *
 * Wool and carpet are silent, exactly as they are in vanilla: standing on them,
 * breaking them or placing them makes no vibration at all.
 */

const MOVEMENT_THRESHOLD = 0.001;
const playerStates = new Map();

world.afterEvents.playerBreakBlock.subscribe(({ block, brokenBlockPermutation }) => {
	if (!isSilentBlock(brokenBlockPermutation)) {
		VibrationManager.add(block.location, "block_break", { dimension: block.dimension.id });
	}
});

world.afterEvents.playerPlaceBlock.subscribe(({ block }) => {
	if (!isSilentBlock(block)) {
		VibrationManager.add(block.location, "block_place", { dimension: block.dimension.id });
	}
});

world.afterEvents.itemCompleteUse.subscribe(({ source }) => {
	if (source?.location) {
		VibrationManager.add(source.location, "item_use", { dimension: source.dimension.id });
	}
});

world.afterEvents.explosion.subscribe((e) => {
	const at = e.source?.location ?? e.getImpactedBlocks()[0]?.location;
	if (at) VibrationManager.add(at, "explosion", { dimension: e.dimension.id });
});

world.afterEvents.projectileHitBlock.subscribe((e) => {
	VibrationManager.add(e.location, "projectile_hit", { dimension: e.dimension.id });
});

system.runInterval(() => {
	for (const player of world.getAllPlayers()) {
		if (player) detectPlayerMovement(player);
	}
});

function detectPlayerMovement(player) {
	const prevState = playerStates.get(player.id);
	savePlayerState(player);

	if (!prevState) return;
	if (player.isSneaking) return;

	const currentLoc = player.location;
	const isOnGround = player.isOnGround;

	const dx = currentLoc.x - prevState.loc.x;
	const dz = currentLoc.z - prevState.loc.z;
	const movedOnFoot = isOnGround && dx * dx + dz * dz > MOVEMENT_THRESHOLD;
	const justLanded = !prevState.isOnGround && isOnGround;

	if (!movedOnFoot && !justLanded) return;
	if (!standsOnNoisyGround(player, justLanded)) return;

	VibrationManager.add(player.location, "player_move", { dimension: player.dimension.id });
}

/** True when at least one block under the player's feet is not wool or carpet. */
function standsOnNoisyGround(player, justLanded) {
	const standingBlocks = player.getAllBlocksStandingOn ? player.getAllBlocksStandingOn() : [];

	if (standingBlocks.length > 0) {
		return standingBlocks.some((block) => !isSilentBlock(block));
	}

	if (!justLanded) return false;

	const loc = player.location;
	const dim = player.dimension;

	for (const off of [{ x: 0, z: 0 }, { x: 0.3, z: 0 }, { x: -0.3, z: 0 }, { x: 0, z: 0.3 }, { x: 0, z: -0.3 }]) {
		let below;
		try {
			below = dim.getBlock({
				x: Math.floor(loc.x + off.x),
				y: Math.floor(loc.y - 0.5),
				z: Math.floor(loc.z + off.z)
			});
		} catch {
			continue;
		}
		if (below && !below.isAir && !isSilentBlock(below)) return true;
	}
	return false;
}

function savePlayerState(player) {
	playerStates.set(player.id, {
		loc: { x: player.location.x, y: player.location.y, z: player.location.z },
		isOnGround: player.isOnGround
	});
}

world.afterEvents.playerLeave.subscribe((e) => playerStates.delete(e.playerId));
