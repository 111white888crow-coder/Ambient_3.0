import { world, system } from "@minecraft/server";

/**
 * A world-wide list of "something made a noise here" records, short-lived by
 * design: a vibration only exists for the couple of ticks a listener needs to
 * notice it.
 *
 * Kept in a world dynamic property rather than a plain Map so a listener that
 * loads a tick late (or a chunk that streams in) still sees the same list. The
 * list is tiny — anything older than VIBRATION_DURATION is dropped every tick.
 */

const WORLD_VIBRATION_PROP = "dd:vibrations";
const VIBRATION_DURATION = 3;

export class VibrationManager {
	/**
	 * @param {import("@minecraft/server").Vector3} location
	 * @param {string} cause  free-form label, e.g. "tuning_fork_ring"
	 * @param {object} [data] extra payload a listener may care about
	 */
	static add(location, cause, data = null) {
		const list = this._getAll();

		list.push({
			vibration: {
				x: Math.floor(location.x),
				y: Math.floor(location.y),
				z: Math.floor(location.z)
			},
			dimension: data?.dimension ?? undefined,
			cause,
			data,
			tickCreated: system.currentTick
		});

		this._save(list);
	}

	static getAll() {
		return this._getAll();
	}

	static _getAll() {
		try {
			const raw = world.getDynamicProperty(WORLD_VIBRATION_PROP);
			return raw ? JSON.parse(raw) : [];
		} catch {
			return [];
		}
	}

	static _save(list) {
		world.setDynamicProperty(WORLD_VIBRATION_PROP, JSON.stringify(list));
	}

	static _tick() {
		const list = this._getAll();
		if (list.length === 0) return;

		const currentTick = system.currentTick;
		const kept = list.filter((v) => currentTick - v.tickCreated < VIBRATION_DURATION);

		if (kept.length !== list.length) this._save(kept);
	}
}

system.runInterval(() => VibrationManager._tick());
