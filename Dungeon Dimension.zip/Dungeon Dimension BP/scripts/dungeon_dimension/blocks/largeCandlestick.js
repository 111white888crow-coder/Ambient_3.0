import { world, system, GameMode, EquipmentSlot, WeatherType } from "@minecraft/server";
const BLOCK_ID = "dd:large_candlestick";
const FIRE_STATE = "dd:fire";
const PART_STATE = "minecraft:multi_block_part";
const IGNITERS = new Set(["minecraft:flint_and_steel", "minecraft:fire_charge"]);
const HAND_EXTINGUISHERS = new Set(["minecraft:water_bucket", "minecraft:potion"]);
const SPLASH_ITEMS = new Set(["minecraft:splash_potion", "minecraft:lingering_potion"]);
const SPLASH_ENTITIES = new Set(["minecraft:splash_potion", "minecraft:lingering_potion"]);
const LIGHT_SOUND = "fire.ignite";
const EXTINGUISH_SOUND = "extinguish.candle";
const FLAME = "minecraft:candle_flame_particle";
const SMOKE = "minecraft:basic_smoke_particle";
const SMOKE_CHANCE = 0.3;
const BOWL_Y = 0.78;
const BOWL_HALF = 0.22;
const FLAMES_PER_TICK = 2;
const SPLASH_RADIUS = 3;
const SPLASH_MEMORY = 200;

const isCandlestick = (block) => block?.typeId === BLOCK_ID;
const isLit = (block) => block.permutation.getState(FIRE_STATE) === 1;
const partOf = (block) => block.permutation.getState(PART_STATE) ?? 0;

function otherPart(block) {
	try { return partOf(block) === 0 ? block.above() : block.below(); }
	catch { return undefined; }
}

function light(block, on) {
	try {
		if (block.permutation.getState(FIRE_STATE) === (on ? 1 : 0)) return;
		block.setPermutation(block.permutation.withState(FIRE_STATE, on ? 1 : 0));
	} catch (error) { console.warn(`[large_candlestick] fire: ${error}`); }
}

function setFlame(block, on, sound) {
	if (!isCandlestick(block)) return;
	light(block, on);
	const other = otherPart(block);
	if (isCandlestick(other)) light(other, on);
	if (sound) block.dimension.playSound(sound, block.center());
}

function payForIgnition(player, held) {
	if (player.getGameMode() === GameMode.Creative) return;
	const equipment = player.getComponent("minecraft:equippable");
	if (!equipment) return;
	const durability = held.getComponent("minecraft:durability");
	if (durability !== undefined) {
		if (durability.damage + 1 >= durability.maxDurability) equipment.setEquipment(EquipmentSlot.Mainhand, undefined);
		else { durability.damage += 1; equipment.setEquipment(EquipmentSlot.Mainhand, held); }
		return;
	}
	if (held.amount > 1) { held.amount -= 1; equipment.setEquipment(EquipmentSlot.Mainhand, held); }
	else equipment.setEquipment(EquipmentSlot.Mainhand, undefined);
}

function hasTag(itemStack, tag) {
	try { return itemStack.hasTag(tag); } catch { return false; }
}

world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
	const { block, player, itemStack: held } = event;
	if (!isCandlestick(block) || held === undefined) return;
	const lit = isLit(block);

	if (lit && (hasTag(held, "minecraft:is_shovel") || HAND_EXTINGUISHERS.has(held.typeId) || SPLASH_ITEMS.has(held.typeId))) {
		event.cancel = true;
		system.run(() => { if (isCandlestick(block) && isLit(block)) setFlame(block, false, EXTINGUISH_SOUND); });
		return;
	}

	if (!lit && IGNITERS.has(held.typeId)) {
		event.cancel = true;
		system.run(() => {
			if (!isCandlestick(block) || isLit(block)) return;
			setFlame(block, true, LIGHT_SOUND);
			payForIgnition(player, held);
		});
	}
});

const weather = new Map();
world.afterEvents.weatherChange.subscribe((event) => weather.set(event.dimension, event.newWeather));

function raining(dimension) {
	try { if (typeof dimension.getWeather === "function") return dimension.getWeather() !== WeatherType.Clear; } catch { }
	return (weather.get(dimension.id) ?? WeatherType.Clear) !== WeatherType.Clear;
}

function underOpenSky(block) {
	try {
		const top = block.dimension.getTopmostBlock({ x: block.x, z: block.z });
		return top === undefined || top.y <= block.y;
	} catch { return false; }
}

function drowned(block) {
	try {
		if (block.isWaterlogged) return true;
		const other = otherPart(block);
		return other !== undefined && other.isWaterlogged;
	} catch { return false; }
}

function isWaterBottle(itemStack) {
	try {
		const potion = itemStack.getComponent("minecraft:potion");
		if (potion === undefined) return true;
		const effect = potion.potionEffectType?.id;
		return effect === undefined || String(effect).endsWith("none");
	} catch { return true; }
}

const waterThrows = new Map();

world.afterEvents.itemUse.subscribe((event) => {
	const { itemStack, source } = event;
	if (!itemStack || !SPLASH_ITEMS.has(itemStack.typeId) || !isWaterBottle(itemStack)) return;
	const now = system.currentTick;
	for (const [id, tick] of waterThrows) if (now - tick > SPLASH_MEMORY) waterThrows.delete(id);
	waterThrows.set(source.id, now);
});

function splashOut(dimension, location, source) {
	const thrown = source === undefined ? undefined : waterThrows.get(source.id);
	if (thrown === undefined || system.currentTick - thrown > SPLASH_MEMORY) return;
	const cx = Math.floor(location.x), cy = Math.floor(location.y), cz = Math.floor(location.z);
	for (let dx = -SPLASH_RADIUS; dx <= SPLASH_RADIUS; dx++)
		for (let dy = -SPLASH_RADIUS; dy <= SPLASH_RADIUS; dy++)
			for (let dz = -SPLASH_RADIUS; dz <= SPLASH_RADIUS; dz++) {
				try {
					const block = dimension.getBlock({ x: cx + dx, y: cy + dy, z: cz + dz });
					if (isCandlestick(block) && isLit(block)) setFlame(block, false, EXTINGUISH_SOUND);
				} catch { }
			}
}

const onSplash = (event) => {
	if (!SPLASH_ENTITIES.has(event.projectile?.typeId)) return;
	splashOut(event.dimension, event.location, event.source);
};
world.afterEvents.projectileHitBlock.subscribe(onSplash);
world.afterEvents.projectileHitEntity.subscribe(onSplash);

system.beforeEvents.startup.subscribe((init) => {
	init.blockComponentRegistry.registerCustomComponent("dd:candlestick_flame", {
		onTick(event) {
			const { block, dimension } = event;
			if (!isCandlestick(block) || !isLit(block)) return;
			if (drowned(block) || (raining(dimension) && underOpenSky(block))) {
				system.run(() => { if (isCandlestick(block) && isLit(block)) setFlame(block, false, EXTINGUISH_SOUND); });
				return;
			}
			for (let i = 0; i < FLAMES_PER_TICK; i++) {
				const at = {
					x: block.x + 0.5 + (Math.random() * 2 - 1) * BOWL_HALF,
					y: block.y + BOWL_Y,
					z: block.z + 0.5 + (Math.random() * 2 - 1) * BOWL_HALF
				};
				try {
					dimension.spawnParticle(FLAME, at);
					if (Math.random() < SMOKE_CHANCE) dimension.spawnParticle(SMOKE, at);
				} catch { }
			}
		}
	});

	init.blockComponentRegistry.registerCustomComponent("dd:candlestick", {
		onPlace(event) {
			const { block } = event;
			system.run(() => {
				if (!isCandlestick(block)) return;
				const other = otherPart(block);
				if (isCandlestick(other)) light(block, isLit(other));
			});
		}
	});
});
