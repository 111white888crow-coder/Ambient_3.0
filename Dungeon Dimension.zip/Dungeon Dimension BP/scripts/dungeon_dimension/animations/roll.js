import { world, system } from "@minecraft/server";

const A = { enable: true, cooldown: 15, horiz: 10, vert: 10, postInvuln: false };
const lastRollTick = new Map();
const lastSneakTime = new Map();
const playerSneakState = new Map();
const DOUBLE_SNEAK_WINDOW = 10;

const rollSubscribers = new Set();

export const RollSystem = {

  onRoll(callback) {
    rollSubscribers.add(callback);
  }
};

function norm2D(x, z) {
  const L = Math.hypot(x, z);
  return L > 1e-6 ? { x: x / L, z: z / L } : { x: 0, z: 0 };
}

function safePlayAnimation(entity, name, options = {}) {
  try { entity.playAnimation?.(name, options); } catch { try { entity.playAnimation?.(name, options.blendOutTime ?? 0); } catch { } }
}

function safeEffect(entity, id, duration, amplifier = 0, particles = false) {
  try { entity.addEffect?.(id, duration, { amplifier, showParticles: particles }); } catch { try { entity.addEffect?.(id, duration, amplifier, particles); } catch { } }
}

function pushPlayer(player, dir, h, v) {
  const d = norm2D(dir.x, dir.z);
  try { player.applyKnockback(d.x, d.z, h, v); return true; } catch { }
  try { player.applyImpulse({ x: d.x * h * 0.45, y: v * 0.06, z: d.z * 0.45 * h }); return true; } catch { }
  return false;
}

function getRelativeDirection(rotY, moveHeading) {
  let diff = moveHeading - rotY;
  while (diff > 180) diff -= 360;
  while (diff < -180) diff += 360;

  if (Math.abs(diff) <= 45) return "forward";
  if (Math.abs(diff) >= 135) return "backward";
  return diff < 0 ? "right" : "left";
}

function doRoll(player) {
  if (!A.enable) return;

  try {
    if (player.isGliding || player.isInWater || player.isRiptiding) return;
  } catch (e) { }

  const last = lastRollTick.get(player.id) ?? -1e9;
  if (system.currentTick - last < A.cooldown) return;

//  const rollCost = StaminaManager.BASE_COSTS.ROLL_USE;
//  if (!StaminaManager.hasEnoughStamina(player, rollCost, "ROLL_USE")) return;

//  StaminaManager.consumeStamina(player, rollCost, "roll_use");

  const vel = player.getVelocity?.() ?? { x: 0, y: 0, z: 0 };
  const rot = player.getRotation?.() ?? { x: 0, y: 0, z: 0 };
  const lookRad = (rot.y + 45) * Math.PI / 180;
  const lookDir = { x: Math.cos(lookRad) - Math.sin(lookRad), z: Math.sin(lookRad) + Math.cos(lookRad) };

  const moving = Math.hypot(vel.x, vel.z) > 0.03;
  const moveDir = moving ? norm2D(vel.x, vel.z) : norm2D(lookDir.x, lookDir.z);

  let moveHeading = Math.atan2(moveDir.z, moveDir.x) * 180 / Math.PI - 90;
  if (moveHeading < -180) moveHeading += 360;

  const direction = moving ? getRelativeDirection(rot.y, moveHeading) : "forward";

  let h = 1.3 * (0.2 * A.horiz);
  let v = 0.30 * (0.05 * A.vert);

  if (direction === "backward") {
    h = 1.8 * (0.2 * A.horiz);
    v = 0.18 * (0.05 * A.vert);
  }

  safePlayAnimation(player, "animation.dd.reset", { blendOutTime: 0.1 });
  player.addTag("dd:evading");
  system.runTimeout(() => { if (player.isValid) player.removeTag("dd:evading"); }, 12);

  pushPlayer(player, moveDir, h, v);
  if (A.postInvuln) safeEffect(player, "resistance", 10, 16, false);
  lastRollTick.set(player.id, system.currentTick);

  let handled = false;
  for (const callback of rollSubscribers) {
    if (callback(player, direction)) {
      handled = true;
      break;
    }
  }

  if (!handled) {
    let anim = "animation.h.ru";
    let animDef = "animation.h.rs";

    if (direction === "backward") {
      anim = "animation.h.rd";
      animDef = "animation.h.r2";
    }

    safePlayAnimation(player, animDef, { blendOutTime: 0.3, controller: "roll_steady_controller" });
    safePlayAnimation(player, anim, { controller: "roll_controller" });
    safePlayAnimation(player, "animation.h.rh", { blendOutTime: 1, controller: "roll_head_controller" });
  }
}

system.runInterval(() => {
  try {
    for (const player of world.getAllPlayers()) {
      const isSneaking = player.isSneaking;
      const wasSneak = playerSneakState.get(player.id) ?? false;

      if (isSneaking && !wasSneak) {
        const lastTime = lastSneakTime.get(player.id) ?? -1e9;
        const currentTick = system.currentTick;

        if (currentTick - lastTime <= DOUBLE_SNEAK_WINDOW) {
          doRoll(player);
          lastSneakTime.set(player.id, -1e9);
        } else {
          lastSneakTime.set(player.id, currentTick);
        }
      }
      playerSneakState.set(player.id, isSneaking);
    }
  } catch (e) { }
}, 1);

try {
  world.afterEvents.playerLeave.subscribe(ev => {
    lastRollTick.delete(ev.playerId);
    lastSneakTime.delete(ev.playerId);
    playerSneakState.delete(ev.playerId);
  });
} catch { }

export { };
