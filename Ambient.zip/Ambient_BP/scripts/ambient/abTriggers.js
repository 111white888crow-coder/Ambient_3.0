import { world, system, BlockPermutation } from "@minecraft/server";

const NEIGHBOR_OFFSETS = [
    { dx: 1, dy: 0, dz: 0, dir: "east" }, { dx: -1, dy: 0, dz: 0, dir: "west" },
    { dx: 0, dy: 0, dz: 1, dir: "south" }, { dx: 0, dy: 0, dz: -1, dir: "north" },
    { dx: 0, dy: 1, dz: 0, dir: "up" }, { dx: 0, dy: -1, dz: 0, dir: "down" },
];

export const abTriggers = {
    _tagBehaviours: new Map(),
    registerBehaviourByTag(tag, callbacks) {
        if (!this._tagBehaviours.has(tag)) this._tagBehaviours.set(tag, []);
        this._addUnique(this._tagBehaviours.get(tag), callbacks);
    },
    _addUnique(list, callbacks) {
        if (!callbacks) return;
        const signature = signatureOf(callbacks);
        if (list.some(existing => signatureOf(existing) === signature)) return;
        list.push(callbacks);
    },
    notifyNeighbours(block, extra = {}) {
        if (!block) return;
        const dimension = block.dimension;
        const location = block.location;
        for (const off of NEIGHBOR_OFFSETS) {
            const neighbour = safeGetBlock(dimension, {
                x: location.x + off.dx,
                y: location.y + off.dy,
                z: location.z + off.dz,
            });
            if (!neighbour) continue;
            const bhList = getBehavioursFor(neighbour);
            if (bhList.length === 0) continue;
            runBehaviours(bhList, "onAdjacentChange", {
                ...extra, changedBlock: block, block: neighbour, direction: off.dir, dimension,
            });
        }
    },
};

function signatureOf(callbacks) {
    return Object.keys(callbacks)
        .sort()
        .map(key => `${key}:${String(callbacks[key])}`)
        .join("|");
}

function safeGetBlock(dim, loc) { try { return dim.getBlock(loc); } catch { return null; } }

function getBehavioursFor(block) {
    if (!block) return [];
    const results = [];
    let params;
    for (const [tag, bhListTag] of abTriggers._tagBehaviours) {
        let has = false;
        try { has = block.hasTag(tag); } catch { has = false; }
        if (!has) continue;
        params ??= extractParams(block);
        bhListTag.forEach(tagBh => results.push([tagBh, params]));
    }
    return results;
}

function extractParams(block) {
    const params = {};
    for (const t of block.getTags()) {
        if (!t.startsWith("param__")) continue;
        const parts = t.split("__");
        if (parts.length >= 3) {
            params[parts[1]] = parseParamValue(parts.slice(2).join("__"));
        }
    }
    return params;
}

function parseParamValue(value) {
    const lower = value.toLowerCase();
    if (lower === "true") return true;
    if (lower === "false") return false;
    if (!isNaN(Number(value))) return Number(value);
    if (value.includes(",")) return value.split(",").map(v => v.trim()).map(parseParamValue);
    if (value.includes("-")) return value.replace(/-/g, "/");
    return value;
}

function runBehaviours(bhs, cbName, e) {
    for (const [bh, params] of bhs) {
        try { bh?.[cbName]?.(e, params); }
        catch (err) { console.warn(`[abTriggers] ${cbName}: ${err}`); }
    }
}

function behaviourFilterPasses(bh, itemOrStack, context = {}) {
    const { item_id, item_tag, allow_hand, handOnly, item_any, customFilter } = bh || {};

    if (handOnly) return !itemOrStack;
    if (item_any) return true;

    const hasFilters = item_id || item_tag || customFilter;
    if (!hasFilters) return true;
    if (!itemOrStack) return allow_hand ?? false;

    const ids = Array.isArray(item_id) ? item_id : item_id ? [item_id] : [];
    const tags = Array.isArray(item_tag) ? item_tag : item_tag ? [item_tag] : [];
    let typeId = null;

    if (typeof itemOrStack === "string") typeId = itemOrStack;
    else if (typeof itemOrStack.typeId === "string") typeId = itemOrStack.typeId;
    else if (typeof itemOrStack.id === "string") typeId = itemOrStack.id;

    if (ids.length > 0) {
        if (!typeId || !ids.includes(typeId)) return false;
    }
    if (tags.length > 0) {
        const hasTagFn = typeof itemOrStack.hasTag === "function" ? itemOrStack.hasTag.bind(itemOrStack) : null;
        if (!hasTagFn) return false;
        for (const tag of tags) { try { if (!hasTagFn(tag)) return false; } catch { return false; } }
    }
    if (typeof customFilter === "function") {
        try {
            if (!customFilter(itemOrStack, context.block, context.face, context.player, context.faceLocation)) return false;
        } catch { return false; }
    }
    return true;
}

function registerEventSubscriptions() {
    if (globalThis.__AB_TRIGGERS_SUBSCRIBED) return;
    globalThis.__AB_TRIGGERS_SUBSCRIBED = true;

    world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
        const { block, blockFace, faceLocation, player, isFirstEvent, itemStack } = event;
        if (!isFirstEvent || !block || !player) return;

        let isBlockItem = false;
        if (itemStack) {
            try { if (BlockPermutation.resolve(itemStack.typeId)) isBlockItem = true; } catch { }
            try { if (itemStack.hasTag?.("ab:is_block")) isBlockItem = true; } catch { }
        }

        const bhList = getBehavioursFor(block).filter(([bh]) => typeof bh.onInteract === "function");
        if (bhList.length === 0) return;

        let shouldCancel = false;
        for (const [bh, params] of bhList) {
            if (!behaviourFilterPasses(bh, itemStack, { block, face: blockFace, player, faceLocation })) continue;
            if (isBlockItem && !player.isSneaking) shouldCancel = true;
            system.run(() => {
                try {
                    bh.onInteract({ player, block, face: blockFace, faceLocation, face_location: faceLocation, itemStack }, params);
                } catch (err) {
                    console.warn(`[abTriggers] Error onInteract: ${err}`);
                }
            });
        }
        if (shouldCancel) event.cancel = true;
    });

    world.afterEvents.playerBreakBlock.subscribe((ev) => {
        const { block, player, dimension, brokenBlockPermutation } = ev;
        if (!block) return;
        for (const off of NEIGHBOR_OFFSETS) {
            const neighbor = safeGetBlock(dimension, { x: block.location.x + off.dx, y: block.location.y + off.dy, z: block.location.z + off.dz });
            if (!neighbor) continue;
            const bhList = getBehavioursFor(neighbor);
            if (bhList.length === 0) continue;
            const payload = { player, brokenBlock: block, brokenBlockPermutation, changedBlock: block, block: neighbor, direction: off.dir, dimension };
            runBehaviours(bhList, "onAdjacentBreak", payload);
            runBehaviours(bhList, "onAdjacentChange", payload);
        }
    });

    world.afterEvents.playerPlaceBlock.subscribe((ev) => {
        const { block, player, dimension } = ev;
        if (!block) return;
        const own = getBehavioursFor(block);
        if (own.length > 0) runBehaviours(own, "onPlace", { player, block, dimension });
        for (const off of NEIGHBOR_OFFSETS) {
            const neighbor = safeGetBlock(dimension, { x: block.location.x + off.dx, y: block.location.y + off.dy, z: block.location.z + off.dz });
            if (!neighbor) continue;
            const bhList = getBehavioursFor(neighbor);
            if (bhList.length === 0) continue;
            const payload = { player, placedBlock: block, changedBlock: block, block: neighbor, direction: off.dir, dimension };
            runBehaviours(bhList, "onAdjacentPlace", payload);
            runBehaviours(bhList, "onAdjacentChange", payload);
        }
    });
}

registerEventSubscriptions();
