import { BlockPermutation } from "@minecraft/server";
import {
    CARDINAL_STATE, CHEST_DIRECTION_STATE, CONTAINER_OWNER_STATE, DOUBLE_POS_STATE,
    DOUBLE_STATE, MULTIBLOCK_PART_STATE, OPEN_STATE, add, centerOf, defer,
    getBlock, inventoryOf, isChest, warn
} from "./wwCommon.js";
import {
    axisOfCardinal, cardinalOf, doubleTypeOf, frontOf, frontOfCardinal, isChanging,
    isDouble, isNativeDouble, markChanging, partnerLocationOf, resolve, rightOf,
    singleTypeOf, unmarkChanging
} from "./chestLayout.js";
import { healVisual, removeEntityAt } from "./chestEntity.js";
import { dropSessionsAt, isOpen, normalizeRest } from "./chestStorage.js";

export const SNEAK_PREVENTS_PAIRING = true;

function singlePermutation(block) {
    return BlockPermutation.resolve(singleTypeOf(block.typeId), {
        [CARDINAL_STATE]: cardinalOf(block), [OPEN_STATE]: false,
        [DOUBLE_STATE]: false, [DOUBLE_POS_STATE]: "left"
    });
}

function doublePermutation(block, part) {
    const cardinal = cardinalOf(block);
    return BlockPermutation.resolve(doubleTypeOf(block.typeId), {
        [CARDINAL_STATE]: axisOfCardinal(cardinal),
        [CHEST_DIRECTION_STATE]: cardinal,
        [MULTIBLOCK_PART_STATE]: part,
        [OPEN_STATE]: false, [CONTAINER_OWNER_STATE]: 0
    });
}

function readItems(container) {
    if (!container) throw new Error("У сундука отсутствует контейнер. Включите Upcoming Creator Features.");
    return Array.from({ length: container.size }, (_, slot) => container.getItem(slot));
}

function restoreItems(container, items) {
    if (!container) throw new Error("Контейнер сундука не был создан");
    const overflow = [];
    for (let slot = 0; slot < items.length; slot++) {
        const item = items[slot];
        if (!item) continue;
        if (slot < container.size) container.setItem(slot, item);
        else overflow.push(item);
    }
    return overflow;
}

function refresh(dimension, location) {
    const block = getBlock(dimension, location);
    if (isChest(block)) healVisual(block, isOpen(block));
}

function replaceGroup(blocks, targets) {
    const dimension = blocks[0].dimension;
    const overflow = [];
    const saved = blocks.map((block, i) => ({
        location: { ...block.location }, original: block.permutation, target: targets[i],
        items: readItems(inventoryOf(block))
    }));
    for (const entry of saved) markChanging(dimension, entry.location);
    try {
        for (const entry of saved) inventoryOf(getBlock(dimension, entry.location))?.clearAll();
        for (const entry of saved) getBlock(dimension, entry.location).setType("minecraft:barrier");
        for (const entry of saved) getBlock(dimension, entry.location).setPermutation(entry.target);
        for (const entry of saved) {
            const block = getBlock(dimension, entry.location);
            if (block.typeId !== entry.target.type.id || !inventoryOf(block)) {
                throw new Error("Не удалось перестроить сундук");
            }
        }
        for (const entry of saved) {
            for (const item of restoreItems(inventoryOf(getBlock(dimension, entry.location)), entry.items)) {
                overflow.push({ item, location: entry.location });
            }
        }
    } catch (error) {
        warn(error);
        for (const entry of saved) inventoryOf(getBlock(dimension, entry.location))?.clearAll();
        for (const entry of saved) {
            try { getBlock(dimension, entry.location)?.setType("minecraft:barrier"); } catch (failure) { warn(failure); }
        }
        for (const entry of saved) {
            try { getBlock(dimension, entry.location)?.setPermutation(entry.original); } catch (failure) { warn(failure); }
        }
        for (const entry of saved) {
            try {
                for (const item of restoreItems(inventoryOf(getBlock(dimension, entry.location)), entry.items)) {
                    dimension.spawnItem(item, centerOf(entry.location));
                }
            } catch (failure) {
                warn(failure);
                inventoryOf(getBlock(dimension, entry.location))?.clearAll();
                for (const item of entry.items) if (item) dimension.spawnItem(item, centerOf(entry.location));
            }
        }
        return false;
    } finally {
        for (const entry of saved) unmarkChanging(dimension, entry.location);
    }
    for (const { item, location } of overflow) dimension.spawnItem(item, centerOf(location));
    for (const entry of saved) removeEntityAt(dimension, entry.location);
    for (const entry of saved) refresh(dimension, entry.location);
    return true;
}

function pair(left, right) {
    const targets = [doublePermutation(left, 0), doublePermutation(right, 1)];
    dropSessionsAt(left.dimension, left.location);
    dropSessionsAt(right.dimension, right.location);
    return replaceGroup([left, right], targets);
}

export function unpair(block) {
    const info = resolve(block);
    if (info.kind === "none" || info.kind === "unloaded") return false;
    const halves = info.kind === "double" ? [info.left, info.right] : [block];
    const targets = halves.map(singlePermutation);
    dropSessionsAt(block.dimension, block.location);
    if (info.kind === "double") normalizeRest(info);
    return replaceGroup(halves, targets);
}

export function tryPair(placed, player) {
    if (!isChest(placed) || isDouble(placed) || isChanging(placed.dimension, placed.location)) return false;
    if (SNEAK_PREVENTS_PAIRING && player?.isSneaking) return false;
    const right = rightOf(frontOf(placed));
    for (const sign of [1, -1]) {
        const other = getBlock(placed.dimension, add(placed.location, right, sign));
        if (!isChest(other) || other.typeId !== placed.typeId || isDouble(other)) continue;
        if (cardinalOf(other) !== cardinalOf(placed)) continue;
        return sign === 1 ? pair(placed, other) : pair(other, placed);
    }
    return false;
}

export function reconcile(block) {
    const info = resolve(block);
    if (info.kind === "broken") return unpair(block);
    if (info.kind === "double" && !isNativeDouble(block)) return pair(info.left, info.right);
    return false;
}

export function onBroken(dimension, location, permutation) {
    if (isChanging(dimension, location)) return;
    const native = permutation.getState(MULTIBLOCK_PART_STATE) !== undefined;
    const wasDouble = native || permutation.getState(DOUBLE_STATE) === true;
    const side = native ? permutation.getState(MULTIBLOCK_PART_STATE) === 0 ? "left" : "right"
        : permutation.getState(DOUBLE_POS_STATE) ?? "left";
    const cardinal = permutation.getState(native ? CHEST_DIRECTION_STATE : CARDINAL_STATE);
    const partnerAt = wasDouble ? partnerLocationOf(location, frontOfCardinal(cardinal), side) : undefined;
    dropSessionsAt(dimension, location);
    defer(() => {
        if (isChest(getBlock(dimension, location))) return;
        removeEntityAt(dimension, location);
        if (!partnerAt) return;
        removeEntityAt(dimension, partnerAt);
        const partner = getBlock(dimension, partnerAt);
        if (isChest(partner) && isDouble(partner)) reconcile(partner);
    });
}
