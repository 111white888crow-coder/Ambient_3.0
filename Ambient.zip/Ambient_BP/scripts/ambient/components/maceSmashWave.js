import { world, system, EquipmentSlot, MolangVariableMap } from "@minecraft/server";
import { BLOCK_PARTICLES } from "../data/blockParticleEffects.js";

// Mace smash attack -> circular wave of block-cube particles around the target.
// Blocks around the target (except the one(s) the target / attacker stand on)
// throw up spinning cubes of their own texture that rise and fall ballistically.

const MACE_ITEM = "minecraft:mace";
const FALL_THRESHOLD = 1.5; // vanilla smash attack: fall distance > 1.5 blocks
const WAVE_MIN_RADIUS = 0.6;
const WAVE_MAX_RADIUS = 3.6;
const WAVE_SCAN_RADIUS = 4;
const TICKS_PER_BLOCK = 2.4; // wave propagation speed (ticks per block of radius)

// playerId -> highest Y reached during the current fall
const fallPeaks = new Map();

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        try {
            if (player.isGliding) {
                fallPeaks.delete(player.id);
                continue;
            }
            const vy = player.getVelocity().y;
            if (vy < -0.01) {
                const peak = fallPeaks.get(player.id);
                if (peak === undefined || player.location.y > peak) {
                    fallPeaks.set(player.id, player.location.y);
                }
            } else {
                fallPeaks.delete(player.id);
            }
        } catch {
            fallPeaks.delete(player.id);
        }
    }
}, 1);

function forgetPlayer(playerId) {
    fallPeaks.delete(playerId);
}

world.afterEvents.playerLeave.subscribe(({ playerId }) => forgetPlayer(playerId));
world.afterEvents.entityDie.subscribe(({ deadEntity }) => {
    if (deadEntity.typeId === "minecraft:player") forgetPlayer(deadEntity.id);
});

world.afterEvents.entityHitEntity.subscribe((event) => {
    try {
        onHit(event);
    } catch (error) {
        console.warn("[Ambient] mace smash wave failed: " + error);
    }
});

function onHit(event) {
    const { damagingEntity, hitEntity } = event;
    if (!damagingEntity || damagingEntity.typeId !== "minecraft:player") return;
    if (!hitEntity) return;
    const peak = fallPeaks.get(damagingEntity.id);
    if (peak === undefined || peak - damagingEntity.location.y < FALL_THRESHOLD) return;
    const equippable = damagingEntity.getComponent("minecraft:equippable");
    const item = equippable && equippable.getEquipment(EquipmentSlot.Mainhand);
    if (!item || item.typeId !== MACE_ITEM) return;
    fallPeaks.delete(damagingEntity.id); // one wave per fall
    spawnWave(damagingEntity.dimension, hitEntity, damagingEntity);
}

function spawnWave(dimension, target, player) {
    const loc = target.location;
    const cx = Math.floor(loc.x) + 0.5;
    const cz = Math.floor(loc.z) + 0.5;
    const floorY = Math.floor(loc.y - 0.01); // layer the target stands on
    const targetColX = Math.floor(loc.x);
    const targetColZ = Math.floor(loc.z);
    let playerColX = null;
    let playerColZ = null;
    try {
        playerColX = Math.floor(player.location.x);
        playerColZ = Math.floor(player.location.z);
    } catch {
        // player reference may already be invalid
    }
    for (let dx = -WAVE_SCAN_RADIUS; dx <= WAVE_SCAN_RADIUS; dx++) {
        for (let dz = -WAVE_SCAN_RADIUS; dz <= WAVE_SCAN_RADIUS; dz++) {
            const bx = targetColX + dx;
            const bz = targetColZ + dz;
            const d = Math.hypot(bx + 0.5 - cx, bz + 0.5 - cz);
            if (d < WAVE_MIN_RADIUS || d > WAVE_MAX_RADIUS) continue;
            // skip the block the target stands on and the attacker's landing spot
            if (bx === targetColX && bz === targetColZ) continue;
            if (playerColX !== null && bx === playerColX && bz === playerColZ) continue;
            const delay = Math.max(0, Math.round((d - WAVE_MIN_RADIUS) * TICKS_PER_BLOCK));
            system.runTimeout(() => {
                try {
                    emitBlockCube(dimension, bx, floorY, bz, cx, cz, d);
                } catch {
                    // block/dimension may be unloaded by now
                }
            }, delay);
        }
    }
}

function emitBlockCube(dimension, bx, by, bz, cx, cz, d) {
    const block = dimension.getBlock({ x: bx, y: by, z: bz });
    if (!block || block.isAir || block.isLiquid) return;
    const effect = BLOCK_PARTICLES[block.typeId];
    if (!effect) return;
    const size = 0.3 + Math.random() * 0.15;
    const molang = new MolangVariableMap();
    molang.setNumber("variable.block_size", size);
    const push = 1.0 + Math.random() * 0.8;
    molang.setNumber("variable.dirx", ((bx + 0.5 - cx) / d) * push);
    molang.setNumber("variable.dirz", ((bz + 0.5 - cz) / d) * push);
    molang.setNumber("variable.lift", 3.4 + Math.random() * 2.2);
    dimension.spawnParticle(effect, { x: bx + 0.5, y: by + 1 + size / 2 + 0.02, z: bz + 0.5 }, molang);
}
