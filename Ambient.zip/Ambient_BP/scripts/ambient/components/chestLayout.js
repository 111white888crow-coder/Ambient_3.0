import {
    CARDINAL_STATE, CHEST_DIRECTION_STATE, DOUBLE_POS_STATE, DOUBLE_STATE,
    MULTIBLOCK_PART_STATE, add, cellKey, getBlock, getState, isChest
} from "./wwCommon.js";

const FRONT_BY_CARDINAL = { north: "south", south: "north", east: "west", west: "east" };
const RIGHT_BY_FRONT = {
    north: { x: -1, y: 0, z: 0 }, south: { x: 1, y: 0, z: 0 },
    east: { x: 0, y: 0, z: -1 }, west: { x: 0, y: 0, z: 1 }
};
const AXIS_BY_CARDINAL = { north: "east", south: "west", east: "south", west: "north" };
const YAW_BY_FRONT = { south: 0, west: 90, north: 180, east: 270 };

export const singleTypeOf = (typeId) => typeId.replace(/_double_chest$/, "_chest");
export const doubleTypeOf = (typeId) => singleTypeOf(typeId).replace(/_chest$/, "_double_chest");
export const isNativeDouble = (block) => getState(block, MULTIBLOCK_PART_STATE, undefined) !== undefined;
export const cardinalOf = (block) => getState(block,
    isNativeDouble(block) ? CHEST_DIRECTION_STATE : CARDINAL_STATE, "north");
export const axisOfCardinal = (cardinal) => AXIS_BY_CARDINAL[cardinal] ?? "east";
export const frontOfCardinal = (cardinal) => FRONT_BY_CARDINAL[cardinal] ?? "south";
export const frontOf = (block) => frontOfCardinal(cardinalOf(block));
export const rightOf = (front) => RIGHT_BY_FRONT[front] ?? RIGHT_BY_FRONT.south;
export const yawOfFront = (front) => YAW_BY_FRONT[front] ?? 0;
export const isDouble = (block) => isNativeDouble(block) || getState(block, DOUBLE_STATE, false) === true;
export const sideOf = (block) => isNativeDouble(block)
    ? getState(block, MULTIBLOCK_PART_STATE, 0) === 0 ? "left" : "right"
    : getState(block, DOUBLE_POS_STATE, "left");

export function partnerLocationOf(location, front, side) {
    return add(location, rightOf(front), side === "left" ? 1 : -1);
}

export const partnerLocation = (block) => partnerLocationOf(block.location, frontOf(block), sideOf(block));

function compatible(a, b) {
    return isChest(b) && b.typeId === a.typeId && isDouble(b) &&
        sideOf(a) !== sideOf(b) && cardinalOf(a) === cardinalOf(b) &&
        (!isNativeDouble(a) || getState(a, CARDINAL_STATE) === getState(b, CARDINAL_STATE));
}

export function resolve(block) {
    if (!isChest(block)) return { kind: "none" };
    if (!isDouble(block)) return { kind: "single" };
    const other = getBlock(block.dimension, partnerLocation(block));
    if (!other) return { kind: "unloaded" };
    if (!compatible(block, other)) return { kind: "broken" };
    const left = sideOf(block) === "left";
    return { kind: "double", partner: other, left: left ? block : other, right: left ? other : block };
}

export function groupKey(block, info = resolve(block)) {
    return cellKey(block.dimension, info.kind === "double" ? info.left.location : block.location);
}

const changing = new Set();
export const isChanging = (dimension, location) => changing.has(cellKey(dimension, location));
export const markChanging = (dimension, location) => changing.add(cellKey(dimension, location));
export const unmarkChanging = (dimension, location) => changing.delete(cellKey(dimension, location));
