export function equipShelfItem(entity, item, mainhand) {
    const equipment = entity.getComponent('minecraft:equippable');
    if (equipment && typeof equipment.setEquipment === 'function') {
        if (!equipment.setEquipment(mainhand, item)) throw new Error('Cannot equip shelf item');
        return;
    }

    if (!/^[a-z0-9_.-]+:[a-z0-9_./-]+$/.test(item.typeId)) throw new Error('Invalid shelf item identifier');
    const result = entity.runCommand(`replaceitem entity @s slot.weapon.mainhand 0 ${item.typeId} 1`);
    if (!result || result.successCount < 1) throw new Error('Cannot equip shelf item with replaceitem');

}
