export const DEFAULT_SLOTS = { 0: [0.25, 0.3125, 0.78125], 1: [0.75, 0.3125, 0.78125], 2: [0.25, 0.6875, 0.78125], 3: [0.75, 0.6875, 0.78125] };
export const YAW = { north: 0, east: 90, south: 180, west: 270 };
export function rotatePoint([x, y, z], facing) {

    if (facing?.startsWith('face:')) {
        switch (facing.slice(5)) {
            case 'down': return [x, 1-y, 1-z];
            case 'north': return [x, z, 1-y];
            case 'south': return [x, 1-z, y];
            case 'east': return [1-y, x, z];
            case 'west': return [y, 1-x, z];
            default: return [x,y,z];
        }
    }
    switch (facing) {
        case 'east': return [1 - z, y, x];
        case 'south': return [1 - x, y, 1 - z];
        case 'west': return [z, y, 1 - x];
        default: return [x, y, z];
    }
}
export function slotsFrom(params = {}) {
    const mode = params.coordinate_space ?? 'block';
    if (!['block','model'].includes(mode)) throw new Error('coordinate_space must be block or model');
    const entries = Object.entries(params.item_slot ?? DEFAULT_SLOTS);
    if (!entries.length || entries.some(([id, p]) => !/^\d+$/.test(id) || !Array.isArray(p) || p.length !== 3 || p.some(n => !Number.isFinite(n)) || (mode === 'block' && p.some(n=>n<0 || n>1)))) {
        throw new Error('item_slot must map numeric IDs to finite [x,y,z]; block coordinates must be in 0..1');
    }
    return entries.sort((a,b)=>Number(a[0])-Number(b[0])).map(([id,p])=>[id,mode==='model' ? [0.5-p[0]/16,p[1]/16,0.5+p[2]/16] : [...p]]);
}

export function pickSlot(slots, hit, face, facing) {
    const axes = /up|down/i.test(face) ? [0, 2] : /east|west/i.test(face) ? [1, 2] : [0, 1];
    const point = [hit.x, hit.y, hit.z];
    let best, distance = Infinity;
    for (const [id, local] of slots) {
        const p = rotatePoint(local, facing);
        const d = axes.reduce((sum, axis) => sum + (point[axis] - p[axis]) ** 2, 0);
        if (d < distance) { best = id; distance = d; }
    }
    return best;
}
export function slotWorldPosition(local, location, facing) {
    const [x,y,z] = rotatePoint(local, facing);
    return { x:location.x+x, y:location.y+y, z:location.z+z };
}

export function pickSlotFromRay(slots, eye, direction, location, facing) {
    const values = [eye.x,eye.y,eye.z,direction.x,direction.y,direction.z,location.x,location.y,location.z];
    if (!values.every(Number.isFinite)) throw new Error('Invalid shelf selection ray');
    const length = Math.hypot(direction.x,direction.y,direction.z);
    if (!length) throw new Error('Empty shelf selection ray');
    const d = { x:direction.x/length, y:direction.y/length, z:direction.z/length };
    let best, bestError=Infinity, bestDistance=Infinity;
    for (const [id, local] of slots) {
        const p = slotWorldPosition(local, location, facing);
        const v = { x:p.x-eye.x, y:p.y-eye.y, z:p.z-eye.z };
        const distance = Math.hypot(v.x,v.y,v.z);
        const forward = v.x*d.x + v.y*d.y + v.z*d.z;
        if (forward <= 0 || distance === 0) continue;
        const error = Math.hypot(v.y*d.z-v.z*d.y, v.z*d.x-v.x*d.z, v.x*d.y-v.y*d.x) / distance;
        if (error < bestError-1e-12 || (Math.abs(error-bestError)<=1e-12 && distance<bestDistance-1e-12)) {
            best=id; bestError=error; bestDistance=distance;
        }
    }
    return best;
}
export function shapeFor(leftLength, rightLength) {
    if (!leftLength && !rightLength) return 'single';
    if (!leftLength) return rightLength === 1 ? 'double_left' : 'left';
    if (!rightLength) return leftLength === 1 ? 'double_right' : 'right';
    return 'middle';
}

export function facingForBlock(block) {
    const p=block.permutation;
    const face=p.getState('minecraft:block_face');
    return face ? `face:${face}` : p.getState('ab:facing') ?? p.getState('minecraft:cardinal_direction') ?? 'north';
}
export function attachmentRotation(facing) {
    return ({'face:up':[0,0,0], 'face:down':[180,0,0], 'face:north':[-90,0,0], 'face:south':[90,0,0], 'face:east':[0,0,-90], 'face:west':[0,0,90]})[facing] ?? [0,0,0];
}

export function scaleFrom(params = {}, kind = 'item') {
    const key = kind === 'block' ? 'block_scale' : 'item_scale';
    const scale = params[key] ?? 0.5;
    if (!Number.isFinite(scale) || scale < 0 || scale > 3) throw new Error(`${key} must be a number in 0..3`);
    return scale;
}

export function displayFrom(params = {}, isBlock = false, typeId = '') {
    const kind = isBlock ? 'block' : 'item';
    const key = isBlock ? 'Block_rotation' : 'Item_rotation';
    const rotation = isBanner(typeId) ? bannerRotation(params) : params[key] ?? [0, 0, 0];
    if (!Array.isArray(rotation) || rotation.length !== 3 || rotation.some(n => !Number.isFinite(n))) throw new Error(`${key} must be [x,y,z] in degrees`);
    const scale = isBanner(typeId) && params.banner_scale !== undefined ? scaleFrom({ item_scale: params.banner_scale }, 'item') : scaleFrom(params, kind);
    return { scale, rotation: rotation.map(n => ((n % 360) + 360) % 360) };
}

export function visualKind(typeId, isBlock = false) {
    if (isBanner(typeId)) return 'item';
    if (isBlock) return 'block';
    if (typeId === 'minecraft:stick' || /(?:sword|pickaxe|axe|shovel|hoe|bow|trident|fishing_rod|mace|wrench|hammer|spear)$/.test(typeId)) return 'hand_equipped';
    return 'item';
}

export function displayLocalPosition(params, local, isBlock = false) {
    const key = isBlock ? 'Block_offset' : 'Item_offset';
    const offset = params[key] ?? [0, 0, 0];
    if (!Array.isArray(offset) || offset.length !== 3 || offset.some(n => !Number.isFinite(n))) throw new Error(`${key} must be finite model pixels [x,y,z]`);
    return [local[0] - offset[0] / 16, local[1] + offset[1] / 16, local[2] + offset[2] / 16];
}

export function isBanner(typeId) {
    return /^minecraft:(?:(?:white|orange|magenta|light_blue|yellow|lime|pink|gray|light_gray|cyan|purple|blue|brown|green|red|black|standing|wall)_)?banner$/.test(typeId);
}

export function jarPowered(block, power = undefined) {
    if (!/^ab:(?:[a-z_]+_)?item_jar$/.test(block.typeId)) return false;
    return (power ?? block.getRedstonePower?.() ?? 0) > 0;
}







export const BANNER_YAW = 180;
let bannerYawRuntime;
export function setBannerYaw(value) { bannerYawRuntime = value; }
export function bannerYaw(params = {}) {
    const v = params.banner_yaw ?? bannerYawRuntime ?? BANNER_YAW;
    return Number.isFinite(v) ? ((v % 360) + 360) % 360 : BANNER_YAW;
}
export function bannerRotation(params = {}) {
    const r = params.banner_rotation ?? [0, 0, 0];
    if (!Array.isArray(r) || r.length !== 3 || r.some(n => !Number.isFinite(n))) throw new Error('banner_rotation must be [x,y,z] in degrees');
    return [r[0], r[1] + bannerYaw(params), r[2]];
}

export function bannerMount() { return [0, 0, 0]; }

const INTO_SURFACE = { 'face:north': 0, 'face:south': 180, 'face:east': 90, 'face:west': 270 };
export function bannerEntityYaw(facing, playerYaw) {
    if (facing in INTO_SURFACE) return INTO_SURFACE[facing];
    if (facing in YAW) return YAW[facing];

    const y = Number.isFinite(playerYaw) ? playerYaw : 0;
    return (((Math.round(y / 90) * 90) % 360) + 360) % 360;
}
