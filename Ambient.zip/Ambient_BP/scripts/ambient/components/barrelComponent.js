import { world } from "@minecraft/server";
import {
    DRESSER_TAG, OPEN_STATE, MAX_VIEW_DISTANCE, cellKey, centerOf, distanceSq, getBlock, getState,
    isBarrelLike, isPlayer, playSoundAt, setStates
} from "./wwCommon.js";

const SOUND_OPEN = "block.barrel.open";
const SOUND_CLOSE = "block.barrel.close";

const viewed = new Map();

function setOpen(block, open) {
    return setStates(block, { [OPEN_STATE]: open });
}

function release(key, entry, withSound) {
    viewed.delete(key);
    const block = getBlock(entry.dimension, entry.location);
    if (!isBarrelLike(block)) return;
    setOpen(block, false);
    if (withSound) playSoundAt(entry.dimension, centerOf(entry.location), SOUND_CLOSE);
}

export function barrelOpened(event) {
    const block = event.block;
    const player = event.openSource?.entity ?? event.player;
    if (!isBarrelLike(block) || !isPlayer(player)) return;

    const key = cellKey(block.dimension, block.location);
    let entry = viewed.get(key);
    const first = entry === undefined;
    if (first) {
        entry = { dimension: block.dimension, location: { ...block.location }, players: new Set() };
        viewed.set(key, entry);
    }
    entry.players.add(player.id);
    if (!first) return;

    setOpen(block, true);
    playSoundAt(block.dimension, centerOf(block.location), SOUND_OPEN);
}

export function barrelClosed(event) {
    const block = event.block;
    if (!isBarrelLike(block)) return;

    const key = cellKey(block.dimension, block.location);
    const entry = viewed.get(key);
    if (!entry) return;

    const player = event.closeSource?.entity ?? event.player;
    if (player) entry.players.delete(player.id);
    if (entry.players.size === 0) release(key, entry, true);
}

export function barrelForgetPlayer(playerId) {
    for (const [key, entry] of [...viewed]) {
        entry.players.delete(playerId);
        if (entry.players.size === 0) release(key, entry, true);
    }
}

export function barrelAudit() {
    const players = new Map(world.getAllPlayers().map((player) => [player.id, player]));
    for (const [key, entry] of [...viewed]) {
        if (!getBlock(entry.dimension, entry.location)) continue;
        for (const id of [...entry.players]) {
            const player = players.get(id);
            if (!player || player.dimension.id !== entry.dimension.id ||
                distanceSq(player.location, entry.location) > MAX_VIEW_DISTANCE ** 2) entry.players.delete(id);
        }
        if (entry.players.size === 0) release(key, entry, true);
    }
}

export const barrelComponent = {

    onTick({ block }) {
        if (!getState(block, OPEN_STATE, false)) return;
        if (viewed.has(cellKey(block.dimension, block.location))) return;
        setOpen(block, false);
    },
    onBreak({ block, dimension }) {
        viewed.delete(cellKey(dimension ?? block.dimension, block.location));
    },
    register(registry) {
        registry.registerCustomComponent(DRESSER_TAG, this);
    }
};
