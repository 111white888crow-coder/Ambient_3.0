import { system } from "@minecraft/server";
import { add, cellKey, getBlock, getState, inventoryOf, isChest, warn } from "./wwCommon.js";
import { isChanging, resolve } from "./chestLayout.js";
import { isOpen } from "./chestStorage.js";

const HALF = 27;
const COOLDOWN = 8;
const PER_TICK = 32;
const UP = { x: 0, y: 1, z: 0 };
const NEIGHBOURS = [
    UP, { x: 0, y: -1, z: 0 },
    { x: 1, y: 0, z: 0 }, { x: -1, y: 0, z: 0 },
    { x: 0, y: 0, z: 1 }, { x: 0, y: 0, z: -1 }
];
const FACING = {
    0: { x: 0, y: -1, z: 0 }, 1: { x: 0, y: 1, z: 0 },
    2: { x: 0, y: 0, z: -1 }, 3: { x: 0, y: 0, z: 1 },
    4: { x: -1, y: 0, z: 0 }, 5: { x: 1, y: 0, z: 0 }
};

const hoppers = new Map();

const isHopper = (block) => block?.typeId === "minecraft:hopper";

function outputOf(hopper) {
    const step = FACING[getState(hopper, "facing_direction", -1)];
    return step ? getBlock(hopper.dimension, add(hopper.location, step)) : undefined;
}

function locked(hopper) {
    if (getState(hopper, "toggle_bit", false) === true) return true;
    try { return (hopper.getRedstonePower() ?? 0) > 0; } catch { return false; }
}

function chestContainers(block) {
    if (!isChest(block) || isChanging(block.dimension, block.location) || isOpen(block)) return [];
    const info = resolve(block);
    if (info.kind === "single") return [inventoryOf(block)].filter(Boolean);
    if (info.kind === "double") return [inventoryOf(info.left), inventoryOf(info.right)].filter(Boolean);
    return [];
}

function moveOne(source, sourceLimit, targets) {
    const limit = Math.min(source.size, sourceLimit);
    for (let from = 0; from < limit; from++) {
        const item = source.getItem(from);
        if (!item) continue;
        for (const { container, limit: targetLimit } of targets) {
            if (container === source) continue;
            const size = Math.min(container.size, targetLimit);
            let empty = -1;
            for (let to = 0; to < size; to++) {
                const previous = container.getItem(to);
                if (!previous) { if (empty < 0) empty = to; continue; }
                if (previous.amount >= previous.maxAmount || !previous.isStackableWith(item)) continue;
                const next = previous.clone();
                next.amount++;
                return commit(source, from, item, container, to, next, previous);
            }
            if (empty >= 0) {
                const next = item.clone();
                next.amount = 1;
                return commit(source, from, item, container, empty, next, undefined);
            }
        }
    }
    return false;
}

function commit(source, from, item, target, to, next, previous) {
    try { target.setItem(to, next); } catch { return false; }
    try {
        if (item.amount > 1) {
            const rest = item.clone();
            rest.amount--;
            source.setItem(from, rest);
        } else source.setItem(from, undefined);
    } catch (error) {
        try { target.setItem(to, previous); } catch { }
        warn(error);
        return false;
    }
    return true;
}

function relevant(hopper) {
    return isChest(getBlock(hopper.dimension, add(hopper.location, UP))) || isChest(outputOf(hopper));
}

export function rememberHopper(hopper) {
    if (!isHopper(hopper)) return;
    const key = cellKey(hopper.dimension, hopper.location);
    if (hoppers.has(key)) return;
    const location = { ...hopper.location };
    const phase = Math.abs(location.x * 3 + location.y * 5 + location.z * 7) % COOLDOWN;
    hoppers.set(key, { dimension: hopper.dimension, location, next: system.currentTick + phase });
}

export function discoverHoppers(chest) {
    for (const step of NEIGHBOURS) {
        const neighbour = getBlock(chest.dimension, add(chest.location, step));
        if (isHopper(neighbour) && relevant(neighbour)) rememberHopper(neighbour);
    }
}

export function discoverChestsFor(hopper) {
    if (isHopper(hopper) && relevant(hopper)) rememberHopper(hopper);
}

function process(entry) {
    const now = system.currentTick;
    if (entry.next > now) return true;
    const hopper = getBlock(entry.dimension, entry.location);
    if (!isHopper(hopper)) return false;
    const above = getBlock(entry.dimension, add(entry.location, UP));
    const target = outputOf(hopper);
    if (!isChest(above) && !isChest(target)) return false;

    entry.next = now + COOLDOWN;
    if (locked(hopper)) return true;
    const inventory = inventoryOf(hopper);
    if (!inventory) return false;

    if (isChest(target)) {
        const containers = chestContainers(target);
        if (containers.length) moveOne(inventory, inventory.size, containers.map((container) => ({ container, limit: HALF })));
    }
    if (isChest(above)) {
        for (const container of chestContainers(above)) {
            if (moveOne(container, HALF, [{ container: inventory, limit: inventory.size }])) break;
        }
    }
    return true;
}

export function tickHoppers() {
    const count = Math.min(PER_TICK, hoppers.size);
    for (let i = 0; i < count; i++) {
        const [key, entry] = hoppers.entries().next().value;
        hoppers.delete(key);
        try {
            if (process(entry)) hoppers.set(key, entry);
        } catch (error) {
            warn(error);
            entry.next = system.currentTick + COOLDOWN;
            hoppers.set(key, entry);
        }
    }
}
