import { system, world } from "@minecraft/server";
import { defer, getBlock, isChest } from "./wwCommon.js";
import { isChanging, resolve } from "./chestLayout.js";
import { healVisual } from "./chestEntity.js";
import { isLockedFor, isOpen, normalizeRest, reserveChestOpen } from "./chestStorage.js";
import { onBroken, reconcile, tryPair } from "./chestPairing.js";
import { discoverHoppers } from "./chestHoppers.js";

export const chestComponent = {

    onPlace({ block }) {
        try { discoverHoppers(block); } catch { }
    },

    onTick({ block }) {
        if (isChanging(block.dimension, block.location)) return;
        if (reconcile(block)) return;

        const info = resolve(block);
        if (info.kind === "double" && info.left.location.x === block.location.x &&
            info.left.location.y === block.location.y && info.left.location.z === block.location.z) {
            normalizeRest(info);
        }
        healVisual(block, isOpen(block));
        discoverHoppers(block);
    },

    onBreak(event) {
        const dimension = event.dimension ?? event.block.dimension;
        onBroken(dimension, { ...event.block.location }, event.brokenBlockPermutation);
    },

    register(registry) {
        registry.registerCustomComponent("create:chest", this);
    }
};

export function onPlayerPlaceChest(event) {
    const { block, player } = event;
    if (!isChest(block)) return;
    try { tryPair(block, player); } catch (error) { console.warn(`[Woodworks] pair: ${error}`); }
}

export function beforeChestInteract(event) {
    const { block, player } = event;
    if (!isChest(block)) return;
    if (player.isSneaking && event.itemStack) return;
    if (resolve(block).kind === "unloaded") { event.cancel = true; return; }
    if (!isLockedFor(block)) { reserveChestOpen(block); return; }

    event.cancel = true;
    system.run(() => {
        try { player.onScreenDisplay.setActionBar("§cСундук уже открыт с другой стороны"); } catch { }
    });
}
