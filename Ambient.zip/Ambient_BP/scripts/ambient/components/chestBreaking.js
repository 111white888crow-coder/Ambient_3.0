import { system } from "@minecraft/server";
import { cellKey, getBlock, isChest, warn } from "./wwCommon.js";
import { cardinalOf, groupKey, isChanging, isDouble, resolve, singleTypeOf } from "./chestLayout.js";
import { unpair } from "./chestPairing.js";

const pending = new Map();

function modeOf(player) {
    try { return String(player.getGameMode()).toLowerCase(); } catch { return "survival"; }
}

function rayDistance(origin, direction, block, other) {
    const at = block.location;
    const min = { x: at.x + 1 / 16, y: at.y, z: at.z + 1 / 16 };
    const max = { x: at.x + 15 / 16, y: at.y + 14 / 16, z: at.z + 15 / 16 };
    for (const axis of ["x", "z"]) {
        if (other.location[axis] > at[axis]) max[axis] = at[axis] + 1;
        if (other.location[axis] < at[axis]) min[axis] = at[axis];
    }
    let near = 0;
    let far = 8;
    for (const axis of ["x", "y", "z"]) {
        const step = direction[axis];
        if (Math.abs(step) < 0.000001) {
            if (origin[axis] < min[axis] || origin[axis] > max[axis]) return Infinity;
            continue;
        }
        const a = (min[axis] - origin[axis]) / step;
        const b = (max[axis] - origin[axis]) / step;
        near = Math.max(near, Math.min(a, b));
        far = Math.min(far, Math.max(a, b));
        if (far < near) return Infinity;
    }
    return near;
}

function selectedHalf(block, player) {
    const info = resolve(block);
    if (info.kind === "double") {
        try {
            const origin = player.getHeadLocation();
            const direction = player.getViewDirection();
            const left = rayDistance(origin, direction, info.left, info.right);
            const right = rayDistance(origin, direction, info.right, info.left);
            if (left < right) return info.left;
            if (right < left) return info.right;
        } catch { }
    }
    try {
        const hit = player.getBlockFromViewDirection({ maxDistance: 8 })?.block;
        if (isChest(hit) && groupKey(hit) === groupKey(block)) return hit;
    } catch { }
    return block;
}

function damageTool(request) {
    const { player, slot, item } = request;
    if (!player || !item || request.creative) return;
    const cost = /_sword$/.test(item.typeId) ? 2 : /_(axe|pickaxe|shovel|hoe)$/.test(item.typeId) ? 1 : 0;
    if (!cost) return;
    try {
        const inventory = player.getComponent("minecraft:inventory")?.container;
        const current = inventory?.getItem(slot);
        if (!current || current.typeId !== item.typeId) return;
        const durability = current.getComponent("minecraft:durability");
        const previous = item.getComponent("minecraft:durability");
        if (!durability || durability.unbreakable || !previous || durability.damage !== previous.damage) return;
        const unbreaking = current.getComponent("minecraft:enchantable")?.getEnchantment("unbreaking")?.level ?? 0;
        let damage = durability.damage;
        for (let i = 0; i < cost; i++) {
            if (Math.random() * 100 < durability.getDamageChance(unbreaking)) damage++;
        }
        if (damage >= durability.maxDurability) {
            inventory.setItem(slot, undefined);
            try { player.playSound("random.break"); } catch { }
        } else {
            durability.damage = damage;
            inventory.setItem(slot, current);
        }
    } catch (error) { warn(error); }
}

function destroySingle(dimension, location, request) {
    const block = getBlock(dimension, location);
    if (!isChest(block) || isDouble(block)) return;
    if (request.creative) block.setType("minecraft:air");
    else dimension.runCommand(`setblock ${location.x} ${location.y} ${location.z} air destroy`);
    damageTool(request);
}

function flush(key, job) {
    if (pending.get(key) !== job) return;
    pending.delete(key);
    try {
        const block = getBlock(job.dimension, job.anchor);
        if (!isChest(block) || block.typeId !== job.typeId || cardinalOf(block) !== job.cardinal) return;
        if (!unpair(block)) return;
        for (const request of job.requests.values()) {
            const target = getBlock(job.dimension, request.location);
            if (target?.typeId !== job.singleId || cardinalOf(target) !== job.cardinal) continue;
            destroySingle(job.dimension, request.location, request);
        }
    } catch (error) { warn(error); }
}

function enqueue(block, request) {
    const info = resolve(block);
    if (info.kind === "unloaded" || info.kind === "none") return;
    const key = groupKey(block, info);
    let job = pending.get(key);
    if (!job) {
        job = {
            dimension: block.dimension,
            anchor: { ...(info.kind === "double" ? info.left : block).location },
            typeId: block.typeId, singleId: singleTypeOf(block.typeId),
            cardinal: cardinalOf(block), requests: new Map()
        };
        pending.set(key, job);
        system.run(() => flush(key, job));
    }
    const targetKey = cellKey(block.dimension, request.location);
    if (!job.requests.has(targetKey)) job.requests.set(targetKey, request);
}

export function beforePlayerBreakChest(event) {
    if (event.cancel || !isChest(event.block) || !isDouble(event.block)) return;
    if (isChanging(event.block.dimension, event.block.location)) return;
    event.cancel = true;
    const target = selectedHalf(event.block, event.player);
    enqueue(event.block, {
        location: { ...target.location }, player: event.player,
        slot: event.player.selectedSlotIndex, item: event.itemStack?.clone(),
        creative: modeOf(event.player) === "creative"
    });
}

export function beforeChestExplosion(event) {
    if (event.cancel) return;
    const impacted = event.getImpactedBlocks();
    const kept = [];
    for (const block of impacted) {
        if (!isChest(block) || !isDouble(block) || isChanging(block.dimension, block.location)) {
            kept.push(block);
            continue;
        }
        enqueue(block, { location: { ...block.location }, creative: false });
    }
    if (kept.length !== impacted.length) event.setImpactedBlocks(kept);
}
