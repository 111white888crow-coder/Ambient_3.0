import { system } from "@minecraft/server";

export const BARREL_TAG = "create:barrel";
export const DRESSER_TAG = "create:dresser";
export const CHEST_TAG = "create:chest";
export const OPEN_STATE = "create:open";
export const DOUBLE_STATE = "create:double";
export const DOUBLE_POS_STATE = "create:double_pos";
export const CARDINAL_STATE = "minecraft:cardinal_direction";
export const CHEST_DIRECTION_STATE = "ww:chest_direction";
export const MULTIBLOCK_PART_STATE = "minecraft:multi_block_part";
export const CONTAINER_OWNER_STATE = "ww:container_owner";

export const MAX_VIEW_DISTANCE = 12;

export function cellKey(dimension, pos) {
    return `${dimension.id}|${pos.x},${pos.y},${pos.z}`;
}

export function add(pos, step, k = 1) {
    return { x: pos.x + step.x * k, y: pos.y + step.y * k, z: pos.z + step.z * k };
}

export function getBlock(dimension, pos) {
    try { return dimension.getBlock(pos); } catch { return undefined; }
}

export function hasTag(block, tag) {
    try { return block?.hasTag(tag) === true; } catch { return false; }
}

export const isBarrelLike = (block) => hasTag(block, BARREL_TAG) || hasTag(block, DRESSER_TAG);
export const isChest = (block) => hasTag(block, CHEST_TAG);

export function getState(block, name, fallback) {
    try { return block.permutation.getState(name) ?? fallback; } catch { return fallback; }
}

export function setStates(block, states) {
    try {
        let permutation = block.permutation;
        let changed = false;
        for (const [name, value] of Object.entries(states)) {
            const previous = permutation.getState(name);
            if (previous === undefined || previous === value) continue;
            permutation = permutation.withState(name, value);
            changed = true;
        }
        if (changed) block.setPermutation(permutation);
        return changed;
    } catch (error) {
        warn(error);
        return false;
    }
}

export function inventoryOf(block) {
    try { return block?.getComponent("minecraft:inventory")?.container; } catch { return undefined; }
}

export function isPlayer(entity) {
    try { return entity?.typeId === "minecraft:player"; } catch { return false; }
}

export function centerOf(pos) {
    return { x: pos.x + 0.5, y: pos.y + 0.5, z: pos.z + 0.5 };
}

export function playSoundAt(dimension, location, soundId, volume = 0.5) {
    try {
        dimension.playSound(soundId, location, { volume, pitch: 0.9 + Math.random() * 0.1 });
    } catch (error) { warn(error); }
}

export function distanceSq(a, b) {
    return (a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2;
}

export function warn(error) {
    console.warn(`[Woodworks] ${error}`);
}

export function defer(fn) {
    system.run(() => {
        try { fn(); } catch (error) { warn(error); }
    });
}
