import { system, world } from "@minecraft/server";
import { OPEN_STATE, cellKey, getBlock, getState, isChest, setStates, warn } from "./wwCommon.js";
import { frontOf, isDouble, resolve, sideOf, yawOfFront } from "./chestLayout.js";

export const ENTITY_ID = "ww:chest_entity";
export const ENTITY_FAMILY = "ww_block_entity";
const TAG_PREFIX = "wwc:";

const SHOW_DELAY = 3;

const HIDE_DELAY = 10;

export const WOODS = ["birtch"];

export function variantOf(typeId) {
    const match = /^[^:]+:(.+?)(?:_double)?_chest$/.exec(typeId);
    const index = match ? WOODS.indexOf(match[1]) : -1;
    return index < 0 ? 0 : index;
}

const tagFor = (location) => `${TAG_PREFIX}${location.x},${location.y},${location.z}`;

function parseTag(entity) {
    for (const tag of entity.getTags()) {
        if (!tag.startsWith(TAG_PREFIX)) continue;
        const [x, y, z] = tag.slice(TAG_PREFIX.length).split(",").map(Number);
        if ([x, y, z].every(Number.isFinite)) return { x, y, z };
    }
    return undefined;
}

function findAt(dimension, location, near) {
    try {
        return [...dimension.getEntities({
            type: ENTITY_ID, tags: [tagFor(location)], location: near, maxDistance: 3
        })];
    } catch { return []; }
}

const nearOf = (location) => ({ x: location.x + 0.5, y: location.y, z: location.z + 0.5 });

function entityAt(dimension, location) {
    const [first] = findAt(dimension, location, nearOf(location));
    return first;
}

export function removeEntityAt(dimension, location) {
    for (const entity of findAt(dimension, location, nearOf(location))) {
        try { entity.remove(); } catch { }
    }
}

function setProp(entity, name, value) {
    try {
        if (entity.getProperty(name) !== value) entity.setProperty(name, value);
    } catch (error) { warn(`${name}: ${error}`); }
}

function angleDiff(a, b) {
    return Math.abs(((a - b + 540) % 360) - 180);
}

const transitions = new Map();
let transitionCounter = 0;

export const isTransitioning = (dimension, location) => transitions.has(cellKey(dimension, location));

function ensureEntity(block) {
    const info = resolve(block);
    if (info.kind === "none" || info.kind === "unloaded") return undefined;
    if (info.kind === "double" && sideOf(block) === "right") return undefined;

    const dimension = block.dimension;
    const origin = block.location;
    const double = info.kind === "double";
    const position = {
        x: (double ? (origin.x + info.partner.location.x) / 2 : origin.x) + 0.5,
        y: origin.y,
        z: (double ? (origin.z + info.partner.location.z) / 2 : origin.z) + 0.5
    };
    const yaw = yawOfFront(frontOf(block));

    const found = findAt(dimension, origin, position);
    let entity = found.shift();
    for (const extra of found) { try { extra.remove(); } catch { } }

    let fresh = false;
    if (!entity) {
        try {
            try {
                entity = dimension.spawnEntity(ENTITY_ID, position, { initialRotation: yaw });
            } catch {
                entity = dimension.spawnEntity(ENTITY_ID, position);
            }
            entity.addTag(tagFor(origin));
            fresh = true;
        } catch (error) {
            warn(`spawn ${ENTITY_ID}: ${error}`);
            return undefined;
        }
        setProp(entity, "ww:ready", false);
        setProp(entity, "ww:open", false);
    }

    const at = entity.location;
    const moved = Math.abs(at.x - position.x) > 0.01 || Math.abs(at.y - position.y) > 0.01 || Math.abs(at.z - position.z) > 0.01;
    const turned = angleDiff(entity.getRotation().y, yaw) > 1;
    if (fresh || moved || turned) {
        try { entity.teleport(position, { rotation: { x: 0, y: yaw } }); } catch { }
        if (turned) { try { entity.setRotation({ x: 0, y: yaw }); } catch { } }
    }

    setProp(entity, "ww:variant", variantOf(block.typeId));
    setProp(entity, "ww:double", double ? 1 : 0);
    return { entity, fresh };
}

function halvesAt(dimension, left, right) {
    return [left, right].filter(Boolean).map((location) => getBlock(dimension, location)).filter(Boolean);
}

export function setOpenVisual(dimension, left, right, open) {
    const key = cellKey(dimension, left);
    const token = ++transitionCounter;
    transitions.set(key, token);
    const live = () => transitions.get(key) === token;
    const done = () => { if (live()) transitions.delete(key); };
    const setHalves = (value) => {
        for (const half of halvesAt(dimension, left, right)) setStates(half, { [OPEN_STATE]: value });
    };

    if (open) {
        const owner = getBlock(dimension, left);
        const result = owner ? ensureEntity(owner) : undefined;
        if (!result) { done(); return; }

        const reveal = () => {
            const entity = entityAt(dimension, left);
            if (!entity) { done(); return; }
            setProp(entity, "ww:ready", true);
            setProp(entity, "ww:open", true);
            system.runTimeout(() => {
                if (!live()) return;
                setHalves(true);
                done();
            }, 1);
        };

        if (result.fresh) {
            system.runTimeout(() => { if (live()) reveal(); }, SHOW_DELAY);
        } else {
            reveal();
        }
        return;
    }

    const entity = entityAt(dimension, left);
    if (!entity) {
        setHalves(false);
        done();
        return;
    }
    setProp(entity, "ww:open", false);
    system.runTimeout(() => {
        if (!live()) return;
        setHalves(false);
        system.runTimeout(() => {
            if (!live()) return;
            removeEntityAt(dimension, left);
            done();
        }, 1);
    }, HIDE_DELAY);
}

export function healVisual(block, open) {
    const info = resolve(block);
    if (info.kind === "none" || info.kind === "unloaded") return;
    const owner = !(info.kind === "double" && sideOf(block) === "right");
    const ownerLocation = info.kind === "double" ? info.left.location : block.location;
    if (isTransitioning(block.dimension, ownerLocation)) return;

    if (!open) {
        if (getState(block, OPEN_STATE, false)) setStates(block, { [OPEN_STATE]: false });
        if (owner) removeEntityAt(block.dimension, block.location);
        return;
    }
    if (!owner) return;

    const result = ensureEntity(block);
    if (!result) return;
    setProp(result.entity, "ww:ready", true);
    setProp(result.entity, "ww:open", true);
    const halves = info.kind === "double" ? [info.left, info.right] : [block];
    for (const half of halves) setStates(half, { [OPEN_STATE]: true });
}

export function sweepStrayEntities(isActive) {
    const dimensions = new Map();
    for (const player of world.getAllPlayers()) {
        try { dimensions.set(player.dimension.id, player.dimension); } catch { }
    }
    for (const dimension of dimensions.values()) {
        let entities;
        try { entities = dimension.getEntities({ families: [ENTITY_FAMILY], type: ENTITY_ID }); } catch { continue; }
        for (const entity of entities) {
            try {
                const owner = parseTag(entity);
                if (!owner) { entity.remove(); continue; }
                const block = getBlock(dimension, owner);
                if (!block) continue;
                if (!isChest(block) || (isDouble(block) && sideOf(block) === "right")) { entity.remove(); continue; }
                if (isTransitioning(dimension, owner)) continue;
                if (!isActive(block)) entity.remove();
            } catch { }
        }
    }
}
