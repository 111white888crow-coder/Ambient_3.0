import { system } from "@minecraft/server";

const COMPONENT_ID = "create:wall_shelf";
const CONNECT_TAG = "create:is_wall_shelf_connected";
const SMALL_TAG = "create:is_small_wall_shelf";
const FACING_STATE = "minecraft:cardinal_direction";
const LEFT_STATE = "create:connected_left";
const RIGHT_STATE = "create:connected_right";

const SIDE_STEPS = {
    north: { left: { x: -1, y: 0, z: 0 }, right: { x: 1, y: 0, z: 0 } },
    east: { left: { x: 0, y: 0, z: -1 }, right: { x: 0, y: 0, z: 1 } },
    south: { left: { x: 1, y: 0, z: 0 }, right: { x: -1, y: 0, z: 0 } },
    west: { left: { x: 0, y: 0, z: 1 }, right: { x: 0, y: 0, z: -1 } },
};

const HORIZONTAL = [
    { x: 1, y: 0, z: 0 },
    { x: -1, y: 0, z: 0 },
    { x: 0, y: 0, z: 1 },
    { x: 0, y: 0, z: -1 },
];

function safeOffset(block, step) {
    try { return block.offset(step); } catch { return undefined; }
}

function isInLine(neighbour, facing, small) {
    if (!neighbour) return false;
    try {
        if (!neighbour.isValid || !neighbour.hasTag(CONNECT_TAG)) return false;
        if (neighbour.hasTag(SMALL_TAG) !== small) return false;
        return neighbour.permutation.getState(FACING_STATE) === facing;
    } catch { return false; }
}

function connectionsFor(block, facing) {
    const steps = SIDE_STEPS[facing];
    if (!steps) return null;
    let small = false;
    try { small = block.hasTag(SMALL_TAG); } catch { }
    return {
        left: isInLine(safeOffset(block, steps.left), facing, small),
        right: isInLine(safeOffset(block, steps.right), facing, small),
    };
}

function refresh(block) {
    try {
        if (!block || !block.isValid) return;
        const permutation = block.permutation;
        if (permutation.getState(LEFT_STATE) === undefined) return;

        const found = connectionsFor(block, permutation.getState(FACING_STATE));
        if (!found) return;
        if (permutation.getState(LEFT_STATE) === found.left && permutation.getState(RIGHT_STATE) === found.right) return;

        block.setPermutation(permutation.withState(LEFT_STATE, found.left).withState(RIGHT_STATE, found.right));
    } catch { }
}

function refreshAround(block) {
    if (!block) return;
    refresh(block);
    for (const step of HORIZONTAL) refresh(safeOffset(block, step));
}

function scheduleRefresh(dimension, location) {
    const { x, y, z } = location;
    system.run(() => {
        try { refreshAround(dimension.getBlock({ x, y, z })); } catch { }
    });
}

system.beforeEvents.startup.subscribe((init) => {
    init.blockComponentRegistry.registerCustomComponent(COMPONENT_ID, {

        beforeOnPlayerPlace(event) {
            try {
                const permutation = event.permutationToPlace;
                const found = connectionsFor(event.block, permutation.getState(FACING_STATE));
                if (!found) return;
                event.permutationToPlace = permutation
                    .withState(LEFT_STATE, found.left)
                    .withState(RIGHT_STATE, found.right);
            } catch { }
        },

        onPlace(event) {
            scheduleRefresh(event.block.dimension, event.block.location);
        },
        onBreak(event) {
            scheduleRefresh(event.block.dimension, event.block.location);
        },
        onPlayerBreak(event) {
            scheduleRefresh(event.block.dimension, event.block.location);
        },
    });
});
