import { system, world } from "@minecraft/server";
import {
    CONTAINER_OWNER_STATE, MAX_VIEW_DISTANCE, OPEN_STATE, cellKey, centerOf, distanceSq, getBlock, getState,
    inventoryOf, isChest, isPlayer, playSoundAt, setStates, warn
} from "./wwCommon.js";
import { groupKey, isChanging, resolve } from "./chestLayout.js";
import { setOpenVisual } from "./chestEntity.js";

const SOUND_OPEN = "random.chestopen";
const SOUND_CLOSE = "random.chestclosed";
const HALF = 27;

const sessions = new Map();
const reservations = new Map();

export function reserveChestOpen(block) {
    const key = groupKey(block);
    if (sessions.has(key)) return;
    const reservation = cellKey(block.dimension, block.location);
    reservations.set(key, reservation);
    system.run(() => {
        if (reservations.get(key) === reservation) reservations.delete(key);
    });
}

export function isOpen(block) {
    return sessions.has(groupKey(block));
}

export function isLockedFor(block) {
    const info = resolve(block);
    if (info.kind !== "double") return false;
    const session = sessions.get(groupKey(block, info));
    const location = cellKey(block.dimension, block.location);
    if (session) return cellKey(block.dimension, session.viewed) !== location;
    const reserved = reservations.get(groupKey(block, info));
    return reserved !== undefined && reserved !== location;
}

function halvesOf(session) {
    return [getBlock(session.dimension, session.left), session.double ? getBlock(session.dimension, session.right) : undefined]
        .filter((block) => block !== undefined);
}

function soundPosition(session) {
    const a = centerOf(session.left);
    if (!session.double) return a;
    const b = centerOf(session.right);
    return { x: (a.x + b.x) / 2, y: a.y, z: (a.z + b.z) / 2 };
}

function applyOpen(session, open, withSound) {

    setOpenVisual(session.dimension, session.left, session.double ? session.right : undefined, open);
    if (withSound) playSoundAt(session.dimension, soundPosition(session), open ? SOUND_OPEN : SOUND_CLOSE);
}

function gather(target, info) {
    normalizeRest(info);
    const left = inventoryOf(info.left);
    const right = inventoryOf(info.right);
    const view = inventoryOf(target);
    if (!left || !right || !view || view.size < HALF * 2) throw new Error("не хватает слотов для двойного сундука");

    const items = new Array(HALF * 2);
    for (let i = 0; i < HALF; i++) {
        items[i] = left.getItem(i);
        items[HALF + i] = right.getItem(i);
    }
    left.clearAll();
    right.clearAll();
    for (let i = 0; i < items.length; i++) if (items[i]) view.setItem(i, items[i]);
    const owner = cellKey(target.dimension, target.location) === cellKey(info.left.dimension, info.left.location) ? 1 : 2;
    for (const half of [info.left, info.right]) setStates(half, { [CONTAINER_OWNER_STATE]: owner });
}

function scatter(source, info) {
    const left = inventoryOf(info.left);
    const right = inventoryOf(info.right);
    const view = inventoryOf(source);
    if (!left || !right || !view || view.size < HALF * 2) throw new Error("не удалось сохранить двойной сундук");

    const items = new Array(HALF * 2);
    for (let i = 0; i < items.length; i++) items[i] = view.getItem(i);
    const secondary = cellKey(source.dimension, source.location) === cellKey(info.left.dimension, info.left.location) ? right : left;
    const overflow = [];
    for (let slot = 0; slot < secondary.size; slot++) {
        let item = secondary.getItem(slot);
        if (!item) continue;
        for (let i = 0; i < items.length && item; i++) {
            const stored = items[i];
            if (!stored || !stored.isStackableWith(item) || stored.amount >= stored.maxAmount) continue;
            const count = Math.min(item.amount, stored.maxAmount - stored.amount);
            stored.amount += count;
            if (count === item.amount) item = undefined;
            else item.amount -= count;
        }
        if (!item) continue;
        const free = items.findIndex((stack) => !stack);
        if (free >= 0) items[free] = item;
        else overflow.push(item);
    }
    left.clearAll();
    right.clearAll();
    for (let i = 0; i < HALF; i++) {
        if (items[i]) left.setItem(i, items[i]);
        if (items[HALF + i]) right.setItem(i, items[HALF + i]);
    }
    for (const half of [info.left, info.right]) setStates(half, { [CONTAINER_OWNER_STATE]: 0 });
    for (const item of overflow) info.left.dimension.spawnItem(item, centerOf(info.left.location));
}

function finish(key, session, withSound) {
    const viewed = getBlock(session.dimension, session.viewed);
    if (!viewed) return false;

    if (session.double) {
        const info = resolve(viewed);
        if (info.kind === "unloaded") return false;
        if (info.kind === "double") {
            try { scatter(viewed, info); } catch (error) { warn(error); return false; }
        }
    }
    sessions.delete(key);
    applyOpen(session, false, withSound);
    return true;
}

export function chestOpened(event) {
    const block = event.block;
    const player = event.openSource?.entity ?? event.player;
    if (!isChest(block) || !isPlayer(player) || isChanging(block.dimension, block.location)) return;

    const info = resolve(block);
    if (info.kind === "unloaded" || info.kind === "none") return;

    const double = info.kind === "double";
    const key = groupKey(block, info);
    const existing = sessions.get(key);

    if (existing) {
        if (cellKey(block.dimension, existing.viewed) === cellKey(block.dimension, block.location)) {
            existing.players.add(player.id);
        }
        return;
    }

    if (double) {
        try { gather(block, info); } catch (error) { warn(error); return; }
    }

    const session = {
        dimension: block.dimension,
        viewed: { ...block.location },
        left: { ...(double ? info.left : block).location },
        right: double ? { ...info.right.location } : undefined,
        double,
        players: new Set([player.id])
    };
    sessions.set(key, session);
    applyOpen(session, true, true);
}

export function chestClosed(event) {
    const block = event.block;
    if (!isChest(block) || isChanging(block.dimension, block.location)) return;

    const key = groupKey(block);
    const session = sessions.get(key);
    if (!session) return;

    const player = event.closeSource?.entity ?? event.player;
    if (player) session.players.delete(player.id);
    if (session.players.size === 0) finish(key, session, true);
}

export function chestForgetPlayer(playerId) {
    for (const [key, session] of [...sessions]) {
        session.players.delete(playerId);
        if (session.players.size === 0) finish(key, session, true);
    }
}

export function chestAudit() {
    const players = new Map(world.getAllPlayers().map((player) => [player.id, player]));
    for (const [key, session] of [...sessions]) {
        if (!getBlock(session.dimension, session.viewed)) continue;
        for (const id of [...session.players]) {
            const player = players.get(id);
            if (!player || player.dimension.id !== session.dimension.id ||
                distanceSq(player.location, session.viewed) > MAX_VIEW_DISTANCE ** 2) session.players.delete(id);
        }
        if (session.players.size === 0) finish(key, session, true);
    }
}

export function dropSessionsAt(dimension, location) {
    const id = cellKey(dimension, location);
    for (const [key, session] of [...sessions]) {
        if (session.dimension.id !== dimension.id) continue;
        if (cellKey(dimension, session.left) === id || (session.right && cellKey(dimension, session.right) === id)) {
            if (!finish(key, session, false)) throw new Error("Сначала загрузите обе половины сундука");
        }
    }
}

export function normalizeRest(info) {
    if (info.kind !== "double" || sessions.has(groupKey(info.left, info))) return;
    const owner = getState(info.left, CONTAINER_OWNER_STATE, 0) || getState(info.right, CONTAINER_OWNER_STATE, 0);
    if (owner) {
        scatter(owner === 1 ? info.left : info.right, info);
        return;
    }
    const halves = [inventoryOf(info.left), inventoryOf(info.right)];
    if (halves.some((container) => !container || container.size < HALF * 2)) return;

    const strays = [];
    for (const container of halves) {
        for (let i = HALF; i < container.size; i++) {
            const item = container.getItem(i);
            if (!item) continue;
            strays.push(item);
            container.setItem(i, undefined);
        }
    }
    for (const item of strays) {
        let placed = false;
        for (const container of halves) {
            for (let i = 0; i < HALF && !placed; i++) {
                if (container.getItem(i)) continue;
                container.setItem(i, item);
                placed = true;
            }
            if (placed) break;
        }
        if (!placed) {
            try { info.left.dimension.spawnItem(item, centerOf(info.left.location)); } catch (error) { warn(error); }
        }
    }
}
