import { system, world, EquipmentSlot, BlockTypes } from '@minecraft/server';
import { jarPowered, displayLocalPosition, visualKind, displayFrom, slotsFrom, pickSlotFromRay, slotWorldPosition, YAW, facingForBlock, attachmentRotation, isBanner, bannerYaw, setBannerYaw, bannerMount, bannerEntityYaw } from './shelfMath.js';
import { equipShelfItem } from './shelfEquipment.js';

const ID = 'create:place_in_block', ENTITY = 'ab:shelf_item';
const ownerTag = p => `ab:shelf:${p.x},${p.y},${p.z}`;
const facingOf = facingForBlock;
const layoutKey = (params,facing) => JSON.stringify([8,bannerYaw(params),params.banner_rotation,params.banner_scale,params.item_slot,params.coordinate_space,facing,params.Item_rotation,params.item_scale,params.Block_rotation,params.block_scale,params.item_visual,params.Item_offset,params.Block_offset]);
function parameters(block) { return block.getComponent(ID)?.customComponentParameters?.params; }
function entities(block) {
    return block.dimension.getEntities({ type: ENTITY, tags: [ownerTag(block.location)], location: block.center(), maxDistance: 3 });
}
function drop(entity) {
    const container = entity.getComponent('minecraft:inventory')?.container;
    const item = container?.getItem(0);
    if (item) { entity.dimension.spawnItem(item, entity.location); container.setItem(0); }
    entity.remove();
}
function clear(block) { for (const entity of entities(block)) drop(entity); }
function visual(item) { return visualKind(item.typeId, !!BlockTypes.get(item.typeId)); }
function visualOf(params, item) { return isBanner(item.typeId) ? 'item' : (params.item_visual ?? visual(item)); }
const mountOf = (item, facing) => isBanner(item.typeId) ? bannerMount() : attachmentRotation(facing);
function yawOf(item, facing, entity, playerYaw) {
    if (!isBanner(item.typeId)) return YAW[facing] ?? 0;
    const saved = entity?.getDynamicProperty('ab:yaw');
    return typeof saved === 'number' ? saved : bannerEntityYaw(facing, playerYaw);
}

function interact(block, player, id, expectedType, expectedFacing, selectedSlot, expectedItem) {
    if (!player.isValid || player.isSneaking || block.typeId !== expectedType || player.selectedSlotIndex !== selectedSlot || facingOf(block) !== expectedFacing) return;
    const params = parameters(block);
    if (!params) return;
    const slots = slotsFrom(params), facing = facingOf(block);
    if (!slots.some(([key]) => key === id)) return;
    const existing = entities(block).find(e => e.getDynamicProperty('ab:slot') === id);

    const inventory = player.getComponent('minecraft:inventory')?.container;
    const held = inventory?.getItem(selectedSlot);
    if (existing) {
        if (held || expectedItem) return;
        const stored = existing.getComponent('minecraft:inventory').container.getItem(0);
        if (stored) {
            const remainder = inventory.addItem(stored);
            if (remainder) return;
        }
        existing.remove();
        return;
    }
    if (!held || !expectedItem || !held.isStackableWith(expectedItem) || held.amount !== expectedItem.amount) return;
    const isBlockVisual = visualOf(params, held) === 'block';
    const display = displayFrom(params, isBlockVisual, held.typeId);
    const local = slots.find(([key]) => key === id)[1];
    const origin = block.location;
    const position = slotWorldPosition(displayLocalPosition(params, local, isBlockVisual), origin, facing);
    const single = held.clone(); single.amount = 1;
    let entity;
    try {
        const yaw = yawOf(single, facing, undefined, player.getRotation().y);
        entity = block.dimension.spawnEntity(ENTITY, position, { initialRotation: yaw });
        if (isBanner(single.typeId)) entity.setDynamicProperty('ab:yaw', yaw);
        entity.addTag(ownerTag(origin));
        entity.setDynamicProperty('ab:slot', id);
        entity.setDynamicProperty('ab:owner_type', block.typeId);
        const mount = mountOf(single, facing);
        for (let i=0;i<3;i++) entity.setProperty(`ab:mount_${'xyz'[i]}`,mount[i]);
        entity.setDynamicProperty('ab:layout', layoutKey(params, facing));
        entity.setProperty('ab:jar_powered', jarPowered(block));
        entity.setProperty('create:item_visual', visualOf(params, single));
        entity.setProperty('create:item_scale', display.scale);
        for (let i = 0; i < 3; i++) entity.setProperty(`create:rotation_${'xyz'[i]}`, display.rotation[i]);
        entity.getComponent('minecraft:inventory').container.setItem(0, single);
        equipShelfItem(entity, single, EquipmentSlot.Mainhand);
        entity.setProperty('ab:ready', true);
        if (String(player.getGameMode()).toLowerCase() !== 'creative') {
            const rest = held.amount > 1 ? held.clone() : undefined;
            if (rest) rest.amount--;
            inventory.setItem(selectedSlot, rest);
        }
    } catch (error) {

        entity?.remove();
        throw error;
    }
}
world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    if (event.player.isSneaking || !parameters(event.block)) return;
    event.cancel = true;
    if (!event.isFirstEvent) return;
    const { block, player } = event;
    const type = block.typeId, slot = player.selectedSlotIndex, facing = facingOf(block);

    const id = pickSlotFromRay(slotsFrom(parameters(block)), player.getHeadLocation(), player.getViewDirection(), block.location, facing);
    if (id === undefined) return;
    const item = event.itemStack?.clone();
    system.run(() => {
        try { interact(block, player, id, type, facing, slot, item); }
        catch (e) { console.warn(`[place_in_block] ${e}`); }
    });
});
system.beforeEvents.startup.subscribe(({ blockComponentRegistry }) => {
    blockComponentRegistry.registerCustomComponent('ab:jar_redstone', {
        onRedstoneUpdate({ block, powerLevel }) {
            const powered = jarPowered(block, powerLevel);
            for (const entity of entities(block)) entity.setProperty('ab:jar_powered', powered);
        },
    });
    blockComponentRegistry.registerCustomComponent(ID, {
        onBreak({ block }) { clear(block); },
        onPlayerBreak({ block }) { clear(block); },
    });
});

system.runInterval(() => {
    for (const name of ['overworld', 'nether', 'the_end']) {
        for (const entity of world.getDimension(name).getEntities({ type: ENTITY })) {
            try {
                const tag = entity.getTags().find(t => t.startsWith('ab:shelf:'));
                if (!tag) continue;
                const [x, y, z] = tag.slice('ab:shelf:'.length).split(',').map(Number);
                const block = entity.dimension.getBlock({ x, y, z });
                if (!block) continue;
                if (block.typeId !== entity.getDynamicProperty('ab:owner_type') || !parameters(block)) { drop(entity); continue; }

                const powered = jarPowered(block);
                if (entity.getProperty('ab:jar_powered') !== powered) entity.setProperty('ab:jar_powered', powered);
                if (!entity.getProperty('ab:ready') || entity.getDynamicProperty('ab:layout') !== layoutKey(parameters(block), facingOf(block))) {
                    const stored = entity.getComponent('minecraft:inventory')?.container?.getItem(0);
                    if (stored) {
                        const local = slotsFrom(parameters(block)).find(([id]) => id === entity.getDynamicProperty('ab:slot'))?.[1];
                        if (local) {
                            entity.teleport(slotWorldPosition(displayLocalPosition(parameters(block), local, visualOf(parameters(block), stored) === 'block'), block.location, facingOf(block)), { rotation: { x:0, y:yawOf(stored, facingOf(block), entity) } });
                        }
                        if (!local) { drop(entity); continue; }
                        const mount=mountOf(stored, facingOf(block));
                        for (let i=0;i<3;i++) entity.setProperty(`ab:mount_${'xyz'[i]}`,mount[i]);
                        const display = displayFrom(parameters(block), visualOf(parameters(block), stored) === 'block', stored.typeId);
                        entity.setProperty('create:item_visual', visualOf(parameters(block), stored));
                        entity.setProperty('create:item_scale', display.scale);
                        for (let i=0;i<3;i++) entity.setProperty(`create:rotation_${'xyz'[i]}`, display.rotation[i]);
                        entity.setDynamicProperty('ab:layout',layoutKey(parameters(block),facingOf(block)));
                        equipShelfItem(entity, stored, EquipmentSlot.Mainhand);
                        entity.setProperty('ab:ready', true);
                    }
                }
            } catch (e) { console.warn(`[place_in_block] audit: ${e}`); }
        }
    }
}, 40);




try { const saved = world.getDynamicProperty('ab:banner_yaw'); if (typeof saved === 'number') setBannerYaw(saved); } catch {}
system.afterEvents.scriptEventReceive.subscribe(({ id, message, sourceEntity }) => {
    if (id !== 'ab:banner_yaw') return;
    const value = Number(message.trim());
    const tell = text => { try { (sourceEntity?.sendMessage ? sourceEntity : world).sendMessage(text); } catch {} };
    if (message.trim() === '' ) { tell(`§7ab:banner_yaw = ${bannerYaw()}`); return; }
    if (!Number.isFinite(value)) { tell('§cUsage: /scriptevent ab:banner_yaw <degrees>'); return; }
    const norm = ((value % 360) + 360) % 360;
    setBannerYaw(norm);
    world.setDynamicProperty('ab:banner_yaw', norm);
    tell(`§aab:banner_yaw = ${norm}`);
});
