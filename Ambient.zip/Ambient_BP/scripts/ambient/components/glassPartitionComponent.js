import { system, world } from "@minecraft/server";
import { abTriggers } from "../abTriggers.js";
import { faceIsFull, stairFullFaces } from "../utils/blockChecks.js";
import { NO_PARTITION_CONNECTION } from "../data/partitionConnections.js";
import { matches, NO_WALL_CONNECT } from "../data/blockSets.js";

const PART = "ab:vertical_part";
const SIDES = [
  ["north", "ab:link_north"],
  ["east", "ab:link_east"],
  ["south", "ab:link_south"],
  ["west", "ab:link_west"],
];
const OPPOSITE = { north: "south", east: "west", south: "north", west: "east" };

export function isPartition(block) {
  const id = block?.typeId;
  return typeof id === "string" && id.startsWith("ab:") && id.endsWith("glass_partition");
}

export function isLinkable(block, side) {
  if (!block || block.isAir || block.isLiquid) return false;
  const id = block.typeId;
  if (typeof id !== "string") return false;

  if (isPartition(block)) return true;
  if (block.hasTag("ab:wall") || block.hasTag("dd:wall")) return true;
  if (id.startsWith("minecraft:") && (id.endsWith("glass_pane") || id.endsWith("_bars") || id.endsWith("_wall"))) return true;
  if (NO_PARTITION_CONNECTION.has(id) || block.hasTag("ab:no_partition_connection") || matches(id, NO_WALL_CONNECT)) return false;

  const states = block.permutation.getAllStates();

  const stairFaces = stairFullFaces(block, states);
  if (stairFaces !== null) return stairFaces.includes(OPPOSITE[side]);
  return faceIsFull(block, states, "side");
}

function offset(block, dir) {
  try {
    switch (dir) {
      case "up": return block.above();
      case "down": return block.below();
      case "north": return block.north();
      case "south": return block.south();
      case "east": return block.east();
      case "west": return block.west();
    }
  } catch { return undefined; }
}

export function refresh(block) {
  if (!block || !block.isValid || !isPartition(block)) return;
  const up = offset(block, "up"), down = offset(block, "down");
  const hasUp = !!up && up.typeId === block.typeId;
  const hasDown = !!down && down.typeId === block.typeId;
  const part = hasUp && hasDown ? "middle" : hasUp ? "bottom" : hasDown ? "top" : "single";

  let perm = block.permutation;
  let dirty = false;
  if (perm.getState(PART) !== part) { perm = perm.withState(PART, part); dirty = true; }
  for (const [dir, state] of SIDES) {
    const neighbour = offset(block, dir);

    if (!neighbour) continue;
    const link = isLinkable(neighbour, dir);
    if (perm.getState(state) !== link) { perm = perm.withState(state, link); dirty = true; }
  }
  if (dirty) block.setPermutation(perm);
}

const AROUND = ["up", "down", "north", "east", "south", "west"];
function safelyRefresh(block) {
  try { refresh(block); }
  catch (error) { console.warn(`[glass_partition] ${error}`); }
}
function refreshNeighbors(block) {
  for (const dir of AROUND) safelyRefresh(offset(block, dir));
}
function refreshAround(block) {
  safelyRefresh(block);
  refreshNeighbors(block);
}
function scheduleAround({ block }) {
  const { dimension, location } = block;
  system.run(() => {
    try { const current = dimension.getBlock(location); if (current) refreshAround(current); }
    catch {                                                       }
  });
}

system.beforeEvents.startup.subscribe(({ blockComponentRegistry }) => {
  blockComponentRegistry.registerCustomComponent("ab:glass_partition", {
    onPlace: scheduleAround,
    onBreak: scheduleAround,
    onPlayerBreak: scheduleAround,

    onTick({ block }) { safelyRefresh(block); },
  });
});

world.afterEvents.playerPlaceBlock.subscribe((e) => refreshAround(e.block));
world.afterEvents.playerBreakBlock.subscribe((e) => refreshNeighbors(e.block));
world.afterEvents.blockExplode.subscribe((e) => refreshNeighbors(e.block));

abTriggers.registerBehaviourByTag("ab:glass_partition", {
  onAdjacentChange({ block }) { safelyRefresh(block); },
});
