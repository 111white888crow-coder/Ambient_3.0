import { system } from '@minecraft/server';
import { shapeFor } from './shelfMath.js';

const TAG = 'create:items_shelf';
const SIDES = { north: [-1, 0], east: [0, -1], south: [1, 0], west: [0, 1] };
const AROUND = [[1, 0], [-1, 0], [0, 1], [0, -1]];
function offset(block, x, z) { try { return block.offset({ x, y: 0, z }); } catch { return undefined; } }
function matches(block, facing, mount) {
    return block?.hasTag(TAG) && block.permutation.getState('ab:facing') === facing && block.permutation.getState('ab:mount') === mount;
}
function scan(block, dx, dz, facing, mount) {
    let count = 0;

    while (count < 2) {
        block = offset(block, dx, dz);
        if (!matches(block, facing, mount)) break;
        count++;
    }
    return count;
}
function refresh(block) {
    if (!block?.hasTag(TAG)) return;
    const p = block.permutation, facing = p.getState('ab:facing'), mount = p.getState('ab:mount');
    const [dx, dz] = SIDES[facing] ?? SIDES.north;
    const shape = shapeFor(scan(block, dx, dz, facing, mount), scan(block, -dx, -dz, facing, mount));
    if (p.getState('ab:shape') !== shape) block.setPermutation(p.withState('ab:shape', shape));
}
function around(block) {
    refresh(block);

    for (const [dx, dz] of AROUND) for (let n = 1; n <= 2; n++) refresh(offset(block, dx * n, dz * n));
}
function schedule({ block }) {
    const { dimension, location } = block;
    system.run(() => { try { around(dimension.getBlock(location)); } catch (e) { console.warn(`[items_shelf] ${e}`); } });
}
function beforePlace(event) {
    const face = String(event.face).toLowerCase();
    const mount = face === 'up' || face === 'down' ? 'floor' : 'wall';
    const facing = mount === 'wall' ? face : horizontalFacing(event.player);
    event.permutationToPlace = event.permutationToPlace.withState('ab:mount', mount).withState('ab:facing', facing);
}
function horizontalFacing(player) {
    const yaw = ((player.getRotation().y % 360) + 360) % 360;
    return ['north', 'east', 'south', 'west'][Math.round(yaw / 90) % 4];
}
system.beforeEvents.startup.subscribe(({ blockComponentRegistry }) => {
    blockComponentRegistry.registerCustomComponent(TAG, {
        beforeOnPlayerPlace: beforePlace, onPlace: schedule, onBreak: schedule, onPlayerBreak: schedule,
        onTick({ block }) { around(block); },
    });
});
