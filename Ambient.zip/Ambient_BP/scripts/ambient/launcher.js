import "./components/slabComponent.js";
import "./components/wallComponent.js";
import "./components/glassPartitionComponent.js";
import "./components/wallShelfComponent.js";
import "./components/branchComponent.js";
import { system, world } from "@minecraft/server";
import { barrelAudit, barrelClosed, barrelComponent, barrelForgetPlayer, barrelOpened } from "./components/barrelComponent.js";
import { beforeChestInteract, onPlayerPlaceChest } from "./components/chestComponent.js";
import { chestAudit, chestClosed, chestForgetPlayer, chestOpened, isOpen as isChestOpen } from "./components/chestStorage.js";
import { sweepStrayEntities } from "./components/chestEntity.js";
import { warn } from "./components/wwCommon.js";
import { discoverChestsFor, tickHoppers } from "./components/chestHoppers.js";
import { beforeChestExplosion, beforePlayerBreakChest } from "./components/chestBreaking.js";

system.beforeEvents.startup.subscribe((event) => {
    barrelComponent.register(event.blockComponentRegistry);
});

world.beforeEvents.playerInteractWithBlock.subscribe(beforeChestInteract);
world.afterEvents.playerPlaceBlock.subscribe(onPlayerPlaceChest);
world.beforeEvents.playerBreakBlock.subscribe(beforePlayerBreakChest);
world.beforeEvents.explosion.subscribe(beforeChestExplosion);

world.afterEvents.blockContainerOpened.subscribe((event) => {
    try { barrelOpened(event); } catch (error) { warn(error); }
    try { chestOpened(event); } catch (error) { warn(error); }
});

world.afterEvents.blockContainerClosed.subscribe((event) => {
    try { barrelClosed(event); } catch (error) { warn(error); }
    try { chestClosed(event); } catch (error) { warn(error); }
});

function forgetPlayer(playerId) {
    try { barrelForgetPlayer(playerId); } catch (error) { warn(error); }
    try { chestForgetPlayer(playerId); } catch (error) { warn(error); }
}
world.afterEvents.playerLeave.subscribe(({ playerId }) => forgetPlayer(playerId));
world.afterEvents.entityDie.subscribe(({ deadEntity }) => {
    if (deadEntity.typeId === "minecraft:player") forgetPlayer(deadEntity.id);
});

system.runInterval(() => {
    try { barrelAudit(); } catch (error) { warn(error); }
    try { chestAudit(); } catch (error) { warn(error); }
}, 40);

system.runInterval(() => {
    try { sweepStrayEntities(isChestOpen); } catch (error) { warn(error); }
}, 100);

world.afterEvents.playerPlaceBlock.subscribe(({ block }) => {
    try { discoverChestsFor(block); } catch (error) { warn(error); }
});

system.runInterval(() => {
    try { tickHoppers(); } catch (error) { warn(error); }
}, 1);

import "./components/itemsShelfComponent.js";
import "./components/placeInBlockComponent.js";
import "./components/maceSmashWave.js";
